
package com.newton.deskchatapp.nearby

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.newton.deskchatapp.R
import com.newton.deskchatapp.models.Desk

class NearbyDeskAdapter : RecyclerView.Adapter<NearbyDeskAdapter.ViewHolder>() {

    private val desks = mutableListOf<Desk>()

    fun submitList(newList: List<Desk>) {
        desks.clear()
        desks.addAll(newList)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_nearby_desk, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val desk = desks[position]
        holder.bind(desk)
    }

    override fun getItemCount(): Int = desks.size

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val nameText: TextView = itemView.findViewById(R.id.textDeskName)
        private val locationText: TextView = itemView.findViewById(R.id.textDeskLocation)

        fun bind(desk: Desk) {
            nameText.text = desk.name
            locationText.text = "Lat: ${desk.location.latitude}, Lng: ${desk.location.longitude}"
        }
    }
}
