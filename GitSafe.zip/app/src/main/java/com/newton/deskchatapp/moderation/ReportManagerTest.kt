package com.newton.deskchatapp.moderation

import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.runBlocking
import org.junit.Before
import org.junit.Test
import org.mockito.kotlin.*

class ReportManagerTest {

    private lateinit var firestore: FirebaseFirestore
    private lateinit var reportManager: ReportManager

    @Before
    fun setup() {
        firestore = mock()
        // stub collection("reports").document() -> returns a mock docref that returns a completed task
        val reportsCollection: CollectionReference = mock()
        val docRef: DocumentReference = mock()
        whenever(firestore.collection("reports")).thenReturn(reportsCollection)
        whenever(reportsCollection.document()).thenReturn(docRef)
        whenever(docRef.set(any())).thenReturn(mock())

        reportManager = ReportManager(firestore)
    }

    @Test
    fun test_reportMessage_calls_firestore() = runBlocking {
        val result = reportManager.reportMessage(
            messageId = "m1",
            deskId = "d1",
            reporterId = "u1",
            reason = "spam",
            additionalNotes = "note"
        )
        // depending on ReportManager implementation it might return Result.success
        // assert success if that's the API
        assert(result.isSuccess)
        // verify set called
        verify(firestore).collection("reports")
        verify(firestore.collection("reports")).document()
    }
}