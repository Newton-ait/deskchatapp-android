package com.newton.deskchatapp.moderation

import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ReportManager @Inject constructor(
    private val firestore: FirebaseFirestore
) {

    /**
     * Creates a report entry in `reports` collection.
     * Returns Result.success(Unit) on success, or Result.failure(exception) on error.
     */
    suspend fun reportMessage(
        messageId: String,
        deskId: String?,
        reporterId: String,
        reason: String,
        additionalNotes: String?
    ): Result<Unit> {
        return try {
            val payload = mapOf(
                "messageId" to messageId,
                "deskId" to (deskId ?: ""),
                "reporterId" to reporterId,
                "reason" to reason,
                "notes" to (additionalNotes ?: ""),
                "createdAt" to com.google.firebase.Timestamp.now()
            )
            firestore.collection("reports").add(payload).await()
            Result.success(Unit)
        } catch (t: Throwable) {
            Result.failure(t)
        }
    }
}