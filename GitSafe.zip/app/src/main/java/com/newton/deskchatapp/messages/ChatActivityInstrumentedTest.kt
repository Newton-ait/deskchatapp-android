package com.newton.deskchatapp.messages

import androidx.test.core.app.ActivityScenario
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.*
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.newton.deskchatapp.R
import com.newton.deskchatapp.models.Message
import org.junit.Test
import org.junit.runner.RunWith
import androidx.recyclerview.widget.RecyclerView

@RunWith(AndroidJUnit4::class)
class ChatActivityInstrumentedTest {
    @Test
    fun sendButton_and_display() {
        ActivityScenario.launch(ChatActivity::class.java).use {
            onView(withId(R.id.inputMessage)).check(matches(isDisplayed()))
            onView(withId(R.id.buttonSend)).check(matches(isDisplayed()))
            onView(withId(R.id.inputMessage)).perform(typeText("Hello instrumentation"), closeSoftKeyboard())
            onView(withId(R.id.buttonSend)).perform(click())
            onView(withText("Hello instrumentation")).check(matches(isDisplayed()))
        }
    }

    @Test
    fun adapter_displays_message() {
        ActivityScenario.launch(ChatActivity::class.java).use {
            it.onActivity { act ->
                val rv = act.findViewById<RecyclerView>(R.id.recyclerMessages)
                val ad = rv.adapter
                ad?.let { adapter ->
                    val m = Message(id="1", deskId="deskX", authorId="x", text="Hello instrumentation")
                    if (adapter is MessageListAdapter) adapter.submitList(listOf(m))
                }
            }
            onView(withText("Hello instrumentation")).check(matches(isDisplayed()))
        }
    }
}