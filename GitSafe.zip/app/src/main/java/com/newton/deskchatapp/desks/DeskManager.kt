package com.newton.deskchatapp.desk

import com.google.firebase.firestore.GeoPoint
import com.google.firebase.firestore.FirebaseFirestore
import com.newton.deskchatapp.models.Desk
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DeskManager @Inject constructor(
    private val firestore: FirebaseFirestore
) {

    private fun desksCollection() = firestore.collection("desks")

    suspend fun getDeskById(deskId: String): Desk? {
        return try {
            val doc = desksCollection().document(deskId).get().await()
            doc.toObject(Desk::class.java)
        } catch (e: Exception) {
            null
        }
    }

    suspend fun getNearbyDesks(location: GeoPoint, radiusMeters: Double = 1000.0): Result<List<Desk>> {
        return try {
            // NOTE: crude example — keep your geopoint query logic as needed
            val snapshot = desksCollection().get().await()
            val desks = snapshot.documents.mapNotNull { it.toObject(Desk::class.java) }
            Result.success(desks)
        } catch (t: Throwable) {
            Result.failure(t)
        }
    }

    suspend fun createDesk(desk: Desk): Result<String> {
        return try {
            val ref = desksCollection().add(desk).await()
            Result.success(ref.id)
        } catch (t: Throwable) {
            Result.failure(t)
        }
    }
}