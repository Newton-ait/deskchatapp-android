package com.newton.deskchatapp.workers

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.room.Room
import com.newton.deskchatapp.cloud.FirebaseDataSource
import com.newton.deskchatapp.local.AppDatabase
import com.newton.deskchatapp.util.Result
import kotlinx.coroutines.flow.firstOrNull
import timber.log.Timber

class SyncWorker(private val ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    private val db = Room.databaseBuilder(ctx, AppDatabase::class.java, "deskchat.db").build()
    private val dao = db.messageDao()
    private val cloud = FirebaseDataSource()

    override suspend fun doWork(): Result {
        return try {
            val unsynced = dao.getAllMessages().firstOrNull()?.filter { !it.isSynced } ?: emptyList()
            for (msg in unsynced) {
                when (val result = cloud.sendMessage(msg)) {
                    is com.newton.deskchatapp.util.Result.Success -> { dao.markSynced(msg.id, true); Timber.i("Synced ${'$'}{msg.id}") }
                    is com.newton.deskchatapp.util.Result.Error -> { Timber.e(result.exception, "Failed sync") }
                }
            }
            Result.success()
        } catch (e: Exception) {
            Timber.e(e, "Sync worker failed")
            Result.retry()
        }
    }
}
