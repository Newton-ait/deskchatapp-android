package com.newton.deskchatapp.moderation

import android.content.Context
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Basic profanity filter implementation.
 * - getProfanityScore(text): returns count of bad words (0 means clean)
 * - filterText(text): replaces bad words with asterisks
 *
 * NOTE: This is intentionally simple and offline. For production, integrate a
 * server-side API (Perspective API or custom ML) for better accuracy and scoring.
 */
@Singleton
class ProfanityFilter @Inject constructor(private val context: Context) {

    // Minimal list; extend as required or load from resource.
    private val badWords = setOf(
        "damn", "hell", "shit", "fuck", "bastard", "asshole"
    )

    private val wordRegex = Regex("\\b([A-Za-z']+)\\b", RegexOption.IGNORE_CASE)

    /**
     * Returns an integer "score" — count of detected bad words.
     */
    fun getProfanityScore(text: String): Int {
        var count = 0
        wordRegex.findAll(text).forEach { match ->
            val word = match.groupValues[1].lowercase()
            if (badWords.contains(word)) count++
        }
        return count
    }

    /**
     * Returns a filtered string where bad words are replaced with asterisks of equal length.
     */
    fun filterText(text: String): String {
        return wordRegex.replace(text) { match ->
            val word = match.groupValues[1]
            if (badWords.contains(word.lowercase())) {
                "*".repeat(word.length)
            } else {
                word
            }
        }
    }
}