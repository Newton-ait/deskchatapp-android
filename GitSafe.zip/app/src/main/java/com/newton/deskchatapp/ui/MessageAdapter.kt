package com.newton.deskchatapp.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.newton.deskchatapp.R
import com.newton.deskchatapp.model.Message
import com.newton.deskchatapp.util.UserNameHelper
import java.text.SimpleDateFormat
import java.util.*

class MessageAdapter(private var messages: List<Message>) : RecyclerView.Adapter<MessageAdapter.MessageViewHolder>() {
    class MessageViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val txtSender: TextView = view.findViewById(R.id.txtSender)
        val txtText: TextView = view.findViewById(R.id.txtText)
        val txtTime: TextView = view.findViewById(R.id.txtTime)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_message, parent, false)
        return MessageViewHolder(view)
    }

    override fun getItemCount() = messages.size

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        val msg = messages[position]
        holder.txtSender.text = UserNameHelper.generateAnonymousName(msg.senderId)
        holder.txtText.text = msg.text
        val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
        holder.txtTime.text = sdf.format(Date(msg.timestamp))
    }

    fun update(newList: List<Message>) {
        messages = newList
        notifyDataSetChanged()
    }
}
