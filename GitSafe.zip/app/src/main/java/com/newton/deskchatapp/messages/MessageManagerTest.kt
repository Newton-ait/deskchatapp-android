package com.newton.deskchatapp.messages

import com.google.firebase.firestore.FirebaseFirestore
import com.newton.deskchatapp.models.Message
import kotlinx.coroutines.runBlocking
import org.junit.Test
import org.mockito.Mockito
import kotlin.test.assertTrue

class MessageManagerTest {
    @Test
    fun postMessage_delegates_to_repo() = runBlocking {
        val mockRepo = Mockito.mock(MessagesRepository::class.java)
        val manager = MessageManager(mockRepo)
        val msg = Message(id="1", deskId="desk1", authorId="a", text="Hello")
        Mockito.`when`(mockRepo.sendMessage(Mockito.eq("desk1"), Mockito.any(Message::class.java)))
            .thenReturn(Result.success(msg))
        val result = manager.postMessage("desk1", msg)
        assertTrue(result.isSuccess)
        Mockito.verify(mockRepo).sendMessage(Mockito.eq("desk1"), Mockito.any(Message::class.java))
    }
}