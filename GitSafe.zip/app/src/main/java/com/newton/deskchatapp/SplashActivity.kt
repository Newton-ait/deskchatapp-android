
package com.newton.deskchatapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

import com.newton.deskchatapp.util.ThemeManager

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeManager.applySavedTheme(this)
        setContentView(R.layout.activity_splash)
        window.decorView.postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }, 700)
    }
}
