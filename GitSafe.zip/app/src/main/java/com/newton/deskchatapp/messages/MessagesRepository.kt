package com.newton.deskchatapp.messages

import android.util.Log
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.firestore.ktx.toObject
import com.newton.deskchatapp.models.Message
import com.newton.deskchatapp.util.Resource
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

private const val TAG = "MessagesRepository"

class MessagesRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth
) {
    private fun messagesCollectionForDesk(deskId: String) =
        db.collection("desks").document(deskId).collection("messages")

    /**
     * Real-time messages stream for a desk, wrapped in Resource states.
     */
    fun getMessages(deskId: String): Flow<Resource<List<Message>>> = callbackFlow {
        trySend(Resource.Loading(message = "Loading messages..."))

        val query = messagesCollectionForDesk(deskId)
            .orderBy("createdAt", Query.Direction.ASCENDING)

        val subscription = query.addSnapshotListener { snapshot: QuerySnapshot?, error ->
            if (error != null) {
                close(error)
                return@addSnapshotListener
            }
            if (snapshot != null) {
                val list = snapshot.documents.mapNotNull { doc ->
                    try {
                        val m = doc.toObject<Message>()
                        if (m != null) m.copy(id = doc.id) else null
                    } catch (t: Throwable) {
                        null
                    }
                }
                trySend(Resource.Success(list))
            }
        }

        awaitClose {
            subscription.remove()
        }
    }

    /**
     * Send a message.
     */
    suspend fun sendMessage(deskId: String, message: Message): Result<Message> {
        
        // Moderation check inserted automatically
        if (com.newton.deskchatapp.moderation.ProfanityFilter.containsProfanity(message)) {
            android.util.Log.w("ProfanityCheck", "Blocked message containing profanity")
            return
        }
return try {
            val col = messagesCollectionForDesk(deskId)
            val ref = col.add(message).await()
            val snapshot = ref.get().await()
            val posted = snapshot.toObject<Message>()?.copy(id = ref.id) ?: message.copy(id = ref.id)
            Result.success(posted)
        } catch (t: Throwable) {
            Result.failure(t)
        }
    }

    /**
     * Edit a message's text. Only updates allowed fields (text, editedAt, filteredText).
     */
    suspend fun editMessage(deskId: String, messageId: String, newText: String, filteredText: String? = null): Result<Unit> {
        return try {
            val docRef = messagesCollectionForDesk(deskId).document(messageId)
            val updateMap = mutableMapOf<String, Any?>(
                "text" to newText,
                "editedAt" to Timestamp.now()
            )
            if (filteredText != null) updateMap["filteredText"] = filteredText
            docRef.update(updateMap as Map<String, Any?>).await()
            Result.success(Unit)
        } catch (t: Throwable) {
            Log.w(TAG, "Failed to edit message", t)
            Result.failure(t)
        }
    }

    /**
     * Soft-delete a message by setting `deleted=true` and overwriting text to a placeholder.
     * Admins may delete the document entirely via Cloud Functions or admin SDK.
     */
    suspend fun softDeleteMessage(deskId: String, messageId: String): Result<Unit> {
        return try {
            val docRef = messagesCollectionForDesk(deskId).document(messageId)
            val updates = mapOf(
                "deleted" to true,
                "text" to "[message deleted]",
                "editedAt" to Timestamp.now()
            )
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (t: Throwable) {
            Log.w(TAG, "Failed to delete message", t)
            Result.failure(t)
        }
    }

    /**
     * Create a report document in `/moderation/reports/{id}`. Placeholder fields.
     */
    suspend fun reportMessage(deskId: String, messageId: String, reason: String): Result<Unit> {
        return try {
            val reports = db.collection("moderation").document()
            val payload = mapOf(
                "type" to "report",
                "deskId" to deskId,
                "messageId" to messageId,
                "reporterId" to auth.currentUser?.uid,
                "reason" to reason,
                "createdAt" to com.google.firebase.Timestamp.now()
            )
            reports.set(payload).await()
            Result.success(Unit)
        } catch (t: Throwable) {
            Log.w(TAG, "Failed to create report", t)
            Result.failure(t)
        }
    }
}