// File: app/src/main/java/com/newton/deskchatapp/fragments/chat/ChatFragment.kt
package com.newton.deskchatapp.fragments.chat

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.Timestamp
import com.newton.deskchatapp.R
import com.newton.deskchatapp.messages.MessagesRepository
import com.newton.deskchatapp.models.Message
import com.newton.deskchatapp.util.NetworkUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.android.synthetic.main.fragment_chat.*  // using synthetic imports for brevity; if you use ViewBinding replace accordingly

/**
 * New ChatFragment:
 * - Observes repository messages flow and displays using existing MessageAdapter
 * - Send-on-Enter (Enter sends, Shift+Enter inserts newline)
 * - Shows an offline banner when there's no connection
 * - On send failure shows retry SnackBar and restores text
 *
 * Assumptions:
 * - MessagesRepository provides:
 *      suspend fun sendMessage(deskId: String, message: Message): Result<Message>
 *      fun getMessages(deskId: String): kotlinx.coroutines.flow.Flow<com.newton.deskchatapp.util.Resource<List<Message>>>
 * - You have a MessageAdapter class that can be constructed (constructor used below).
 *
 * If you use ViewBinding or DataBinding replace the synthetic view use with your binding code.
 */
@AndroidEntryPoint
class ChatFragment : Fragment() {

    
        // Moderation check inserted automatically
        if (com.newton.deskchatapp.moderation.ProfanityFilter.containsProfanity(message)) {
            android.util.Log.w("ProfanityCheck", "Blocked message containing profanity")
            return
        }
@Inject
    lateinit var messagesRepository: MessagesRepository

    private lateinit var adapter: MessageAdapter
    private var currentDeskId: String = "" // Will be set from args or host Activity

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // If the host activity/args set a desk id, get it:
        currentDeskId = arguments?.getString(ARG_DESK_ID) ?: ""
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        // Inflate the existing fragment_chat layout (replace it earlier if you followed previous steps)
        return inflater.inflate(R.layout.fragment_chat, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        // RecyclerView setup
        adapter = MessageAdapter()
        recycler_chat.layoutManager = LinearLayoutManager(requireContext()).apply {
            stackFromEnd = true
        }
        recycler_chat.adapter = adapter

        // Wire up input send behaviour
        btn_send_message.setOnClickListener { onSendClicked() }

        // IME: Enter -> send, Shift+Enter -> newline
        et_message_input.setOnEditorActionListener { v, actionId, event ->
            // handle IME send action
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                onSendClicked()
                true
            } else {
                // handle hardware keyboard Enter key press
                if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN) {
                    if (event.isShiftPressed) {
                        // allow newline insertion
                        false
                    } else {
                        onSendClicked()
                        true
                    }
                } else {
                    false
                }
            }
        }

        // show/hide send button based on text presence
        et_message_input.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                btn_send_message.isEnabled = !s.isNullOrBlank()
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) { }
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { }
        })

        // Observe messages from repository
        if (currentDeskId.isNotBlank()) {
            observeMessages(currentDeskId)
        } else {
            // If host Activity will set desk id later, expose a method or use fragment args.
            // For now show a toast.
            Toast.makeText(requireContext(), getString(R.string.no_desk_selected), Toast.LENGTH_SHORT).show()
        }

        // Update offline UI on start
        updateConnectionUi()
    }

    private fun observeMessages(deskId: String) {
        lifecycleScope.launchWhenStarted {
            messagesRepository.getMessages(deskId).collectLatest { resource ->
                when (resource) {
                    is com.newton.deskchatapp.util.Resource.Loading -> {
                        progress_chat_loading?.isVisible = true
                    }
                    is com.newton.deskchatapp.util.Resource.Success -> {
                        progress_chat_loading?.isVisible = false
                        val list = resource.data ?: emptyList()
                        adapter.submitList(list) {
                            recycler_chat.post {
                                recycler_chat.smoothScrollToPosition(adapter.itemCount - 1)
                            }
                        }
                    }
                    is com.newton.deskchatapp.util.Resource.Error -> {
                        progress_chat_loading?.isVisible = false
                        Snackbar.make(requireView(), resource.message ?: getString(R.string.error_loading_messages), Snackbar.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    private fun onSendClicked() {
        val raw = et_message_input.text?.toString() ?: ""
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return

        // Optimistic UI: clear quickly
        et_message_input.setText("")
        updateConnectionUi()

        // Build message object (minimal fields required; adapt to your Message model)
        val msg = Message(
            id = UUID.randomUUID().toString(),
            deskId = currentDeskId,
            authorId = null, // repository / firebase will set author if needed (or set current user id here)
            text = trimmed,
            createdAt = Timestamp.now()
        )

        // Keep a local copy in case of failure so we can restore the text
        val previousText = raw

        // Send using repository off main dispatcher
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val res = messagesRepository.sendMessage(currentDeskId, msg)
                launch(Dispatchers.Main) {
                    if (res.isFailure) {
                        // Sending failed. Firestore offline persistence may queue, but repository reports failure.
                        Snackbar.make(requireView(), getString(R.string.error_sending_message), Snackbar.LENGTH_LONG)
                            .setAction(R.string.retry) {
                                et_message_input.setText(previousText)
                                et_message_input.setSelection(previousText.length)
                            }.show()
                    } else {
                        // success - repository/Firestore will propagate new message via getMessages flow
                        // optionally scroll is kept when messages flow emits
                    }
                }
            } catch (t: Throwable) {
                launch(Dispatchers.Main) {
                    Snackbar.make(requireView(), getString(R.string.error_sending_message), Snackbar.LENGTH_LONG)
                        .setAction(R.string.retry) {
                            et_message_input.setText(previousText)
                            et_message_input.setSelection(previousText.length)
                        }.show()
                }
            } finally {
                launch(Dispatchers.Main) {
                    updateConnectionUi()
                }
            }
        }
    }

    private fun updateConnectionUi() {
        val connected = NetworkUtils.hasInternetConnection(requireContext())
        error_state_container.isVisible = !connected
        // Optionally change message shown in error_text depending on connectivity
        // error_text.text = if (connected) "" else getString(R.string.no_connection)
    }

    /**
     * Public helper so host Activity can set the desk id if not provided via args.
     */
    fun setDeskId(deskId: String) {
        if (deskId == currentDeskId) return
        currentDeskId = deskId
        observeMessages(deskId)
    }

    companion object {
        private const val ARG_DESK_ID = "arg_desk_id"
        fun newInstance(deskId: String): ChatFragment {
            val f = ChatFragment()
            val b = Bundle()
            b.putString(ARG_DESK_ID, deskId)
            f.arguments = b
            return f
        }
    }
}
