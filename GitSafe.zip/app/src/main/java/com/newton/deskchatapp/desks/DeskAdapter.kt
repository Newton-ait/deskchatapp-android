package com.newton.deskchatapp.desks

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.newton.deskchatapp.R
import com.newton.deskchatapp.models.Desk
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

class DeskAdapter : ListAdapter<Desk, DeskAdapter.DeskViewHolder>(DeskDiffCallback()) {

    var onDeskClick: ((Desk) -> Unit)? = null
    var currentLocation: android.location.Location? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DeskViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_desk, parent, false)
        return DeskViewHolder(view)
    }

    override fun onBindViewHolder(holder: DeskViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class DeskViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvDeskName: TextView = itemView.findViewById(R.id.tvDeskName)
        private val tvDistance: TextView = itemView.findViewById(R.id.tvDistance)
        private val tvLocation: TextView = itemView.findViewById(R.id.tvLocation)
        private val tvMessageCount: TextView = itemView.findViewById(R.id.tvMessageCount)
        private val tvLastActivity: TextView = itemView.findViewById(R.id.tvLastActivity)
        private val tvActiveUsers: TextView = itemView.findViewById(R.id.tvActiveUsers)
        private val progressExpiration: LinearProgressIndicator =
            itemView.findViewById(R.id.progressExpiration)

        fun bind(desk: Desk) {
            // Desk Name
            tvDeskName.text = desk.name

            // Distance
            currentLocation?.let { userLocation ->
                val deskLocation = android.location.Location("desk").apply {
                    latitude = desk.location.latitude
                    longitude = desk.location.longitude
                }
                val distance = userLocation.distanceTo(deskLocation)
                tvDistance.text = formatDistance(distance)
            } ?: run {
                tvDistance.text = "Unknown distance"
            }

            // Location description
            tvLocation.text = getLocationDescription(desk.location)

            // Message Count
            tvMessageCount.text = "${desk.messageCount} messages"

            // Last Activity
            tvLastActivity.text = getTimeAgo(desk.lastActivity)

            // Active Users (simulated for now)
            val activeUsers = (1..5).random() // Replace with real data later
            tvActiveUsers.text = "$activeUsers active"

            // Expiration Progress (if desk is expiring soon)
            setupExpirationProgress(desk)

            // Click listener
            itemView.setOnClickListener {
                onDeskClick?.invoke(desk)
            }
        }

        private fun formatDistance(distance: Float): String {
            return when {
                distance < 1000 -> "${distance.roundToInt()}m away"
                else -> "${(distance / 1000).format(1)}km away"
            }
        }

        private fun Float.format(decimals: Int): String =
            "%.${decimals}f".format(this)

        private fun getLocationDescription(location: com.google.firebase.firestore.GeoPoint): String {
            val lat = location.latitude
            val lng = location.longitude

            return when {
                lat > 0.315 && lat < 0.316 && lng > 32.582 && lng < 32.584 -> "Main Campus"
                lat > 0.310 && lat < 0.312 -> "Library Area"
                lat > 0.320 && lat < 0.322 -> "Student Center"
                else -> "Campus Area"
            }
        }

        private fun getTimeAgo(timestamp: Date): String {
            val now = Date()
            val diff = now.time - timestamp.time
            val seconds = diff / 1000
            val minutes = seconds / 60
            val hours = minutes / 60

            return when {
                seconds < 60 -> "Just now"
                minutes < 60 -> "$minutes min ago"
                hours < 24 -> "$hours hr ago"
                else -> SimpleDateFormat("MMM dd", Locale.getDefault()).format(timestamp)
            }
        }

        private fun setupExpirationProgress(desk: Desk) {
            val now = Date()
            val deskLifetime = 24 * 60 * 60 * 1000L // 24 hours
            val deskAge = now.time - desk.createdAt.time
            val progress = (deskAge.toFloat() / deskLifetime * 100).coerceIn(0f, 100f)

            if (progress > 80) {
                progressExpiration.visibility = View.VISIBLE
                progressExpiration.progress = progress.toInt()

                val color = when {
                    progress > 95 -> R.color.expiration_critical
                    progress > 85 -> R.color.expiration_warning
                    else -> R.color.expiration_normal
                }
                progressExpiration.setIndicatorColor(
                    ContextCompat.getColor(itemView.context, color)
                )
            } else {
                progressExpiration.visibility = View.GONE
            }
        }
    }

    class DeskDiffCallback : DiffUtil.ItemCallback<Desk>() {
        override fun areItemsTheSame(oldItem: Desk, newItem: Desk): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Desk, newItem: Desk): Boolean {
            return oldItem == newItem
        }
    }
}