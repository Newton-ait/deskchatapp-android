package com.newton.deskchatapp

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import com.newton.deskchatapp.ui.ChatScreen
import com.newton.deskchatapp.ui.theme.ChatTheme

@RunWith(AndroidJUnit4::class)
class ChatScreenUITest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun chatScreen_shouldDisplayMessages() {
        composeTestRule.setContent {
            ChatTheme {
                ChatScreen(
                    conversationId = "test_conv",
                    viewModel = FakeChatViewModel()
                )
            }
        }

        composeTestRule.onNodeWithText("Test message").assertExists()
        composeTestRule.onNodeWithContentDescription("Send message").assertExists()
    }

    @Test
    fun sendMessage_shouldClearInput() {
        composeTestRule.setContent {
            ChatTheme {
                ChatScreen(
                    conversationId = "test_conv",
                    viewModel = FakeChatViewModel()
                )
            }
        }

        composeTestRule.onNodeWithContentDescription("Message input")
            .performTextInput("Hello World")
        composeTestRule.onNodeWithContentDescription("Send message").performClick()
        composeTestRule.onNodeWithText("Hello World").assertDoesNotExist()
    }
}

// Fake viewmodel for UI tests
class FakeChatViewModel : androidx.lifecycle.ViewModel() {
    // Provide the minimal functions and states used by ChatScreen
}