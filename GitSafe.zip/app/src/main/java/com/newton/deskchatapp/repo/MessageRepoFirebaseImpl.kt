package com.newton.deskchatapp.repo

import com.newton.deskchatapp.cloud.FirebaseDataSource
import com.newton.deskchatapp.model.Message
import com.newton.deskchatapp.util.Result
import kotlinx.coroutines.flow.Flow

class MessageRepoFirebaseImpl(private val source: FirebaseDataSource = FirebaseDataSource()) : IMessageRepo {
    override suspend fun sendMessage(message: Message): Result<Unit> = source.sendMessage(message)
    override fun listenForMessages(): Flow<List<Message>> = source.listenForMessages()
    override suspend fun deleteMessage(id: String): Result<Unit> = source.deleteMessage(id)
    override suspend fun markSynced(id: String) { /* no-op */ }
}
