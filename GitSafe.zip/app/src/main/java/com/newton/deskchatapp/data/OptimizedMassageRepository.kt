package com.newton.deskchatapp.data

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton
import com.newton.deskchatapp.util.PerformanceMonitor
import com.newton.deskchatapp.models.Message
import com.newton.deskchatapp.util.Resource

@Singleton
class OptimizedMessageRepository @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val performanceMonitor: PerformanceMonitor
) {
    // Simple in-memory cache per conversation
    private val messagesCache = mutableMapOf<String, List<Message>>()

    suspend fun getMessagesOptimized(conversationId: String): Resource<List<Message>> {
        val trace = performanceMonitor.startTrace("get_messages_$conversationId")
        return try {
            messagesCache[conversationId]?.let { cached ->
                trace.putMetric("cache_hit", 1)
                return Resource.Success(cached)
            }
            trace.putMetric("cache_miss", 1)
            val snapshot = firestore.collection("messages")
                .whereEqualTo("conversationId", conversationId)
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .limit(50)
                .get()
                .await()

            val messages = snapshot.documents.mapNotNull { doc ->
                try {
                    doc.toObject(Message::class.java)?.copy(id = doc.id)
                } catch (e: Exception) {
                    null
                }
            }
            messagesCache[conversationId] = messages
            Resource.Success(messages)
        } catch (e: Exception) {
            Resource.Error("Failed to load messages: ${e.message}", e)
        } finally {
            trace.stop()
        }
    }

    fun clearCache(conversationId: String? = null) {
        if (conversationId == null) messagesCache.clear() else messagesCache.remove(conversationId)
    }
}