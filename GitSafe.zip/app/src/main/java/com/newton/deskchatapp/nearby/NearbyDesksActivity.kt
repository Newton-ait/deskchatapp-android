package com.newton.deskchatapp.nearby

import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.GeoPoint
import com.newton.deskchatapp.R
import com.newton.deskchatapp.desk.DeskManager
import com.newton.deskchatapp.location.LocationManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

@AndroidEntryPoint
class NearbyDesksActivity : AppCompatActivity() {

    @Inject lateinit var locationManager: LocationManager
    @Inject lateinit var deskManager: DeskManager

    private lateinit var adapter: NearbyDeskAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var loading: ProgressBar
    private lateinit var emptyState: TextView
    private lateinit var errorState: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_nearby_desks)

        adapter = NearbyDeskAdapter()

        recyclerView = findViewById(R.id.recyclerNearbyDesks)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        loading = findViewById(R.id.nearbyLoading)
        emptyState = findViewById(R.id.nearbyEmpty)
        errorState = findViewById(R.id.nearbyError)

        loadNearbyDesks()
    }

    private fun loadNearbyDesks() {
        loading.visibility = View.VISIBLE
        errorState.visibility = View.GONE
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val location = withContext(Dispatchers.IO) { locationManager.getCurrentLocation() }
                val result = withContext(Dispatchers.IO) {
                    deskManager.getNearbyDesks(GeoPoint(location.latitude, location.longitude), radiusInMeters = 1000.0)
                }
                result.onSuccess { desks ->
                    loading.visibility = View.GONE
                    adapter.submitList(desks)
                    emptyState.visibility = if (desks.isEmpty()) View.VISIBLE else View.GONE
                }.onFailure { ex ->
                    loading.visibility = View.GONE
                    errorState.visibility = View.VISIBLE
                    errorState.text = getString(R.string.error_loading, ex.message ?: "unknown")
                }
            } catch (e: Exception) {
                loading.visibility = View.GONE
                errorState.visibility = View.VISIBLE
                errorState.text = getString(R.string.error_loading, e.message ?: "unknown")
            }
        }
    }
}
