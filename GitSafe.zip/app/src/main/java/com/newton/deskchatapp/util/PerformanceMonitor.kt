package com.newton.deskchatapp.util

import android.content.Context
import com.google.firebase.perf.FirebasePerformance
import com.google.firebase.perf.metrics.Trace
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.delay

@Singleton
class PerformanceMonitor @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val firebasePerf: FirebasePerformance = FirebasePerformance.getInstance()

    fun startTrace(traceName: String): Trace {
        val trace = firebasePerf.newTrace(traceName)
        trace.start()
        return trace
    }

    suspend fun measureMessageLoadTime(conversationId: String, loader: suspend () -> Unit): Long {
        val trace = startTrace("message_load_$conversationId")
        return try {
            val startTime = System.currentTimeMillis()
            loader()
            System.currentTimeMillis() - startTime
        } finally {
            trace.stop()
        }
    }

    fun logScreenRenderTime(screenName: String, renderTimeMs: Long) {
        val trace = startTrace("screen_render_$screenName")
        trace.putMetric("render_time_ms", renderTimeMs)
        trace.stop()
    }
}