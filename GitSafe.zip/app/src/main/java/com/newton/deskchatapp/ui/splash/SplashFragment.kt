package com.newton.deskchatapp.ui.splash

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import com.newton.deskchatapp.databinding.FragmentSplashBinding
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * SplashFragment - lifecycle-aware view binding and safe coroutine usage.
 */
class SplashFragment : Fragment() {

    private var _binding: FragmentSplashBinding? = null
    // Provide a clearer error message rather than using "?: throw IllegalStateException("Non-null assertion replaced to avoid NPE in app/src/main/java/com/newton/deskchatapp/ui/splash/SplashFragment.kt")"
    private val binding get() = requireNotNull(_binding) { "FragmentSplashBinding is only valid between onCreateView and onDestroyView." }

    private val viewModel: SplashViewModel by viewModels() // if you have one

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentSplashBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Example safe coroutine usage: do splash delay without blocking UI thread
        lifecycleScope.launch {
            // show loading UI or animate
            delay(800L)
            // navigate to next screen or trigger viewModel action
            // e.g. findNavController().navigate(R.id.action_splash_to_main)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        // Avoid leaks by clearing _binding in onDestroyView
        _binding = null
    }
}