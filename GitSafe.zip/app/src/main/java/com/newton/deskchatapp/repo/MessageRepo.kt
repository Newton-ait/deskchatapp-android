package com.newton.deskchatapp.repo

import android.content.Context
import com.newton.deskchatapp.db.DeskDatabase
import com.newton.deskchatapp.db.entity.DeskMessage
import com.newton.deskchatapp.nearby.bluetooth.BluetoothRepo
import com.newton.deskchatapp.net.NetworkRepo
import com.newton.deskchatapp.cloud.FirebaseDataSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.util.UUID

class MessageRepo(private val context: Context) {

    suspend fun insertLocal(msg: com.newton.deskchatapp.db.entity.DeskMessage) {
        withContext(Dispatchers.IO) { dao.insert(msg) }
    }

    private val db = DeskDatabase.getInstance(context)
    private val dao = db.deskMessageDao()
    private val bluetooth = BluetoothRepo(context)
    private val network = NetworkRepo(context)
    private val firebase = FirebaseDataSource()

    suspend fun postMessage(text: String?, cellHash: String, ttlMs: Long = 48L*60L*60L*1000L): DeskMessage {
        // Bluetooth-first: if nearby scanning is active (we rely on NetworkRepo for online/offline)
        val msg = DeskMessage(
            id = UUID.randomUUID().toString(),
            text = text,
            cellHash = cellHash,
            timestamp = System.currentTimeMillis(),
            anonToken = generateAnonToken(),
            synced = false,
            ttlMs = ttlMs
        )
        withContext(Dispatchers.IO) {
            dao.insert(msg)
        }
        // If network available, push to firebase
        if (network.isOnline()) {
            val payload = mapOf(
                "id" to msg.id,
                "text" to (msg.text ?: ""),
                "cellHash" to msg.cellHash,
                "timestamp" to msg.timestamp,
                "ttlMs" to msg.ttlMs
            )
            val ok = firebase.pushDeskMessage("desks_ephemeral", payload)
            if (ok) {
                val synced = msg.copy(synced = true)
                withContext(Dispatchers.IO) { dao.insert(synced) }
            }
        } else {
            // Broadcast locally via Bluetooth short message
            // Keep message short when broadcasting via BLE: include id and short text
            val broadcast = "id:${msg.id};cell:${msg.cellHash};t:${(msg.text ?: "").take(80)}"
            bluetooth.broadcastShortMessage(broadcast)
        }
        return msg
    }

    private fun generateAnonToken(): String {
        return UUID.randomUUID().toString().substring(0,8)
    }

    suspend fun getNearby(cell: String): List<DeskMessage> {
        return withContext(Dispatchers.IO) { dao.getByCell(cell) }
    }

    suspend fun expireOldMessages(): Int {
        val cutoff = System.currentTimeMillis() - (48L*60L*60L*1000L)
        return withContext(Dispatchers.IO) { dao.deleteOlderThan(cutoff) }
    }

    // Sync unsynced local messages to firebase (call on connectivity restore)
    suspend fun syncLocalToCloud() {
        val unsynced = withContext(Dispatchers.IO) {
            // Simple query: we don't have dedicated flag query; pull all and filter
            dao.getAll() /* replaced wildcard call: implement proper query */ // ROOM SQL wildcard not supported here; for brevity pull empty
            listOf<DeskMessage>()
        }
        // TODO: implement proper unsynced query and push to firebase
    }

fun observeMessages(cell: String): Flow<List<com.newton.deskchatapp.db.entity.DeskMessage>> {
    return dao.observeByCell(cell)
}

fun observeAllMessages(): Flow<List<com.newton.deskchatapp.db.entity.DeskMessage>> {
    return dao.observeAll()
}

}
