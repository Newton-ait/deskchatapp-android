package com.newton.deskchatapp.nearby.bluetooth

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch

/**
 * NEW: Desk layer - BluetoothRepo
 * High-level coroutine-friendly wrapper over BluetoothManager.
 */
class BluetoothRepo(context: Context) {
    private val manager = BluetoothManager(context)
    private val _incoming = MutableSharedFlow<BluetoothManager.NearbyAdvert>(replay = 16)
    val incoming: SharedFlow<BluetoothManager.NearbyAdvert> = _incoming.asSharedFlow()

    fun startNearby() {
        manager.startScan()
        // collect manager.received and re-emit - using a coroutine scope
        CoroutineScope(Dispatchers.IO).launch {
            manager.received.collect { advert ->
                _incoming.emit(advert)
            }
        }
    }

    fun stopNearby() {
        manager.stopScan()
    }

    fun broadcastShortMessage(text: String) {
        manager.startAdvertising(text)
        // We could advertise briefly then stop after some time; leave control to caller.
    }

    fun stopBroadcast() {
        manager.stopAdvertising()
    }
}
