package com.newton.deskchatapp.workers

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.newton.deskchatapp.messages.MessageManager

/**
 * Worker that invokes MessageManager.cleanupExpiredMessages() and returns success/failure.
 * Replace/adjust package imports if your MessageManager is in a different package.
 */
class ExpiredMessagesWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    companion object {
        private const val TAG = "ExpiredMessagesWorker"
    }

    override suspend fun doWork(): Result {
        try {
            Log.d(TAG, "ExpiredMessagesWorker started")
            val mgr = MessageManager() // Ensure MessageManager has a no-arg constructor or adapt DI
            val res = mgr.cleanupExpiredMessages()
            return if (res.isSuccess) {
                Log.d(TAG, "ExpiredMessagesWorker success: deleted ${res.getOrNull()}")
                Result.success()
            } else {
                Log.w(TAG, "ExpiredMessagesWorker returned failure result, will retry")
                Result.retry()
            }
        } catch (e: Exception) {
            Log.e(TAG, "ExpiredMessagesWorker exception: ${e.message}", e)
            return Result.retry()
        }
    }
}
