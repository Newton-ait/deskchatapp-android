package com.newton.deskchatapp.nearby.location

object GeoGrid {
    // Simple coarse grid: 100m approximate by truncating lat/lon to ~0.001 degrees (~111m)
    fun cellId(lat: Double, lon: Double): String {
        val latKey = (lat * 1000).toInt() // truncates to ~0.001 deg
        val lonKey = (lon * 1000).toInt()
        return "cell_${latKey}_${lonKey}"
    }
}
