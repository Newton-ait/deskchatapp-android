package com.newton.deskchatapp.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.newton.deskchatapp.db.entity.DeskMessage

@Dao
interface DeskMessageDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(message: DeskMessage)

    @Query("""SELECT * FROM desk_messages WHERE cellHash = :cell ORDER BY timestamp DESC""")
    suspend fun getByCell(cell: String): List<DeskMessage>

    @Query("""DELETE FROM desk_messages WHERE timestamp < :cutoff""")
    suspend fun deleteOlderThan(cutoff: Long): Int
}
