package com.newton.deskchatapp.ui.screens

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.newton.deskchatapp.R

class ChatActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
