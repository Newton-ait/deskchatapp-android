
package com.newton.deskchatapp.map

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.newton.deskchatapp.R
import com.newton.deskchatapp.nearby.NearbyDesksActivity

class MapActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map)
        // Placeholder: Launch Nearby list
        findViewById<Button>(R.id.btnOpenNearby).setOnClickListener {
            startActivity(Intent(this, NearbyDesksActivity::class.java))
        }
    }
}
