package com.newton.deskchatapp.messages

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.newton.deskchatapp.R
import com.newton.deskchatapp.models.Message
import java.text.SimpleDateFormat
import java.util.*

class MessageAdapter(
    private val currentUserId: String?
) : ListAdapter<Message, MessageAdapter.VH>(Diff()) {

    var onEditRequested: ((Message) -> Unit)? = null
    var onDeleteRequested: ((Message) -> Unit)? = null
    var onReportRequested: ((Message) -> Unit)? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_message, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.bind(getItem(position))
    }

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        private val tvMessage: TextView = view.findViewById(R.id.tvMessage)
        private val tvTimestamp: TextView = view.findViewById(R.id.tvTimestamp)
        private val tvExpiry: TextView? = view.findViewById(R.id.tvExpiry)

        fun bind(m: Message) {
            // show filteredText if present
            val displayText = when {
                m.deleted -> "[message deleted]"
                !m.filteredText.isNullOrBlank() -> m.filteredText
                else -> m.text
            }
            tvMessage.text = displayText

            val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
            val ts = m.createdAt?.toDate()
            tvTimestamp.text = if (ts != null) sdf.format(ts) else ""

            tvExpiry?.text = m.expiresAt?.let { exp ->
                val e = exp.toDate()
                val now = Date()
                if (e.before(now)) "expired" else "expires ${SimpleDateFormat("MM/dd HH:mm", Locale.getDefault()).format(e)}"
            } ?: ""

            // Long press to show moderation options
            itemView.setOnLongClickListener {
                val isMine = m.authorId == currentUserId
                val options = mutableListOf<String>()
                if (isMine && !m.deleted) {
                    options.add(itemView.context.getString(R.string.action_edit))
                    options.add(itemView.context.getString(R.string.action_delete))
                } else if (!isMine) {
                    options.add(itemView.context.getString(R.string.action_report))
                }

                if (options.isEmpty()) return@setOnLongClickListener true

                AlertDialog.Builder(itemView.context)
                    .setTitle(itemView.context.getString(R.string.message_actions))
                    .setItems(options.toTypedArray()) { _, which ->
                        when (options[which]) {
                            itemView.context.getString(R.string.action_edit) -> onEditRequested?.invoke(m)
                            itemView.context.getString(R.string.action_delete) -> onDeleteRequested?.invoke(m)
                            itemView.context.getString(R.string.action_report) -> onReportRequested?.invoke(m)
                        }
                    }
                    .show()

                true
            }
        }
    }

    class Diff : DiffUtil.ItemCallback<Message>() {
        override fun areItemsTheSame(oldItem: Message, newItem: Message): Boolean =
            oldItem.id == newItem.id

        override fun areContentsTheSame(oldItem: Message, newItem: Message): Boolean =
            oldItem == newItem
    }
}
