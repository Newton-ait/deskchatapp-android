package com.newton.deskchatapp.messages

import com.newton.deskchatapp.models.Message
import com.newton.deskchatapp.util.Resource
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertTrue
import org.junit.Test
import org.mockito.Mockito
import kotlin.test.assertEquals

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModelTest {
    @Test
    fun loadMessages_sets_state() = runTest {
        val mockRepo = Mockito.mock(MessageRepository::class.java)
        val dummy = listOf(Message(id="1", deskId="desk1", authorId="a", text="x"))
        Mockito.`when`(mockRepo.getMessages(Mockito.anyString()))
            .thenReturn(flowOf(Resource.Success(dummy)))
        val vm = ChatViewModel(mockRepo)
        vm.loadMessages("desk1")
        assertTrue(vm.messagesState.value is Resource.Success)
    }

    @Test
    fun sendMessage_noDesk_shows_error() = runTest {
        val mockRepo = Mockito.mock(MessageRepository::class.java)
        val vm = ChatViewModel(mockRepo)
        vm.sendMessage("hello")
        val ui = vm.uiState.value
        assertTrue(ui is ChatUiState.Error)
        assertEquals("No desk selected", (ui as ChatUiState.Error).message)
    }
}