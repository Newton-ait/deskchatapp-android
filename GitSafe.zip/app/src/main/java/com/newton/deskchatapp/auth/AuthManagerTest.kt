package com.newton.deskchatapp.auth

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.mockito.Mockito

class AuthManagerTest {
    @Test
    fun currentUser_returns_expected() {
        val mockAuth = Mockito.mock(FirebaseAuth::class.java)
        val mockUser = Mockito.mock(FirebaseUser::class.java)
        Mockito.`when`(mockAuth.currentUser).thenReturn(mockUser)
        val manager = AuthManager(mockAuth)
        assertEquals(mockUser, manager.currentUser())
    }

    @Test
    fun getOrCreateUserUid_returns_failure_if_no_user() = runBlocking {
        val mockAuth = Mockito.mock(FirebaseAuth::class.java)
        Mockito.`when`(mockAuth.currentUser).thenReturn(null)
        val manager = AuthManager(mockAuth)
        val result = manager.getOrCreateUserUid()
        assertTrue(result.isFailure)
    }
}