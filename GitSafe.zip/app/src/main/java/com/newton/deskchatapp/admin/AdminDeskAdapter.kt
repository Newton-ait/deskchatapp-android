
package com.newton.deskchatapp.admin

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.newton.deskchatapp.R
import com.newton.deskchatapp.models.Desk

class AdminDeskAdapter(private val desks: List<Desk>) : RecyclerView.Adapter<AdminDeskAdapter.VH>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(android.R.layout.simple_list_item_2, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val d = desks[position]
        holder.title.text = d.name
        holder.subtitle.text = "Reports: ${d.reports ?: 0} • Active: ${d.active}"
    }

    override fun getItemCount(): Int = desks.size

    class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title: TextView = itemView.findViewById(android.R.id.text1)
        val subtitle: TextView = itemView.findViewById(android.R.id.text2)
    }
}
