package com.newton.deskchatapp.models

import com.google.firebase.Timestamp
import com.google.firebase.firestore.GeoPoint

/**
 * Message model stored in Firestore. Extra nullable fields are OK if server functions add them.
 */
data class Message(
    val id: String = "",
    val deskId: String = "",
    val authorId: String? = null,
    val text: String = "",
    val location: GeoPoint? = null,
    val createdAt: Timestamp? = null,
    val expiresAt: Timestamp? = null,
    val flagged: Boolean = false,
    val filteredText: String? = null,
    val profanityScore: Int? = null,
    val deleted: Boolean = false,
    val editedAt: Timestamp? = null
)
