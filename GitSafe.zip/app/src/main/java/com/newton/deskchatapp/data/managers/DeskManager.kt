package com.newton.deskchatapp.data.managers

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.GeoPoint
import com.newton.deskchatapp.models.CreateDeskRequest
import com.newton.deskchatapp.models.Desk
import kotlinx.coroutines.tasks.await
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DeskManager @Inject constructor(
    private val db: FirebaseFirestore
) {
    private val desksCollection = db.collection("desks")

    suspend fun createDesk(request: CreateDeskRequest): Result<Desk> {
        return try {
            val now = Date()
            val desk = Desk(
                id = UUID.randomUUID().toString(),
                name = request.name,
                description = request.description,
                location = request.location,
                createdBy = request.createdBy,
                createdAt = now,
                lastActivity = now,
                messageCount = 0,
                isActive = true,
                maxRadius = request.maxRadius,
                isPublic = request.isPublic
            )
            desksCollection.document(desk.id).set(desk).await()
            Result.success(desk)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getDesksNearLocation(center: GeoPoint, radiusInMeters: Double): Result<List<Desk>> {
        return try {
            val snapshot = desksCollection
                .whereEqualTo("isActive", true)
                .whereEqualTo("isPublic", true)
                .get()
                .await()

            val desks = snapshot.documents.mapNotNull { doc ->
                try {
                    doc.toObject(Desk::class.java)?.copy(id = doc.id)
                } catch (_: Exception) {
                    null
                }
            }

            val nearby = desks.filter {
                val distance = calculateDistance(
                    center.latitude, center.longitude,
                    it.location.latitude, it.location.longitude
                )
                distance <= radiusInMeters
            }

            Result.success(nearby)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun calculateDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val earthRadius = 6371000.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) *
                Math.cos(Math.toRadians(lat2)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        return earthRadius * c
    }
}