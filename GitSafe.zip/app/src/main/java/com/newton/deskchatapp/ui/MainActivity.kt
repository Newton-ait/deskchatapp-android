package com.newton.deskchatapp.ui

import android.Manifest
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.newton.deskchatapp.R
import com.newton.deskchatapp.cloud.AuthManager
import com.newton.deskchatapp.local.AppDatabase
import com.newton.deskchatapp.model.Message
import com.newton.deskchatapp.repo.MessageRepoHybrid
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import timber.log.Timber

class MainActivity : AppCompatActivity() {
    private lateinit var adapter: MessageAdapter
    private lateinit var repo: MessageRepoHybrid
    private lateinit var recycler: RecyclerView
    private lateinit var etMessage: EditText
    private lateinit var btnSend: ImageButton

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Timber.i("DeskChat UI started")

        recycler = findViewById(R.id.recyclerMessages)
        etMessage = findViewById(R.id.etMessage)
        btnSend = findViewById(R.id.btnSend)

        adapter = MessageAdapter(emptyList())
        recycler.adapter = adapter
        recycler.layoutManager = LinearLayoutManager(this)

        val db = Room.databaseBuilder(this, AppDatabase::class.java, "deskchat.db").build()
        repo = MessageRepoHybrid(this, db.messageDao())

        permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))

        observeMessages()
        setupSend()
    }

    private fun observeMessages() {
        lifecycleScope.launch {
            repo.listenForMessages().collectLatest { messages ->
                adapter.update(messages)
                if (messages.isNotEmpty()) recycler.scrollToPosition(messages.size - 1)
            }
        }
    }

    private fun setupSend() {
        btnSend.setOnClickListener {
            val text = etMessage.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener
            lifecycleScope.launch {
                val user = AuthManager().signInAnonymously()
                val msg = Message(senderId = user.uid, text = text)
                repo.sendMessage(msg)
                etMessage.text.clear()
            }
        }
    }
}
