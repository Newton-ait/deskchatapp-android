package com.newton.deskchatapp.messages

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.newton.deskchatapp.R
import com.newton.deskchatapp.auth.AuthManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class ChatActivity : AppCompatActivity() {

    private val viewModel: ChatViewModel by viewModels()

    private lateinit var recyclerMessages: RecyclerView
    private lateinit var inputMessage: EditText
    private lateinit var buttonSend: Button
    private lateinit var adapter: MessageAdapter

    // Desk identification passed via intent extras
    private lateinit var deskId: String
    private lateinit var deskName: String

    @Inject
    lateinit var authManager: AuthManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat) // ensure this layout exists and has expected ids

        // read intent extras
        deskId = intent.getStringExtra("DESK_ID") ?: run {
            finish()
            return
        }
        deskName = intent.getStringExtra("DESK_NAME") ?: "Desk"

        recyclerMessages = findViewById(R.id.recyclerMessages)
        inputMessage = findViewById(R.id.inputMessage)
        buttonSend = findViewById(R.id.buttonSend)

        adapter = MessageAdapter()
        recyclerMessages.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        recyclerMessages.adapter = adapter

        setupObservers()

        viewModel.startListening(deskId)

        buttonSend.setOnClickListener {
            val text = inputMessage.text.toString().trim()
            if (text.isNotEmpty()) {
                viewModel.sendMessage(text)
                inputMessage.text.clear()
            }
        }
    }

    private fun setupObservers() {
        lifecycleScope.launch {
            viewModel.messages.collectLatest { list ->
                adapter.submitList(list)
                // set current user id for adapter styling
                adapter.currentUserId = authManager.getUserId() ?: "anonymous"
                recyclerMessages.post {
                    recyclerMessages.smoothScrollToPosition(adapter.itemCount - 1)
                }
            }
        }

        lifecycleScope.launch {
            viewModel.isLoading.collectLatest { isLoading ->
                // you may have a progress view; for now we just show/hide send button
                buttonSend.isEnabled = !isLoading
            }
        }

        lifecycleScope.launch {
            viewModel.errorMessage.collectLatest { err ->
                err?.let { android.widget.Toast.makeText(this@ChatActivity, it, android.widget.Toast.LENGTH_SHORT).show() }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        viewModel.stopListening()
    }
}
