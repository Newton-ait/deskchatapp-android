package com.newton.deskchatapp.repo

import com.newton.deskchatapp.local.MessageDao
import com.newton.deskchatapp.model.Message
import com.newton.deskchatapp.util.Result
import kotlinx.coroutines.flow.Flow

class MessageRepoRoomImpl(private val dao: MessageDao) : IMessageRepo {
    override suspend fun sendMessage(message: Message): Result<Unit> {
        dao.insertMessage(message.copy(isSynced = false))
        return Result.Success(Unit)
    }
    override fun listenForMessages(): Flow<List<Message>> = dao.getAllMessages()
    override suspend fun deleteMessage(id: String): Result<Unit> {
        dao.deleteMessage(Message(id = id))
        return Result.Success(Unit)
    }
    override suspend fun markSynced(id: String) { dao.markSynced(id, true) }
}
