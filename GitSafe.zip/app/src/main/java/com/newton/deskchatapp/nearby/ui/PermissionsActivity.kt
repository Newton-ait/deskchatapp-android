package com.newton.deskchatapp.nearby.ui

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.newton.deskchatapp.nearby.PermissionsHelper

class PermissionsActivity : AppCompatActivity() {
    private val requestPerms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        // After permissions are granted or denied, simply finish; Nearby screen should handle lack of permissions gracefully
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val perms = PermissionsHelper.requiredBluetoothPermissions.toMutableList()
        perms.addAll(PermissionsHelper.locationPermissions)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // Possibly request Bluetooth connect/scan etc
        }
        requestPerms.launch(perms.toTypedArray())
    }
}
