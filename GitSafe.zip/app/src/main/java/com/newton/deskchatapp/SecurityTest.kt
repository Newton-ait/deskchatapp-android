package com.newton.deskchatapp

import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Test
import org.junit.runner.RunWith
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.runBlocking
import kotlin.test.fail
import com.google.firebase.firestore.FirebaseFirestoreException
import org.junit.Assert.assertEquals

@RunWith(AndroidJUnit4::class)
class SecurityTest {

    @Test
    fun unauthenticatedUser_cannotReadMessages() = runBlocking {
        val db = FirebaseFirestore.getInstance()
        try {
            db.collection("messages").get().await()
            fail("Unauthenticated user should not be able to read messages")
        } catch (e: Exception) {
            // This test assumes your emulator/test harness enforces rules and will throw
            // If using the Firebase Emulator, assert the permission denial behavior
            if (e is FirebaseFirestoreException) {
                assertEquals("PERMISSION_DENIED", e.code.toString())
            }
        }
    }

    // Add more rule tests adapted to your test setup (emulator / integration harness)
}