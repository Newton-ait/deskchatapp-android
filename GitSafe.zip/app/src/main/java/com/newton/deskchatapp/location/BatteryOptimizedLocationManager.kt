package com.newton.deskchatapp.location

import android.annotation.SuppressLint
import android.content.Context
import com.google.android.gms.location.*
import com.google.firebase.firestore.GeoPoint
import kotlinx.coroutines.suspendCancellableCoroutine
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import dagger.hilt.android.qualifiers.ApplicationContext

/**
 * Battery-optimized location provider: attempts to obtain a fresh location using balanced power
 * accuracy, falling back to last known location. Use this when you want to reduce battery usage.
 */
@Singleton
class BatteryOptimizedLocationManager @Inject constructor(
    @ApplicationContext context: Context
) : LocationManager(context) {

    private val fusedClient: FusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(context)

    private val locationRequest: LocationRequest = LocationRequest.Builder(Priority.PRIORITY_BALANCED_POWER_ACCURACY, 5000)
        .setMinUpdateIntervalMillis(2000)
        .setMaxUpdates(1)
        .build()

    @SuppressLint("MissingPermission")
    override suspend fun getCurrentLocation(): Result<GeoPoint> {
        return try {
            // Try last known first
            val last = fusedClient.lastLocation.await()
            if (last != null) {
                return Result.success(GeoPoint(last.latitude, last.longitude))
            }

            // Otherwise request a single location update (battery optimized)
            suspendCancellableCoroutine { cont ->
                val callback = object : LocationCallback() {
                    override fun onLocationResult(result: LocationResult) {
                        val loc = result.lastLocation
                        if (!cont.isCompleted) cont.resume(Result.success(GeoPoint(loc.latitude, loc.longitude)))
                        try { fusedClient.removeLocationUpdates(this) } catch (_: Exception) {
        android.util.Log.w("BatteryOptimizedLocationManager", "Caught exception in BatteryOptimizedLocationManager.kt: ", _)
    }
                    }

                    override fun onLocationAvailability(avail: LocationAvailability) {
                        if (!avail.isLocationAvailable && !cont.isCompleted) {
                            cont.resumeWithException(Exception("Location not available"))
                        }
                    }
                }

                fusedClient.requestLocationUpdates(locationRequest, callback, null).addOnFailureListener { exc ->
                    if (!cont.isCompleted) cont.resumeWithException(exc)
                }

                cont.invokeOnCancellation {
                    try { fusedClient.removeLocationUpdates(callback) } catch (_: Exception) {
        android.util.Log.w("BatteryOptimizedLocationManager", "Caught exception in BatteryOptimizedLocationManager.kt: ", _)
    }
                }
            }
        } catch (t: Throwable) {
            Result.failure(t)
        }
    }
}