package com.newton.deskchatapp.cloud

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.newton.deskchatapp.model.Message
import com.newton.deskchatapp.util.Result
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import timber.log.Timber

class FirebaseDataSource(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {

    suspend fun sendMessage(message: Message): Result<Unit> = try {
        db.collection("messages").document(message.id).set(message.toMap()).await()
        Timber.i("Message sent to Firestore: ${'$'}{message.id}")
        Result.Success(Unit)
    } catch (e: Exception) {
        Timber.e(e, "Failed to send message")
        Result.Error(e)
    }

    fun listenForMessages(): Flow<List<Message>> = callbackFlow {
        val listener = db.collection("messages")
            .orderBy("timestamp", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Timber.e(error, "Firestore listener error")
                    trySend(emptyList())
                } else if (snapshot != null) {
                    val messages = snapshot.documents.mapNotNull { doc ->
                        doc.data?.let { Message.fromMap(it) }
                    }
                    trySend(messages)
                }
            }

        awaitClose { listener.remove() }
    }

    suspend fun deleteMessage(id: String): Result<Unit> = try {
        db.collection("messages").document(id).delete().await()
        Timber.i("Message deleted: ${'$'}id")
        Result.Success(Unit)
    } catch (e: Exception) {
        Result.Error(e)
    }
}
