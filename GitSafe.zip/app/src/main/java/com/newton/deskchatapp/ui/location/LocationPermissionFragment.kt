package com.newton.deskchatapp.ui.location

import android.Manifest
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import com.newton.deskchatapp.databinding.FragmentLocationPermissionBinding

/**
 * LocationPermissionFragment - uses view binding safely and a modern ActivityResult launcher for permissions.
 */
class LocationPermissionFragment : Fragment() {

    private var _binding: FragmentLocationPermissionBinding? = null
    private val binding get() = requireNotNull(_binding) { "FragmentLocationPermissionBinding is only valid between onCreateView and onDestroyView." }

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            onLocationPermissionGranted()
        } else {
            onLocationPermissionDenied()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentLocationPermissionBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnRequestPermission.setOnClickListener {
            requestPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    private fun onLocationPermissionGranted() {
        // proceed with location-based flow
    }

    private fun onLocationPermissionDenied() {
        // show rationale or alternative flow
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}