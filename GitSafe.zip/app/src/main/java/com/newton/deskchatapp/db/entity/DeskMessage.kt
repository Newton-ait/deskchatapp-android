package com.newton.deskchatapp.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "desk_messages")
data class DeskMessage(
    @PrimaryKey val id: String,
    val text: String?,
    val cellHash: String,
    val timestamp: Long,
    val anonToken: String,
    val synced: Boolean = false,
    val ttlMs: Long = 48L * 60L * 60L * 1000L // default 48h
)
