package com.newton.deskchatapp.messages

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MessageExpirationManager(
    private val context: Context,
    private val workManager: WorkManager
) {
    fun schedulePeriodicCleanup() {
        val work = PeriodicWorkRequestBuilder<MessageCleanupWorker>(24, TimeUnit.HOURS)
            .build()
        workManager.enqueueUniquePeriodicWork(
            "message_cleanup",
            ExistingPeriodicWorkPolicy.REPLACE,
            work
        )
    }

    fun cancelPeriodicCleanup() {
        workManager.cancelUniqueWork("message_cleanup")
    }
}