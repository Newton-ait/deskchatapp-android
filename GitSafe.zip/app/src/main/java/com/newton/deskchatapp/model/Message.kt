package com.newton.deskchatapp.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "messages")
data class Message(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val senderId: String = "",
    val senderName: String = "Anonymous",
    val text: String = "",
    val latitude: Double? = null,
    val longitude: Double? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val isAnonymous: Boolean = false,
    val isSynced: Boolean = false,
    val expiryTimestamp: Long? = null
) {
    fun toMap() = mapOf(
        "id" to id,
        "senderId" to senderId,
        "senderName" to senderName,
        "text" to text,
        "latitude" to latitude,
        "longitude" to longitude,
        "timestamp" to timestamp,
        "isAnonymous" to isAnonymous,
        "isSynced" to isSynced,
        "expiryTimestamp" to expiryTimestamp
    )

    companion object {
        fun fromMap(map: Map<String, Any?>) = Message(
            id = map["id"] as? String ?: UUID.randomUUID().toString(),
            senderId = map["senderId"] as? String ?: "",
            senderName = map["senderName"] as? String ?: "Anonymous",
            text = map["text"] as? String ?: "",
            latitude = map["latitude"] as? Double,
            longitude = map["longitude"] as? Double,
            timestamp = (map["timestamp"] as? Long) ?: 0L,
            isAnonymous = map["isAnonymous"] as? Boolean ?: false,
            isSynced = map["isSynced"] as? Boolean ?: false,
            expiryTimestamp = map["expiryTimestamp"] as? Long
        )
    }
}
