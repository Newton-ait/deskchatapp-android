package com.newton.deskchatapp.models

import com.google.firebase.firestore.GeoPoint

data class CreateDeskRequest(
    val name: String,
    val description: String,
    val location: GeoPoint,
    val createdBy: String,
    val maxRadius: Double = 100.0,
    val isPublic: Boolean = true
)