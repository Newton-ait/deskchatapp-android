package com.newton.deskchatapp.util

/**
 * Generic resource wrapper for flows / repository responses.
 */
sealed class Resource<T>(
    val data: T? = null,
    val message: String? = null,
    val exception: Exception? = null
) {
    class Success<T>(data: T) : Resource<T>(data)
    class Loading<T>(data: T? = null, message: String? = null) : Resource<T>(data, message)
    class Error<T>(message: String, exception: Exception? = null, data: T? = null) : Resource<T>(data, message, exception)

    val isLoading get() = this is Loading
    val isSuccess get() = this is Success
    val isError get() = this is Error
}