package com.newton.deskchatapp.location

import android.content.Context
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.firebase.firestore.GeoPoint
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.suspendCoroutine
import dagger.hilt.android.qualifiers.ApplicationContext

/**
 * Base LocationManager that offers a simple suspendable API to get last known or current location.
 * Concrete implementations may extend (e.g., BatteryOptimizedLocationManager).
 */
@Singleton
open class LocationManager @Inject constructor(
    @ApplicationContext
    private val context: Context
) {
    protected val fusedClient: FusedLocationProviderClient by lazy {
        LocationServices.getFusedLocationProviderClient(context)
    }

    /**
     * Try to return last known location. Subclasses may override for more aggressive fetching.
     */
    open suspend fun getLastKnownLocation(): Result<GeoPoint> {
        return try {
            val location = fusedClient.lastLocation.await()
            if (location != null) {
                Result.success(GeoPoint(location.latitude, location.longitude))
            } else {
                Result.failure(Exception("Location unavailable"))
            }
        } catch (t: Throwable) {
            Result.failure(t)
        }
    }

    /**
     * Default implementation falls back to last known. Subclasses (BatteryOptimizedLocationManager)
     * may attempt a fresh location fetch.
     */
    open suspend fun getCurrentLocation(): Result<GeoPoint> {
        return getLastKnownLocation()
    }
}
