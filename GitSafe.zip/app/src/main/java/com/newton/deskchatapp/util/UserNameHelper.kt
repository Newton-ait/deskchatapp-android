package com.newton.deskchatapp.util

import kotlin.math.absoluteValue

object UserNameHelper {

    private val animalNames = listOf("Fox", "Bear", "Panda", "Wolf", "Eagle", "Tiger", "Cat", "Dolphin")

    fun generateAnonymousName(uid: String): String {
        val hash = uid.hashCode().absoluteValue % animalNames.size
        return "Anon${'$'}{animalNames[hash]}"
    }
}
