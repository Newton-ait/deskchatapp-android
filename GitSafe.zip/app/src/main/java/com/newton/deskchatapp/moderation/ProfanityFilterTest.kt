package com.newton.deskchatapp.moderation

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

class ProfanityFilterTest {

    private lateinit var profanityFilter: ProfanityFilter

    @Before
    fun setup() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        profanityFilter = ProfanityFilter(ctx)
    }

    @Test
    fun test_clean_text_removes_bad_words() {
        val input = "this is a damn message"
        val score = profanityFilter.getProfanityScore(input)
        // score semantics depend on your implementation; ensure >= 1 indicates profanity
        assert(score >= 1)
        val cleaned = profanityFilter.filterText(input)
        // filtered text should not contain the literal bad word
        assert(!cleaned.contains("damn", ignoreCase = true))
    }

    @Test
    fun test_clean_text_keeps_clean_input() {
        val input = "this is a nice message"
        val score = profanityFilter.getProfanityScore(input)
        assertEquals(0, score)
        val cleaned = profanityFilter.filterText(input)
        assertEquals(input, cleaned)
    }
}