package com.newton.deskchatapp.local

import androidx.room.*
import com.newton.deskchatapp.model.Message
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages ORDER BY timestamp ASC")
    fun getAllMessages(): Flow<List<Message>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: Message)

    @Delete
    suspend fun deleteMessage(message: Message)

    @Query("UPDATE messages SET isSynced = :synced WHERE id = :id")
    suspend fun markSynced(id: String, synced: Boolean)
}
