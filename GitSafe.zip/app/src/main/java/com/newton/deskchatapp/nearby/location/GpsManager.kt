package com.newton.deskchatapp.nearby.location

import android.annotation.SuppressLint
import android.content.Context
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.tasks.await

class GpsManager(private val context: Context) {
    private val client: FusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(context)

    @SuppressLint("MissingPermission")
    suspend fun getLastLocationCoarse(): Pair<Double, Double>? {
        val loc = client.lastLocation.await() ?: return null
        return Pair(loc.latitude, loc.longitude)
    }
}
