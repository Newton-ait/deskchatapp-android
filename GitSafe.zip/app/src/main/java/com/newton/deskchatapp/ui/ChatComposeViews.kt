package com.newton.deskchatapp.messages.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import com.newton.deskchatapp.models.Message

@Composable
fun LoadingShimmerItem() {
    val transition = rememberInfiniteTransition()
    val alpha by transition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    )

    Row(modifier = Modifier.padding(12.dp).fillMaxWidth()) {
        Box(modifier = Modifier.size(40.dp).clip(CircleShape).background(Color.LightGray.copy(alpha = alpha)))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.fillMaxWidth()) {
            Box(modifier = Modifier.fillMaxWidth(0.7f).height(12.dp).clip(RoundedCornerShape(6.dp)).background(Color.LightGray.copy(alpha = alpha)))
            Spacer(Modifier.height(8.dp))
            Box(modifier = Modifier.fillMaxWidth(0.4f).height(10.dp).clip(RoundedCornerShape(6.dp)).background(Color.LightGray.copy(alpha = alpha)))
        }
    }
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun AnimatedMessageItem(message: Message, isOwn: Boolean) {
    val enter = slideInVertically(animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)) + fadeIn()
    val exit = shrinkVertically(animationSpec = spring(stiffness = Spring.StiffnessLow)) + fadeOut()
    AnimatedVisibility(visible = true, enter = enter, exit = exit) {
        // You should implement your composable message bubble here
        Row(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
            // placeholder text
            Text(text = message.text)
        }
    }
}