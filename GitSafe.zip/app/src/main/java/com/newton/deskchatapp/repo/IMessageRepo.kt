package com.newton.deskchatapp.repo

import com.newton.deskchatapp.model.Message
import com.newton.deskchatapp.util.Result
import kotlinx.coroutines.flow.Flow

interface IMessageRepo {
    suspend fun sendMessage(message: Message): Result<Unit>
    fun listenForMessages(): Flow<List<Message>>
    suspend fun deleteMessage(id: String): Result<Unit>
    suspend fun markSynced(id: String)
}
