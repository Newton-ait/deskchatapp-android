package com.deskchat.core.expiry

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.deskchat.data.local.db.DeskChatDatabase
import timber.log.Timber

/**
 * Background worker that periodically deletes expired messages.
 */
class ExpiryWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val db = DeskChatDatabaseHolder.instance(applicationContext)
        return try {
            val now = System.currentTimeMillis()
            val deleted = db.messageDao().deleteExpired(now)
            Timber.d("🧭 ExpiryWorker: cleaned $deleted expired messages.")
            Result.success()
        } catch (e: Exception) {
            Timber.w(e, "ExpiryWorker failed")
            Result.retry()
        }
    }
}