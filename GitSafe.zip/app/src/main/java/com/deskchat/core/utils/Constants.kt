package com.deskchat.core.utils

object Constants {
    const val APP_NAME = "DeskChat"
    const val MESSAGE_TTL_HOURS = 24
}
