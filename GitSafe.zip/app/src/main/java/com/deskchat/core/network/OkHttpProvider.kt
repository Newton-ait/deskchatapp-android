package com.deskchat.core.network

import android.content.Context
import okhttp3.Cache
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.logging.HttpLoggingInterceptor
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Single place for OkHttp client with disk cache and network interceptors.
 * Use this for any REST API calls or image loading (Coil can be configured with this client).
 */
object OkHttpProvider {
    private const val CACHE_DIR = "http_cache"
    private const val CACHE_SIZE = 10L * 1024L * 1024L // 10 MB

    fun provideClient(context: Context): OkHttpClient {
        val cacheDir = File(context.cacheDir, CACHE_DIR)
        val cache = Cache(cacheDir, CACHE_SIZE)

        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }

        val offlineInterceptor = Interceptor { chain ->
            var request: Request = chain.request()
            // If the device is offline, use cached responses up to 24 hours
            if (!NetworkState.isOnline(context)) {
                val maxStale = 60 * 60 * 24 // 24 hours
                request = request.newBuilder()
                    .header("Cache-Control", "public, only-if-cached, max-stale=$maxStale")
                    .build()
            }
            chain.proceed(request)
        }

        val networkInterceptor = Interceptor { chain ->
            val response: Response = chain.proceed(chain.request())
            // force caching of GET responses for short time on the network
            val maxAge = 60 // 1 minute
            response.newBuilder()
                .header("Cache-Control", "public, max-age=$maxAge")
                .build()
        }

        return OkHttpClient.Builder()
            .cache(cache)
            .addInterceptor(offlineInterceptor)
            .addNetworkInterceptor(networkInterceptor)
            .addInterceptor(logging)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }
}