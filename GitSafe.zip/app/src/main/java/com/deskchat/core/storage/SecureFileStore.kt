package com.deskchat.core.storage

import android.content.Context
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKey
import java.io.File

/**
 * Simple helper to write/read encrypted files (e.g., attachments) using EncryptedFile.
 */
object SecureFileStore {

    fun writeEncrypted(context: Context, fileName: String, data: ByteArray) {
        val masterKey = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        val file = File(context.filesDir, fileName)
        val enc = EncryptedFile.Builder(context, file, masterKey, EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB)
            .build()
        enc.openFileOutput().use { it.write(data) }
    }

    fun readEncrypted(context: Context, fileName: String): ByteArray? {
        val masterKey = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        val file = File(context.filesDir, fileName)
        if (!file.exists()) return null
        val enc = EncryptedFile.Builder(context, file, masterKey, EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB)
            .build()
        return enc.openFileInput().use { it.readBytes() }
    }

    fun deleteFile(context: Context, fileName: String) {
        val file = File(context.filesDir, fileName)
        if (file.exists()) file.delete()
    }
}