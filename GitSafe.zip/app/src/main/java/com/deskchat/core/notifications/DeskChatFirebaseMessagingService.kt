package com.deskchat.core.notifications

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import timber.log.Timber

/**
 * Receives FCM push notifications for remote DeskChat updates.
 */
class DeskChatFirebaseMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(message: RemoteMessage) {
        val title = message.notification?.title ?: "New DeskChat message"
        val body = message.notification?.body ?: "Someone just posted near your area."
        Timber.d("FCM message received: $title - $body")

        if (NotificationPrefs(this).shouldNotifyNow()) {
            NotificationUtils.showMessageNotification(this, title, body)
        }
    }

    override fun onNewToken(token: String) {
        Timber.d("FCM token refreshed: $token")
        // You can sync token to Firestore user profile if needed.
    }
}