package com.deskchat.core.sync

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.deskchat.data.remote.firebase.FirestoreOptimizedService
import com.deskchat.data.repository.MessageRepository
import timber.log.Timber

/**
 * Worker that flushes queued messages in batches when device is connected and charging (optional).
 * Schedule via WorkManager with appropriate constraints (networkConnected).
 */
class SyncBatchWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    private val repo = MessageRepository.getInstance(ctx)
    private val firestore = FirestoreOptimizedService()

    override suspend fun doWork(): Result {
        try {
            // Suppose we maintain a local queue of unsynced messages (left as an exercise).
            val unsynced = repo.getUnsyncedMessages() // implement in repository
            if (unsynced.isEmpty()) return Result.success()
            // group by desk and send in batches
            val grouped = unsynced.groupBy { it.deskId }
            for ((deskId, msgs) in grouped) {
                firestore.batchWriteMessages(deskId, msgs)
                repo.markAsSynced(msgs.map { it.id })
            }
            Timber.i("SyncBatchWorker: flushed ${unsynced.size} messages")
            return Result.success()
        } catch (e: Exception) {
            Timber.w(e, "SyncBatchWorker failed")
            return Result.retry()
        }
    }
}