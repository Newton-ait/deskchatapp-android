package com.deskchat.core.expiry

import android.content.Context
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.deskchat.data.local.db.DeskChatDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import timber.log.Timber
import java.util.concurrent.TimeUnit

/**
 * Handles local message expiration based on TTL.
 * - schedules ExpiryWorker every few hours
 * - provides manual cleanup and recall functions
 */
class MessageExpirationManager(private val context: Context) {

    private val db = DeskChatDatabaseHolder.instance(context)
    private val scope = CoroutineScope(Dispatchers.IO)

    /** Remove expired messages from local DB immediately. */
    fun runImmediateCleanup() {
        scope.launch {
            try {
                val now = System.currentTimeMillis()
                val deleted = db.messageDao().deleteExpired(now)
                Timber.d("🧹 Local expired messages removed: $deleted")
            } catch (e: Exception) {
                Timber.w(e, "Error cleaning expired messages")
            }
        }
    }

    /** Schedule background worker to clean every 3 hours. */
    fun schedulePeriodicCleanup() {
        val req = OneTimeWorkRequestBuilder<ExpiryWorker>()
            .setInitialDelay(3, TimeUnit.HOURS)
            .build()
        WorkManager.getInstance(context)
            .enqueueUniqueWork("expiry_worker", ExistingWorkPolicy.REPLACE, req)
        Timber.d("⏳ ExpiryWorker scheduled.")
    }

    /** Recall (delete) a message before TTL (manual recall). */
    fun recallMessage(id: String) {
        scope.launch {
            try {
                val result = db.messageDao().deleteById(id)
                Timber.d("🧽 Message recalled manually: $id ($result rows)")
            } catch (e: Exception) {
                Timber.w(e, "Recall failed for $id")
            }
        }
    }
}