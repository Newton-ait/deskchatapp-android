package com.deskchat.core.privacy

import android.content.Context
import com.deskchat.core.storage.SecureFileStore
import com.deskchat.data.local.db.DeskChatDatabase
import com.deskchat.db.SecretStore
import com.deskchat.db.EncryptedRoomBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber

/**
 * Central privacy & data-handling operations.
 * - toggle incognito (affects MessageRepository behavior)
 * - delete all local data (logout / forget)
 * - export data (returns a simple JSON string - for user download)
 */
class PrivacyManager(private val context: Context) {

    private val db = DeskChatDatabaseHolder.instance(context) // make sure holder is wired
    private val secretStore = SecretStore

    suspend fun exportLocalMessagesJson(): String = withContext(Dispatchers.IO) {
        val msgs = db.messageDao().getAll()
        // naive JSON building; replace with Moshi/Gson if desired
        val sb = StringBuilder()
        sb.append("[")
        msgs.forEachIndexed { i, m ->
            sb.append("{")
            sb.append("\"id\":\"${m.id}\",")
            sb.append("\"text\":\"${escapeJson(m.text)}\",")
            sb.append("\"timestamp\":${m.timestamp},")
            sb.append("\"expiresAt\":${m.expiresAt}")
            sb.append("}")
            if (i < msgs.size - 1) sb.append(",")
        }
        sb.append("]")
        sb.toString()
    }

    suspend fun deleteAllLocalData() = withContext(Dispatchers.IO) {
        try {
            db.clearAllTables()
            // wipe secure prefs & secret
            secretStore.clearAll(context)
            // delete any stored files
            // For demo: delete a fixed list or iterate filesDir
            val files = context.filesDir.listFiles() ?: emptyArray()
            for (f in files) {
                if (f.name.startsWith("attachment_")) f.delete()
            }
            Timber.i("PrivacyManager: local data wiped")
        } catch (e: Exception) {
            Timber.w(e, "Failed to delete local data")
            throw e
        }
    }

    private fun escapeJson(s: String): String {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n")
    }
}