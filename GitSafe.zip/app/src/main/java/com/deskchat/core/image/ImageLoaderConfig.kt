package com.deskchat.core.image

import android.content.Context
import coil.ImageLoader
import coil.decode.GifDecoder
import coil.disk.DiskCache
import coil.memory.MemoryCache
import coil.util.DebugLogger
import com.deskchat.core.network.OkHttpProvider
import okhttp3.OkHttpClient

object ImageLoaderConfig {
    fun create(context: Context): ImageLoader {
        val ok = OkHttpProvider.provideClient(context)
        return ImageLoader.Builder(context)
            .okHttpClient { ok as OkHttpClient }
            .diskCache {
                DiskCache.Builder()
                    .directory(context.cacheDir.resolve("image_cache"))
                    .maxSizeBytes(20L * 1024L * 1024L) // 20MB
                    .build()
            }
            .memoryCache {
                MemoryCache.Builder(context)
                    .maxSizePercent(0.12) // 12% of app memory
                    .build()
            }
            .logger(DebugLogger())
            .components {
                if (android.os.Build.VERSION.SDK_INT >= 28) {
                    add(GifDecoder.Factory())
                } else {
                    add(GifDecoder.Factory())
                }
            }
            .build()
    }
}