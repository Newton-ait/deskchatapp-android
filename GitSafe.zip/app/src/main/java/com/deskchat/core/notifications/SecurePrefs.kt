package com.deskchat.core.notifications

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Secure preferences wrapper for any sensitive flags like incognito or user-consent tokens.
 * Full replacement for prior NotificationPrefs if you want to store sensitive values.
 */
class SecurePrefs(context: Context) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "deskchat_secure_prefs_v2",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun setIncognito(on: Boolean) = prefs.edit().putBoolean("incognito", on).apply()
    fun isIncognito(): Boolean = prefs.getBoolean("incognito", false)

    fun setNotificationsEnabled(on: Boolean) = prefs.edit().putBoolean("notifications", on).apply()
    fun isNotificationsEnabled(): Boolean = prefs.getBoolean("notifications", true)

    fun clearAll() = prefs.edit().clear().apply()
}