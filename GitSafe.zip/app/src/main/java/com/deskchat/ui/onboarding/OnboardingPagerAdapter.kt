package com.deskchat.ui.onboarding

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter

class OnboardingPagerAdapter(activity: FragmentActivity) : FragmentStateAdapter(activity) {
    private val pages = listOf(
        OnboardingPageFragment.newInstance("Drop a Message", "Say hi to the world around you.", "air_message.json"),
        OnboardingPageFragment.newInstance("Stay Anonymous", "No names, no pressure — just vibes.", "ghost.json"),
        OnboardingPageFragment.newInstance("Meet Nearby", "Find people by place, not profile.", "map_wave.json")
    )

    override fun getItemCount() = pages.size
    override fun createFragment(position: Int): Fragment = pages[position]
}