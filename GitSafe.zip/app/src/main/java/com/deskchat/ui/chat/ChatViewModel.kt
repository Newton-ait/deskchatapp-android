package com.deskchat.ui.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.deskchat.data.model.FirestoreMessage
import com.deskchat.data.remote.firebase.FirestoreChatService
import com.deskchat.data.repository.ChatRepository
import com.google.firebase.firestore.DocumentSnapshot
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch

class ChatViewModel(private val deskId: String) : ViewModel() {

    private val service = FirestoreChatService()
    private val repo = ChatRepository(service)

    // events -> Activity observes
    private val _incoming = Channel<FirestoreMessage>(Channel.UNLIMITED)
    val incomingFlow = _incoming.receiveAsFlow()

    private var listenerRegistration: com.google.firebase.firestore.ListenerRegistration? = null
    private var lastDoc: DocumentSnapshot? = null

    fun startListening() {
        listenerRegistration = repo.subscribeToDesk(deskId) { msg ->
            viewModelScope.launch {
                _incoming.send(msg)
                // optionally mark delivered if this device receives it
                if (msg.status == "sent") {
                    repo.markStatus(deskId, msg.id, "delivered")
                }
            }
        }
    }

    fun stopListening() {
        listenerRegistration?.remove()
    }

    fun sendMessage(text: String, alias: String? = null) {
        val msg = FirestoreMessage(
            id = "", // let Firestore create id
            text = text,
            senderAlias = alias,
            timestamp = System.currentTimeMillis(),
            status = "sent",
            deskId = deskId,
            ephemeral = true
        )
        viewModelScope.launch {
            val assignedId = repo.sendMessage(deskId, msg)
            // when saved, update local status if necessary
        }
    }

    suspend fun loadMore() : List<FirestoreMessage> {
        val (msgs, last) = repo.loadMore(deskId, lastDoc)
        lastDoc = last
        return msgs
    }
}