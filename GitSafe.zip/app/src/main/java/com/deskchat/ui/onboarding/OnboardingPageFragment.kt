package com.deskchat.ui.onboarding

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.airbnb.lottie.LottieAnimationView
import com.deskchat.R
import android.widget.TextView

class OnboardingPageFragment : Fragment() {

    companion object {
        fun newInstance(title: String, desc: String, anim: String): OnboardingPageFragment {
            val frag = OnboardingPageFragment()
            frag.arguments = Bundle().apply {
                putString("title", title)
                putString("desc", desc)
                putString("anim", anim)
            }
            return frag
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val v = inflater.inflate(R.layout.fragment_onboarding_page, container, false)
        val anim = v.findViewById<LottieAnimationView>(R.id.lottieAnim)
        val title = v.findViewById<TextView>(R.id.tvTitle)
        val desc = v.findViewById<TextView>(R.id.tvDesc)

        title.text = arguments?.getString("title")
        desc.text = arguments?.getString("desc")
        anim.setAnimation(arguments?.getString("anim"))
        anim.playAnimation()
        return v
    }
}