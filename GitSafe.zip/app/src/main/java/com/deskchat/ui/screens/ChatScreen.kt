package com.deskchat.ui.screens

import androidx.compose.runtime.Composable

@Composable
fun ChatScreen() {
    // TODO: implement UI
}
