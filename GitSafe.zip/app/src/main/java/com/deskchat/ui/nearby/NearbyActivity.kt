package com.deskchat.ui.nearby

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_nearby.*
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import timber.log.Timber

/**
 * NearbyActivity - handles permission flow and starts/stops Nearby scanning.
 *
 * Permissions required:
 *  - Android 12+ : BLUETOOTH_SCAN (+ BLUETOOTH_CONNECT if you need device name)
 *  - Older: ACCESS_FINE_LOCATION
 *
 * Replace UI and wiring if your project uses Compose or different patterns.
 */
class NearbyActivity : ComponentActivity() {

    private val vm: NearbyViewModel by viewModels()
    private lateinit var adapter: NearbyAdapter

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        val granted = results.values.all { it }
        if (granted) {
            startNearbyScanning()
        } else {
            Timber.w("Permissions denied: $results")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_nearby)

        adapter = NearbyAdapter { entry ->
            // click: show simple log or open chat
            Timber.i("Clicked nearby: ${entry.device.id} ~ ${entry.distanceMeters}m")
        }
        rvNearby.layoutManager = LinearLayoutManager(this)
        rvNearby.adapter = adapter

        btnStartNearby.setOnClickListener {
            requestPermissionsThenStart()
        }
        btnStopNearby.setOnClickListener {
            vm.stopNearby()
        }

        lifecycleScope.launch {
            vm.nearby.collectLatest { list ->
                adapter.set(list)
            }
        }
        lifecycleScope.launch {
            vm.isScanning.collectLatest { scanning ->
                btnStartNearby.isEnabled = !scanning
                btnStopNearby.isEnabled = scanning
            }
        }
    }

    private fun requestPermissionsThenStart() {
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            perms.add(Manifest.permission.BLUETOOTH_SCAN)
            // optional: BLUETOOTH_CONNECT if you want device name or pairing
            // perms.add(Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            perms.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        // Add background location only if you need scanning in background continuously:
        // perms.add(Manifest.permission.ACCESS_BACKGROUND_LOCATION)

        val toRequest = perms.filter { ContextCompat.checkSelfPermission(this, it) != android.content.pm.PackageManager.PERMISSION_GRANTED }.toTypedArray()
        if (toRequest.isEmpty()) {
            startNearbyScanning()
        } else {
            permissionLauncher.launch(toRequest)
        }
    }

    private fun startNearbyScanning() {
        vm.startNearby(aggressive = true)
    }

    override fun onStop() {
        super.onStop()
        // Optionally stop scanning when activity is not visible to save battery:
        vm.stopNearby()
    }
}