package com.deskchat.ui.chat

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.deskchat.R
import com.deskchat.data.model.FirestoreMessage

class MessageAdapter(private val items: MutableList<FirestoreMessage> = mutableListOf()) :
    RecyclerView.Adapter<MessageAdapter.VH>() {

    fun add(item: FirestoreMessage) {
        items.add(0, item) // newest at top because Firestore query is desc
        notifyItemInserted(0)
    }

    fun addAll(list: List<FirestoreMessage>) {
        val start = items.size
        items.addAll(list)
        notifyItemRangeInserted(start, list.size)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_message, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val m = items[position]
        holder.tvMessage.text = m.text
        holder.tvStatus.text = m.status
    }

    override fun getItemCount(): Int = items.size

    class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvMessage: TextView = itemView.findViewById(R.id.tvMessage)
        val tvStatus: TextView = itemView.findViewById(R.id.tvStatus)
    }
}