package com.deskchat.ui.nearby

import android.app.Application
import android.location.Location
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.deskchat.data.remote.bluetooth.BluetoothScanner
import com.deskchat.location.LocationManager
import com.deskchat.data.remote.bluetooth.ScannedDevice
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import timber.log.Timber
import kotlin.math.*

/**
 * NearbyViewModel (updated)
 * - orchestrates LocationManager + BluetoothScanner
 * - provides sorted list of NearbyEntry (device + distanceMeters)
 */
data class NearbyEntry(
    val device: ScannedDevice,
    val distanceMeters: Double,
    val lastSeen: Long
)

class NearbyViewModel(app: Application) : AndroidViewModel(app) {

    private val locationManager = LocationManager(app.applicationContext)
    private val btScanner = BluetoothScanner(app.applicationContext)

    // Exposed flows
    private val _nearby = MutableStateFlow<List<NearbyEntry>>(emptyList())
    val nearby: StateFlow<List<NearbyEntry>> = _nearby.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    init {
        // observe BT devices and combine with best known location periodically
        viewModelScope.launch {
            btScanner.devices.collectLatest { devices ->
                val loc = locationManager.getLastKnown() ?: run {
                    // optionally request a single update if null
                    null
                }
                val entries = devices.map { dev ->
                    val dist = estimateCombinedDistance(dev, loc)
                    NearbyEntry(dev, dist, dev.lastSeen)
                }.sortedBy { it.distanceMeters }
                _nearby.value = entries
            }
        }
    }

    fun startNearby(aggressive: Boolean = false) {
        _isScanning.value = true
        btScanner.setAggressiveMode(aggressive)
        btScanner.startPeriodicScanning()
        // start location updates for better distance computation
        try {
            locationManager.startLocationUpdates()
        } catch (e: Exception) {
            Timber.w(e, "Location start failed")
        }
    }

    fun stopNearby() {
        _isScanning.value = false
        btScanner.stopPeriodicScanning()
        locationManager.stopLocationUpdates()
    }

    private fun estimateCombinedDistance(device: ScannedDevice, loc: Location?): Double {
        // If device payload included lat/lng (rare), use haversine
        if (device.lat != null && device.lng != null && loc != null) {
            val d = haversineMeters(loc.latitude, loc.longitude, device.lat, device.lng)
            return d
        }
        // Otherwise fallback to RSSI estimate
        val rssiEst = device.estimatedDistanceMeters()
        // If we have coarse location and desk mapping, we could refine further; for now return rssiEst
        return rssiEst
    }

    // Haversine distance
    private fun haversineMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val R = 6371000.0 // Earth radius in meters
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2.0) + cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2.0)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return R * c
    }
}