package com.deskchat.ui.chat

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.deskchat.R
import com.deskchat.data.model.FirestoreMessage
import kotlinx.android.synthetic.main.activity_chat.*
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ChatActivity : AppCompatActivity() {

    private lateinit var adapter: MessageAdapter
    // You should obtain deskId from intent extras
    private val deskId by lazy { intent.getStringExtra("deskId") ?: "default_desk" }
    private val viewModel by lazy { ChatViewModel(deskId) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        adapter = MessageAdapter(mutableListOf())
        rvMessages.layoutManager = LinearLayoutManager(this).apply { reverseLayout = true }
        rvMessages.adapter = adapter

        btnSend.setOnClickListener {
            val txt = etMessage.text.toString().trim()
            if (txt.isNotEmpty()) {
                viewModel.sendMessage(txt)
                etMessage.setText("")
            }
        }

        lifecycleScope.launch {
            viewModel.incomingFlow.collectLatest { msg ->
                runOnUiThread {
                    adapter.add(msg)
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        viewModel.startListening()
    }

    override fun onStop() {
        super.onStop()
        viewModel.stopListening()
    }
}