package com.deskchat.data.remote.bluetooth

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.le.*
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.ParcelUuid
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.nio.charset.Charset
import java.util.*
import kotlin.math.pow

/**
 * BluetoothScanner
 *
 * Responsibilities:
 *  - scan for BLE advertisements with duty-cycling (adaptive scanning to save battery)
 *  - parse minimal advertisement payload into token string (if any)
 *  - expose a StateFlow<List<ScannedDevice>> of current nearby devices (updated live)
 *
 * IMPORTANT:
 *  - Caller must ensure runtime permissions are granted (BLUETOOTH_SCAN, ACCESS_FINE_LOCATION on older devices)
 *  - For Android 12+ require BLUETOOTH_SCAN; for older require location permission
 *
 * Short form note: This is the single-file BLE scanner to paste in place of the earlier placeholder.
 */
data class ScannedDevice(
    val id: String,            // unique token (from adv or generated)
    val address: String?,      // device MAC or null (may be random)
    val rssi: Int,             // RSSI value
    val lastSeen: Long,        // epoch ms
    val txPower: Int? = null,  // if present in adv
    val lat: Double? = null,   // optional if payload contains coordinates (rare)
    val lng: Double? = null
) {
    fun estimatedDistanceMeters(): Double {
        // If txPower is available use RSSI formula: d = 10 ^ ((txPower - rssi) / (10 * n))
        val n = 2.0 // path-loss exponent (2 = free space)
        val useTx = txPower ?: -59 // assume -59 dBm if unknown
        val exp = (useTx - rssi) / (10.0 * n)
        return 10.0.pow(exp)
    }
}

class BluetoothScanner(private val context: Context) {

    private val TAG = "BluetoothScanner"
    private val adapter: BluetoothAdapter? by lazy { BluetoothAdapter.getDefaultAdapter() }
    private val scanner: BluetoothLeScanner? get() = adapter?.bluetoothLeScanner

    // Flow of currently seen devices (most recent first)
    private val _devices = MutableStateFlow<List<ScannedDevice>>(emptyList())
    val devices: StateFlow<List<ScannedDevice>> = _devices

    private var scanCallback: ScanCallback? = null
    private var scanJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    // Map to keep last seen & merged info
    private val seen = Collections.synchronizedMap(mutableMapOf<String, ScannedDevice>())

    // Adaptive scan params - start conservative, adjust later
    private var scanDurationMs: Long = 6000L
    private var restDurationMs: Long = 15000L
    private var aggressiveMode = false

    private val serviceUuidFilter = ParcelUuid(UUID.fromString("0000180D-0000-1000-8000-00805f9b34fb"))
    // You may change to your custom UUID

    /**
     * Call to start periodic scanning with duty-cycle.
     * Permissions must already be granted.
     */
    fun startPeriodicScanning() {
        // If already started, ignore
        if (scanJob?.isActive == true) return

        scanJob = scope.launch {
            while (isActive) {
                if (isScanPermitted()) {
                    startScanOnce()
                    delay(scanDurationMs)
                    stopScan()
                } else {
                    Log.w(TAG, "Scan not permitted by permissions or adapter state")
                }
                // cleanup expired entries older than 45s
                cleanupExpired()
                delay(restDurationMs)
            }
        }
    }

    fun stopPeriodicScanning() {
        scanJob?.cancel()
        stopScan()
        seen.clear()
        _devices.value = emptyList()
    }

    private fun cleanupExpired() {
        val now = System.currentTimeMillis()
        val expiredKeys = mutableListOf<String>()
        synchronized(seen) {
            for ((k, v) in seen) {
                if (now - v.lastSeen > 45000L) expiredKeys.add(k) // 45s timeout
            }
            for (k in expiredKeys) seen.remove(k)
        }
        _devices.value = seen.values.sortedBy { it.estimatedDistanceMeters() } // nearest first
    }

    @SuppressLint("MissingPermission")
    private fun startScanOnce() {
        try {
            val sb = ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY) // short bursts -> low latency
                .setReportDelay(0)
                .build()

            // Basic filter: scan for Service UUID or just allow all
            val filters = listOf(
                // Optionally use a filter to reduce noise
                ScanFilter.Builder().setServiceUuid(serviceUuidFilter).build()
            )

            scanCallback = object : ScanCallback() {
                override fun onScanResult(callbackType: Int, result: ScanResult) {
                    try {
                        val rssi = result.rssi
                        val addr = result.device?.address
                        val now = System.currentTimeMillis()

                        // Attempt to extract token from scanRecord — depends on how advertiser encodes it
                        // Here we try deviceName as simple token (if advertiser put it there)
                        val scanRecord = result.scanRecord
                        val devName = scanRecord?.deviceName
                        var token = devName
                        // Try service data as fallback (convert bytes to string)
                        if (token.isNullOrBlank()) {
                            val sd = scanRecord?.serviceData
                            if (sd != null && sd.isNotEmpty()) {
                                val first = sd.entries.firstOrNull()
                                val bytes = first?.value
                                if (bytes != null) {
                                    token = bytes.toString(Charset.defaultCharset())
                                }
                            }
                        }
                        // Fallback token: MAC + timestamp (non-PII on modern Android but still randomized)
                        if (token.isNullOrBlank()) token = addr ?: UUID.randomUUID().toString()

                        // optional txPower
                        val tx = scanRecord?.txPowerLevel

                        val prev = seen[token]
                        val device = ScannedDevice(
                            id = token,
                            address = addr,
                            rssi = rssi,
                            lastSeen = now,
                            txPower = tx,
                            lat = null,
                            lng = null
                        )
                        seen[token] = device
                        // update flow sorted by distance
                        _devices.value = seen.values.sortedBy { it.estimatedDistanceMeters() }
                    } catch (e: Exception) {
                        Log.w(TAG, "onScanResult error: ${e.message}")
                    }
                }

                override fun onScanFailed(errorCode: Int) {
                    Log.w(TAG, "BLE Scan failed: $errorCode")
                }
            }

            // start scanning
            scanner?.startScan(filters, sb, scanCallback)
            Log.d(TAG, "BLE scan started (duration=${scanDurationMs}ms)")
        } catch (e: Exception) {
            Log.w(TAG, "startScanOnce exception ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    private fun stopScan() {
        try {
            if (scanCallback != null) {
                scanner?.stopScan(scanCallback)
                scanCallback = null
                Log.d(TAG, "BLE scan stopped")
            }
        } catch (e: Exception) {
            Log.w(TAG, "stopScan error ${e.message}")
        }
    }

    /**
     * Simple heuristic to toggle aggressive scanning (for instance, when user toggles Nearby UI)
     */
    fun setAggressiveMode(enabled: Boolean) {
        aggressiveMode = enabled
        if (enabled) {
            scanDurationMs = 9000L
            restDurationMs = 6000L
        } else {
            scanDurationMs = 5000L
            restDurationMs = 15000L
        }
    }

    fun isScanPermitted(): Boolean {
        // Android 12+ requires BLUETOOTH_SCAN; older devices require fine location
        val hasBluetooth = adapter != null && adapter.isEnabled
        val ctx = context
        val bluetoothPermissionOk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        }
        return hasBluetooth && bluetoothPermissionOk
    }
}