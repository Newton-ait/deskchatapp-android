package com.deskchat.data.remote.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.BluetoothLeAdvertiser
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.ParcelUuid
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.nio.charset.Charset
import java.util.*

/**
 * Minimal BLE service skeleton.
 * - startAdvertising(token)
 * - stopAdvertising()
 * - startScanning(onFound)
 * - stopScanning()
 *
 * Note: Requires runtime permissions BLUETOOTH_ADVERTISE / BLUETOOTH_SCAN and location on older Android versions.
 */
class BluetoothService(private val context: Context) {

    private val adapter: BluetoothAdapter? by lazy { BluetoothAdapter.getDefaultAdapter() }
    private val advertiser: BluetoothLeAdvertiser? by lazy { adapter?.bluetoothLeAdvertiser }
    private var advertiseCallback: AdvertiseCallback? = null
    private var scanCallback: ScanCallback? = null

    fun startAdvertising(token: String) {
        try {
            val adv = advertiser ?: return
            val settings = AdvertiseSettings.Builder()
                .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
                .setConnectable(false)
                .setTimeout(0)
                .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
                .build()

            val data = AdvertiseData.Builder()
                // Put token in manufacturer data or service data (careful about size)
                .addServiceUuid(ParcelUuid(UUID.fromString("0000180D-0000-1000-8000-00805f9b34fb")))
                .setIncludeDeviceName(false)
                .build()

            advertiseCallback = object : AdvertiseCallback() {}
            adv.startAdvertising(settings, data, advertiseCallback)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun stopAdvertising() {
        try {
            advertiser?.stopAdvertising(advertiseCallback)
            advertiseCallback = null
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @SuppressLint("MissingPermission")
    fun startScanning(onFound: (token: String) -> Unit) {
        val btAdapter = adapter ?: return
        val scanner = btAdapter.bluetoothLeScanner ?: return

        scanCallback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                try {
                    val sr = result
                    // Attempt to read service data or manufacturer data — sample placeholder
                    val bytes = sr.scanRecord?.deviceName?.toByteArray(Charset.defaultCharset())
                    bytes?.let {
                        val token = String(it)
                        CoroutineScope(Dispatchers.Main).launch { onFound(token) }
                    }
                } catch (e: Exception) { }
            }
        }
        scanner.startScan(scanCallback)
    }

    @SuppressLint("MissingPermission")
    fun stopScanning() {
        try {
            adapter?.bluetoothLeScanner?.stopScan(scanCallback)
            scanCallback = null
        } catch (e: Exception) { e.printStackTrace() }
    }

    fun broadcastMessage(payload: String) {
        // BLE advertisement payload is limited. Use token+server fetch for larger messages.
        startAdvertising(payload)
    }
}
