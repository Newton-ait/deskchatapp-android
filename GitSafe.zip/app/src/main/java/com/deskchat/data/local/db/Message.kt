package com.deskchat.data.local.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages")
data class Message(
    @PrimaryKey val id: String,
    val text: String,
    val senderAlias: String? = null,
    val timestamp: Long,
    val expiresAt: Long
)
