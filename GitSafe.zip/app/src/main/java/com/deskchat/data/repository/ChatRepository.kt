package com.deskchat.data.repository

import com.deskchat.data.model.FirestoreMessage
import com.deskchat.data.remote.firebase.FirestoreChatService
import com.google.firebase.firestore.DocumentSnapshot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ChatRepository(private val service: FirestoreChatService) {

    // send and return assigned id
    suspend fun sendMessage(deskId: String, message: FirestoreMessage): String = withContext(Dispatchers.IO) {
        service.sendMessage(deskId, message)
    }

    fun subscribeToDesk(deskId: String, pageSize: Long = 25, onAdded: (FirestoreMessage) -> Unit) =
        service.listenForLatestMessages(deskId, pageSize, onAdded)

    suspend fun loadMore(deskId: String, lastDoc: DocumentSnapshot?, pageSize: Long = 25L) =
        service.loadPage(deskId, lastDoc, pageSize)

    suspend fun markStatus(deskId: String, messageId: String, status: String) = withContext(Dispatchers.IO) {
        service.updateMessageStatus(deskId, messageId, status)
    }
}