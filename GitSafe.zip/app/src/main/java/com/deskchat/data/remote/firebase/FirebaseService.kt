package com.deskchat.data.remote.firebase

// Placeholder Firebase service - add actual Firebase SDK integration
class FirebaseService {
    fun uploadMessage(json: String) {
        // TODO: integrate Firebase Firestore
    }
}
