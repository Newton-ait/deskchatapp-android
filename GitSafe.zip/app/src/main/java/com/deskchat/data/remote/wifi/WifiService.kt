package com.deskchat.data.remote.wifi

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.ServerSocket
import java.net.Socket

/**
 * WifiService implements NSD-based discovery and a simple TCP server/client for LAN chat.
 * Use startHost(port) to host a room, and discover() to search for peers.
 */
class WifiService(private val context: Context) {
    private val nsdManager = context.getSystemService(Context.NSD_SERVICE) as NsdManager
    private var registrationListener: NsdManager.RegistrationListener? = null
    private var discoveryListener: NsdManager.DiscoveryListener? = null

    fun startHost(port: Int, serviceName: String = "DeskChatRoom") {
        val serviceInfo = NsdServiceInfo().apply {
            this.serviceType = "_deskchat._tcp."
            this.serviceName = serviceName
            setPort(port)
        }

        registrationListener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(info: NsdServiceInfo) {
                Log.d("WifiService", "Registered NSD: ${info.serviceName}")
            }

            override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                Log.d("WifiService", "Registration failed: $errorCode")
            }

            override fun onServiceUnregistered(serviceInfo: NsdServiceInfo) {
                Log.d("WifiService", "Unregistered NSD")
            }

            override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                Log.d("WifiService", "Unregister failed: $errorCode")
            }
        }

        nsdManager.registerService(serviceInfo, NsdManager.PROTOCOL_DNS_SD, registrationListener)
    }

    fun stopHost() {
        registrationListener?.let { nsdManager.unregisterService(it) }
    }

    fun discover(onResolved: (host: String, port: Int) -> Unit) {
        discoveryListener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) { Log.d("WifiService","Discovery started") }
            override fun onDiscoveryStopped(serviceType: String) { Log.d("WifiService","Discovery stopped") }
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) { }
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) { }
            override fun onServiceFound(service: NsdServiceInfo) {
                nsdManager.resolveService(service, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(serviceInfo: NsdServiceInfo?, errorCode: Int) {}
                    override fun onServiceResolved(resolvedServiceInfo: NsdServiceInfo) {
                        val host = resolvedServiceInfo.host.hostAddress
                        val port = resolvedServiceInfo.port
                        onResolved(host, port)
                    }
                })
            }
            override fun onServiceLost(service: NsdServiceInfo) { }
        }
        nsdManager.discoverServices("_deskchat._tcp.", NsdManager.PROTOCOL_DNS_SD, discoveryListener)
    }

    // Simple blocking TCP server - call from coroutine dispatcher IO
    suspend fun runServer(port: Int, onMessage: (String, Socket) -> Unit) = withContext(Dispatchers.IO) {
        val server = ServerSocket(port)
        try {
            while (!server.isClosed) {
                val client = server.accept()
                handleClient(client, onMessage)
            }
        } finally {
            server.close()
        }
    }

    private fun handleClient(socket: Socket, onMessage: (String, Socket) -> Unit) {
        Thread {
            try {
                val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    line?.let { onMessage(it, socket) }
                }
            } catch (e: Exception) {
                Log.e("WifiService","Client error: ${e.message}")
            } finally {
                try { socket.close() } catch (_: Exception) {}
            }
        }.start()
    }

    suspend fun sendToHost(host: String, port: Int, msg: String): Boolean = withContext(Dispatchers.IO) {
        try {
            Socket(host, port).use { sock ->
                val out = PrintWriter(sock.getOutputStream(), true)
                out.println(msg)
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
