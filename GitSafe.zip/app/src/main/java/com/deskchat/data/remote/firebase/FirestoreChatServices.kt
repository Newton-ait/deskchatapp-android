package com.deskchat.data.remote.firebase

import com.deskchat.data.model.FirestoreMessage
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.tasks.await

class FirestoreChatService {
    private val db = FirebaseFirestore.getInstance()
    private val desksColl = db.collection("desks") // each desk -> messages subcollection

    suspend fun sendMessage(deskId: String, message: FirestoreMessage): String {
        val col = desksColl.document(deskId).collection("messages")
        // If id empty, Firestore will create doc ID
        val docRef = if (message.id.isBlank()) col.add(message).await() else {
            col.document(message.id).also { it.set(message).await() }
            col.document(message.id)
        }
        return docRef.id
    }

    fun listenForLatestMessages(deskId: String, pageSize: Long = 25, onAdded: (FirestoreMessage) -> Unit): ListenerRegistration {
        val col = desksColl.document(deskId).collection("messages")
        val query = col.orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .limit(pageSize)
        return query.addSnapshotListener { snapshot, error ->
            if (error != null || snapshot == null) return@addSnapshotListener
            snapshot.documentChanges.forEach { dc ->
                if (dc.type == com.google.firebase.firestore.DocumentChange.Type.ADDED) {
                    val msg = FirestoreMessage.fromSnapshot(dc.document)
                    onAdded(msg)
                }
                // could handle modified/removed if necessary
            }
        }
    }

    suspend fun loadPage(deskId: String, lastDoc: DocumentSnapshot?, pageSize: Long = 25L): Pair<List<FirestoreMessage>, DocumentSnapshot?> {
        val col = desksColl.document(deskId).collection("messages")
        var q = col.orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(pageSize)
        if (lastDoc != null) q = q.startAfter(lastDoc)
        val snap = q.get().await()
        val msgs = snap.documents.map { FirestoreMessage.fromSnapshot(it) }
        val last = snap.documents.lastOrNull()
        return Pair(msgs, last)
    }

    suspend fun updateMessageStatus(deskId: String, messageId: String, status: String) {
        val doc = desksColl.document(deskId).collection("messages").document(messageId)
        doc.update("status", status).await()
    }
}