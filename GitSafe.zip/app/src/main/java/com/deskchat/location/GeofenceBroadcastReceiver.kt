package com.deskchat.location

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingEvent
import timber.log.Timber

class GeofenceBroadcastReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val event = GeofencingEvent.fromIntent(intent) ?: return
        if (event.hasError()) {
            Timber.w("Geofence error: ${event.errorCode}")
            return
        }

        val transition = event.geofenceTransition
        val geofences = event.triggeringGeofences ?: emptyList<Geofence>()

        when (transition) {
            Geofence.GEOFENCE_TRANSITION_ENTER -> {
                geofences.forEach { Timber.d("Entered geofence ${it.requestId}") }
                // TODO: trigger a local notification to users that a desk was just posted at this place
            }
            Geofence.GEOFENCE_TRANSITION_EXIT -> {
                geofences.forEach { Timber.d("Exited geofence ${it.requestId}") }
            }
            else -> Timber.d("Unknown geofence transition: $transition")
        }
    }
}