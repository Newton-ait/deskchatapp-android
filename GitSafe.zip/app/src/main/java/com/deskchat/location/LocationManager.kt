package com.deskchat.location

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.os.Looper
import com.google.android.gms.location.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import timber.log.Timber
import kotlin.math.abs
import kotlin.math.max

/**
 * Enhanced LocationManager with:
 * - adaptive frequency (same as before)
 * - publish throttling: don't publish location updates more often than minPublishIntervalMs
 * - debounce logic for location-to-desk mapping: only compute grid and trigger heavy ops after stable location
 *
 * Exposed API:
 *  - startLocationUpdates()
 *  - stopLocationUpdates()
 *  - requestSingleUpdate(onResult)
 *  - locationFlow (SharedFlow) to observe per-second coarse updates
 */
class LocationManager(private val context: Context) {

    private val fusedClient: FusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(context)

    private var locationRequest: LocationRequest? = null
    private var locationCallback: LocationCallback? = null

    private var isUpdating = false
    private var lastLocation: Location? = null

    // throttling / debounce
    private var minPublishIntervalMs: Long = 10_000L // don't broadcast desk changes more often than 10s
    private var lastPublishedAt: Long = 0L
    private var stableDebounceMs: Long = 2000L // wait 2s of stability before heavy ops

    private val _locFlow = MutableSharedFlow<Location>(replay = 1)
    val locationFlow = _locFlow.asSharedFlow()

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var stabilityJob: Job? = null

    // adaptive intervals
    private var updateIntervalMs: Long = 8000L
    private var fastestIntervalMs: Long = 3000L
    private var smallestDisplacementM: Float = 3f

    @SuppressLint("MissingPermission")
    fun startLocationUpdates() {
        if (isUpdating) return
        adaptStrategy()

        locationRequest = LocationRequest.Builder(Priority.PRIORITY_BALANCED_POWER_ACCURACY, updateIntervalMs)
            .setMinUpdateIntervalMillis(fastestIntervalMs)
            .setMinUpdateDistanceMeters(smallestDisplacementM.toDouble())
            .build()

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val loc = result.lastLocation ?: return
                lastLocation = loc
                try {
                    _locFlow.tryEmit(loc)
                } catch (e: Exception) {
                    Timber.w(e, "emit location failed")
                }
                // schedule stability check
                scheduleStabilityCheck(loc)
            }
        }

        fusedClient.requestLocationUpdates(locationRequest!!, locationCallback!!, Looper.getMainLooper())
        isUpdating = true
        Timber.d("Location updates started (interval=$updateIntervalMs)")
    }

    fun stopLocationUpdates() {
        try {
            locationCallback?.let { fusedClient.removeLocationUpdates(it) }
        } catch (e: Exception) {
            Timber.w(e, "stopLocationUpdates failed")
        } finally {
            locationCallback = null
            isUpdating = false
            stabilityJob?.cancel()
        }
    }

    @SuppressLint("MissingPermission")
    fun requestSingleUpdate(onResult: (Location?) -> Unit) {
        val oneReq = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 0)
            .setMinUpdateIntervalMillis(0)
            .setMaxUpdateDelayMillis(0)
            .build()

        val cb = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                try {
                    onResult(result.lastLocation)
                } finally {
                    fusedClient.removeLocationUpdates(this)
                }
            }
        }
        fusedClient.requestLocationUpdates(oneReq, cb, Looper.getMainLooper())
        // fallback to last location
        fusedClient.lastLocation.addOnSuccessListener { loc -> if (loc != null) onResult(loc) }
            .addOnFailureListener { onResult(null) }
    }

    fun getLastKnown(): Location? = lastLocation

    // --- Throttling & stability logic ----------------

    private fun scheduleStabilityCheck(loc: Location) {
        stabilityJob?.cancel()
        stabilityJob = scope.launch {
            // wait for stableDebounceMs; if another location arrives during this period, job is cancelled and restarted
            delay(stableDebounceMs)
            handleStableLocation(loc)
        }
    }

    private fun handleStableLocation(loc: Location) {
        val now = System.currentTimeMillis()
        if (now - lastPublishedAt < minPublishIntervalMs) {
            Timber.v("Skipping publish: throttled (lastPublished=${now - lastPublishedAt} ms ago)")
            return
        }
        // publish desk change or notify listeners (e.g., compute grid and trigger a send)
        // If you have a callback or event bus, send it. For example:
        try {
            // compute desk id, etc. (GeoGrid is in location package)
            val desk = GeoGrid.toCellId(loc.latitude, loc.longitude, 100)
            Timber.d("Stable location: publishing desk=$desk")
            lastPublishedAt = now
            // TODO: call repository or network manager to announce presence if needed
        } catch (e: Exception) {
            Timber.w(e, "handleStableLocation failed")
        }
    }

    private fun adaptStrategy() {
        val loc = lastLocation ?: return
        val speed = loc.speed
        val accuracy = loc.accuracy
        when {
            speed > 2.0f || accuracy <= 10f -> {
                updateIntervalMs = 3000L
                fastestIntervalMs = 1000L
                smallestDisplacementM = 1f
                minPublishIntervalMs = 3_000L
            }
            speed > 0.3f -> {
                updateIntervalMs = 8_000L
                fastestIntervalMs = 3_000L
                smallestDisplacementM = 3f
                minPublishIntervalMs = 10_000L
            }
            else -> {
                updateIntervalMs = 30_000L
                fastestIntervalMs = 10_000L
                smallestDisplacementM = 8f
                minPublishIntervalMs = 30_000L
            }
        }
    }
}