package com.deskchat.location

import kotlin.math.floor

/**
 * Simple grid system for mapping lat/lng to a coarse cell id.
 *
 * cellSizeMeters: desired cell edge length (meters). Default 100m.
 * This converts meters -> degrees approx (lat only approx by 111.32 km/deg).
 *
 * Desk id format: "G_<gridLat>_<gridLon>_<cellm>"
 */
object GeoGrid {
    private const val METERS_PER_DEGREE = 111320.0 // approximate at equator

    fun cellSizeDegrees(cellSizeMeters: Int): Double = cellSizeMeters / METERS_PER_DEGREE

    fun toCellId(lat: Double, lon: Double, cellSizeMeters: Int = 100): String {
        val deg = cellSizeDegrees(cellSizeMeters)
        val latIdx = floor(lat / deg).toInt()
        val lonIdx = floor(lon / deg).toInt()
        return "G_${latIdx}_${lonIdx}_${cellSizeMeters}"
    }

    /**
     * Reconstructs a rough center coordinate for a cell (approx)
     */
    fun cellCenter(cellId: String): Pair<Double, Double>? {
        try {
            // expected "G_<latIdx>_<lonIdx>_<cellMeters>"
            val parts = cellId.split("_")
            if (parts.size < 4) return null
            val latIdx = parts[1].toInt()
            val lonIdx = parts[2].toInt()
            val cellMeters = parts[3].toInt()
            val deg = cellSizeDegrees(cellMeters)
            val centerLat = (latIdx + 0.5) * deg
            val centerLon = (lonIdx + 0.5) * deg
            return Pair(centerLat, centerLon)
        } catch (e: Exception) {
            return null
        }
    }
}