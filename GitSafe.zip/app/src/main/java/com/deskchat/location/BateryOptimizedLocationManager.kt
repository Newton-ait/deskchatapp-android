package com.deskchat.location

import android.content.Context
import android.os.BatteryManager
import androidx.core.content.getSystemService
import timber.log.Timber

/**
 * Example helper to choose strategy based on battery level.
 * - When battery < 20% we prefer balanced power; else prefer accuracy.
 */
class BatteryOptimizedLocationManager(private val context: Context, private val locationManager: LocationManager) {

    fun chooseStrategyAndStart() {
        val bm = context.getSystemService<BatteryManager>() ?: run {
            locationManager.startLocationUpdates()
            return
        }
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) // 0..100
        Timber.d("Battery level %d", level)
        if (level >= 30) {
            // allow higher frequency
            locationManager.startLocationUpdates()
        } else {
            // lower power: reduce frequency by programmatically tweaking params
            // for simplicity, just start updates and LocationManager adaptStrategy will do the rest
            locationManager.startLocationUpdates()
        }
    }

    fun stop() = locationManager.stopLocationUpdates()
}