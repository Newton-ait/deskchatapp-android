package com.deskchat.location

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.deskchat.core.utils.Constants
import timber.log.Timber

/**
 * Minimal foreground service to keep location updates alive in background.
 * You still must request ACCESS_BACKGROUND_LOCATION permission for Android 10+.
 */
class LocationForegroundService : Service() {

    companion object {
        const val CHANNEL_ID = "deskchat_location_channel"
        const val NOTIF_ID = 5551
    }

    private lateinit var manager: LocationManager

    override fun onCreate() {
        super.onCreate()
        manager = LocationManager(applicationContext)
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotif())
        manager.startLocationUpdates()
        Timber.d("LocationForegroundService started")
    }

    override fun onDestroy() {
        super.onDestroy()
        manager.stopLocationUpdates()
        Timber.d("LocationForegroundService stopped")
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(CHANNEL_ID, "${Constants.APP_NAME} location", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotif(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("${Constants.APP_NAME} — Nearby mode")
            .setContentText("Sharing presence while you are nearby")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .build()
    }
}