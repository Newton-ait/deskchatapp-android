package com.deskchat.db

import android.content.Context
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SupportFactory
import java.nio.charset.StandardCharsets
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import kotlin.random.Random

/**
 * Build a Room database using SQLCipher for encryption at rest.
 * - Uses a derived passphrase stored in EncryptedSharedPreferences.
 *
 * IMPORTANT:
 * - You must add SQLCipher dependency and Zetetic maven repo (see README).
 * - For greatest security, consider using Android Keystore to store encryption keys.
 */
object EncryptedRoomBuilder {

    private const val DB_NAME = "deskchat_secure.db"
    private const val PREFS_NAME = "secure_prefs"
    private const val KEY_ALIAS = "deskchat_db_key"

    /**
     * Create a SupportFactory using a passphrase stored in EncryptedSharedPreferences.
     * The actual persistent secret is generated once and saved encrypted.
     */
    fun createSupportFactory(context: Context): SupportFactory {
        // Build a passphrase
        val passphrase = SecretStore.getOrCreateDbKey(context)
        // SQLCipher expects bytes
        val bytes = passphrase.toByteArray(StandardCharsets.UTF_8)
        val factory = SupportFactory(bytes)
        return factory
    }

    fun getDbName(): String = DB_NAME
}