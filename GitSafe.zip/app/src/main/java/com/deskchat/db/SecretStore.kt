package com.deskchat.db

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.util.*

/**
 * Stores the DB encryption secret inside EncryptedSharedPreferences (which itself uses the Android Keystore).
 * This is not a full hardware-backed KeyStore solution but is secure for most threat models.
 */
object SecretStore {
    private const val PREFS = "deskchat_secure_prefs"
    private const val DB_KEY = "db_passphrase"

    fun getOrCreateDbKey(context: Context): String {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        val esp = EncryptedSharedPreferences.create(
            context,
            PREFS,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )

        var key = esp.getString(DB_KEY, null)
        if (key.isNullOrEmpty()) {
            // generate a random strong passphrase
            key = UUID.randomUUID().toString() + UUID.randomUUID().toString()
            esp.edit().putString(DB_KEY, key).apply()
        }
        return key
    }

    fun clearAll(context: Context) {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        val esp = EncryptedSharedPreferences.create(
            context,
            PREFS,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
        esp.edit().clear().apply()
    }
}