package com.deskchat

import android.app.Application

class MainApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Initialize DI, Firebase, etc.
    }
}
val notifRequest = PeriodicWorkRequestBuilder<NearbyNotificationWorker>(30, TimeUnit.MINUTES)
    .setInitialDelay(5, TimeUnit.MINUTES)
    .build()

WorkManager.getInstance(this).enqueueUniquePeriodicWork(
    "deskchat_nearby_notifier",
    ExistingPeriodicWorkPolicy.KEEP,
    notifRequest
)
val factory = EncryptedRoomBuilder.createSupportFactory(applicationContext)
val db = Room.databaseBuilder(applicationContext, DeskChatDatabase::class.java, EncryptedRoomBuilder.getDbName())
    .openHelperFactory(factory)
    .fallbackToDestructiveMigration() // choose your migration strategy
    .build()