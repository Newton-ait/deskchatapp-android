package com.deskchat.ui

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.deskchat.R
import com.deskchat.ui.main.MainActivity
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class MainNavigationTest {

    @get:Rule
    val activityRule = ActivityScenarioRule(MainActivity::class.java)

    @Test
    fun navigateBetweenTabs() {
        onView(withId(R.id.nav_nearby)).perform(click())
        onView(withId(R.id.nav_profile)).perform(click())
        onView(withId(R.id.nav_chat)).perform(click())
    }
}