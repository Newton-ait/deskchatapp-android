# DeskChat — Clean GitHub-ready Project

This cleaned version is safe to upload publicly. Replace placeholders with your real configs.
