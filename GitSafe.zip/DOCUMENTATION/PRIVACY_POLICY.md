Privacy policy template. Replace with actual policy before publishing.
