Terms of use template.
