# DeskChat — Data Handling Notes (internal)

- Local DB: encrypted with SQLCipher; passphrase stored in EncryptedSharedPreferences which uses Android Keystore.
- Attachments: EncryptedFile (AES-256-GCM).
- Cloud: Firestore collections `desks/{deskId}/messages/{messageId}`. TTL configured on `expiresAt`.
- Discovery tokens: ephemeral tokens that rotate per session. No persistent mapping to a user ID.
- Logs: avoid logging PII or message content in production logs.
- Access: restrict Firestore console access to admin accounts.
- Incident response: revoke Firebase keys, rotate server credentials, inform affected users.