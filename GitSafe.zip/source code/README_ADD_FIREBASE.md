# README - Add Firebase

This project uses Firebase. To run the app locally with Firebase features enabled, add your real Firebase configuration:

1. Obtain your `google-services.json` from the Firebase Console for Android.
2. Place the file at `app/google-services.json`.
3. Re-run your Gradle build: `./gradlew clean build`

If you do not add the file, the build will skip applying the google-services plugin (safe mode).
