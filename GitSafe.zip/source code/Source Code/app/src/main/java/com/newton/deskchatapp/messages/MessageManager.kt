package com.newton.deskchatapp.messages

import com.newton.deskchatapp.models.Message

class MessageManager(private val repo: MessagesRepository) {
    suspend fun postMessage(deskId: String, message: Message): Result<Message> {
        return repo.sendMessage(deskId, message)
    }
}
