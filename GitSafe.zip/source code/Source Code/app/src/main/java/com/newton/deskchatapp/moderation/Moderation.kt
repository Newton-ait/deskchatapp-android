package com.newton.deskchatapp.moderation

import java.util.Date

data class ModerationAction(
    val id: String = "",
    val moderatorId: String = "",
    val targetMessageId: String = "",
    val targetUserId: String = "",
    val actionType: ModerationActionType = ModerationActionType.CONTENT_FLAGGED,
    val reason: String = "",
    val timestamp: Date = Date(),
    val expiresAt: Date? = null,
    val evidence: List<String> = emptyList()
)

enum class ModerationActionType {
    MESSAGE_DELETED,
    USER_WARNED,
    USER_MUTED,
    USER_BANNED,
    CONTENT_FLAGGED
}

data class UserReport(
    val id: String = "",
    val reporterId: String = "",
    val reportedUserId: String = "",
    val reportedMessageId: String? = null,
    val reason: String = "",
    val description: String = "",
    val status: ReportStatus = ReportStatus.PENDING,
    val timestamp: Date = Date(),
    val moderatorNotes: String? = null
)

enum class ReportStatus {
    PENDING, UNDER_REVIEW, RESOLVED, DISMISSED
}

data class UserRole(
    val userId: String = "",
    val roles: Set<UserRoleType> = emptySet(),
    val permissions: Set<Permission> = emptySet(),
    val grantedAt: Date = Date(),
    val grantedBy: String = ""
)

enum class UserRoleType {
    USER, MODERATOR, ADMIN, SUPER_ADMIN
}

enum class Permission {
    DELETE_MESSAGES,
    BAN_USERS,
    MUTE_USERS,
    VIEW_REPORTS,
    MANAGE_MODERATORS
}