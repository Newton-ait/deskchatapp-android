Release notes v1.1.0
