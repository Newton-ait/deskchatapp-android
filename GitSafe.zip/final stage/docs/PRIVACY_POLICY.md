Privacy policy draft.
