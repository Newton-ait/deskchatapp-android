📱 DeskChat Hybrid — Build 1.1.0

How to open:
1. Open Android Studio.
2. Click "File" → "Open" → select the DeskChat/ folder.
3. Let Gradle sync (requires Internet once for dependencies).
4. Build → Make Project.
5. Run on your device or emulator (API 26+).

Notes:
- Firebase is pre-linked via google-services.json.
- BLE and Wi-Fi proximity services require location + Bluetooth permissions.
- Release build uses debug signing by default — ready for testing.
- Update keystore in app/build.gradle for Play Store publishing.
