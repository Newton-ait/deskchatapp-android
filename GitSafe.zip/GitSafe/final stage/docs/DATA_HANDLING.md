Data handling notes.
