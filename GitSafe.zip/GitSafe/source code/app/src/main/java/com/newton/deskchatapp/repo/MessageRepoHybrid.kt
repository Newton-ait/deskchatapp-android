package com.newton.deskchatapp.repo

import android.content.Context
import com.newton.deskchatapp.cloud.FirebaseDataSource
import com.newton.deskchatapp.local.MessageDao
import com.newton.deskchatapp.location.LocationHelper
import com.newton.deskchatapp.model.Message
import com.newton.deskchatapp.util.Result
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class MessageRepoHybrid(private val context: Context, private val dao: MessageDao, private val cloud: FirebaseDataSource = FirebaseDataSource()) : IMessageRepo {
    private val locationHelper = LocationHelper(context)
    private var currentLocation: Pair<Double, Double>? = null

    override suspend fun sendMessage(message: Message): Result<Unit> {
        val loc = try { locationHelper.getCurrentLocation() } catch (e: Exception) { null }
        val msgWithLoc = if (loc != null) message.copy(latitude = loc.first, longitude = loc.second) else message
        dao.insertMessage(msgWithLoc)
        return cloud.sendMessage(msgWithLoc)
    }

    override fun listenForMessages(): Flow<List<Message>> = dao.getAllMessages().map { messages ->
        val loc = currentLocation
        if (loc == null) return@map messages
        messages.filter { msg ->
            msg.latitude != null && msg.longitude != null &&
                locationHelper.distanceInMeters(loc.first, loc.second, msg.latitude, msg.longitude) < 1000
        }
    }

    override suspend fun deleteMessage(id: String): Result<Unit> {
        dao.deleteMessage(Message(id = id))
        return cloud.deleteMessage(id)
    }

    override suspend fun markSynced(id: String) { dao.markSynced(id, true) }
}
