package com.newton.deskchatapp.cloud

import com.google.firebase.auth.FirebaseAuth
import com.newton.deskchatapp.model.User
import kotlinx.coroutines.tasks.await
import timber.log.Timber

class AuthManager(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {

    suspend fun signInAnonymously(): User {
        val result = auth.signInAnonymously().await()
        val firebaseUser = result.user
        Timber.i("Signed in anonymously as ${'$'}{firebaseUser?.uid}")

        return User(
            uid = firebaseUser?.uid ?: "",
            displayName = "Anonymous",
            isAnonymous = true
        )
    }

    fun currentUser(): User? {
        val user = auth.currentUser ?: return null
        return User(
            uid = user.uid,
            displayName = user.displayName ?: "Anonymous",
            isAnonymous = user.isAnonymous
        )
    }

    fun signOut() {
        auth.signOut()
        Timber.i("User signed out")
    }
}
