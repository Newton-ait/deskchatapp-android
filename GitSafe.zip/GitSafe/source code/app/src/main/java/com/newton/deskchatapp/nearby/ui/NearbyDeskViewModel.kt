package com.newton.deskchatapp.nearby.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.newton.deskchatapp.nearby.location.GeoGrid
import com.newton.deskchatapp.nearby.location.GpsManager
import com.newton.deskchatapp.repo.MessageRepo
import com.newton.deskchatapp.nearby.bluetooth.BluetoothRepo
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class NearbyDeskViewModel(application: Application) : AndroidViewModel(application) {
    private val gps = GpsManager(application)
    private val repo = MessageRepo(application)
    private val btRepo = BluetoothRepo(application)

    private val _status = MutableStateFlow("idle")
    val status: StateFlow<String> = _status

    fun startNearby() {
        btRepo.startNearby()
        _status.value = "scanning"
    }

    fun stopNearby() {
        btRepo.stopNearby()
        _status.value = "idle"
    }

    fun postMessageAtCurrentLocation(text: String, callback: (Boolean)->Unit) {
        viewModelScope.launch {
            try {
                val loc = gps.getLastLocationCoarse()
                if (loc == null) { callback(false); return@launch }
                val cell = GeoGrid.cellId(loc.first, loc.second)
                repo.postMessage(text, cell)
                callback(true)
            } catch (e: Exception) {
                callback(false)
            }
        }
    }

import kotlinx.coroutines.flow.collect
import com.newton.deskchatapp.nearby.bluetooth.BluetoothManager
import android.app.Application
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import android.app.PendingIntent
import android.content.Intent
import com.newton.deskchatapp.MainActivity
import com.newton.deskchatapp.db.entity.DeskMessage

private val notificationChannelId = "deskchat_messages"

fun observeIncomingFromBluetooth() {
    // collect adverts and insert into Room DB
    viewModelScope.launch {
        // ensure bluetooth scanning is started externally
        btRepo.incoming.collect { advert ->
            try {
                // parse expected broadcast format: id:<id>;cell:<cell>;t:<text>
                val p = advert.payload
                val parts = p.split(";")
                var id = java.util.UUID.randomUUID().toString()
                var cell = ""
                var text = ""
                for (part in parts) {
                    val kv = part.split(":", limit = 2)
                    if (kv.size==2) {
                        when (kv[0]) {
                            "id" -> id = kv[1]
                            "cell" -> cell = kv[1]
                            "t" -> text = kv[1]
                        }
                    }
                }
                val msg = DeskMessage(id=id, text=text, cellHash=cell, timestamp=System.currentTimeMillis(), anonToken = "ble", synced=false)
                repo.insertLocal(msg)
                // show notification briefly
                showNotification(title = "Nearby message", body = text.take(120))
            } catch (e: Exception) {
                // ignore parse errors
            }
        }
    }
}

private fun showNotification(title: String, body: String) {
    try {
        val intent = Intent(getApplication(), MainActivity::class.java)
        val pending = PendingIntent.getActivity(getApplication(), 0, intent, PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(getApplication(), notificationChannelId)
            .setContentTitle(title)
            .setContentText(body)
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentIntent(pending)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(getApplication()).notify((System.currentTimeMillis()%10000).toInt(), n)
    } catch (e: Exception) {
        // ignore
    }
}


// Synchronous helpers used by the simple NearbyActivity polling loop
suspend fun getMessagesForCell(cell: String) : List<com.newton.deskchatapp.db.entity.DeskMessage> {
    return repo.getNearby(cell)
}

// blocking wrappers for simple UI polling (avoid on main thread in production)
fun getMessagesForCellSync(cell: String) : List<com.newton.deskchatapp.db.entity.DeskMessage> {
    var res: List<com.newton.deskchatapp.db.entity.DeskMessage> = listOf()
    try {
        kotlinx.coroutines.runBlocking {
            res = getMessagesForCell(cell)
        }
    } catch (e: Exception) {}
    return res
}

fun getLastCellSync(): String? {
    // Try to fetch current coarse location synchronously (best-effort)
    return try {
        var out: String? = null
        kotlinx.coroutines.runBlocking {
            val loc = gps.getLastLocationCoarse()
            if (loc != null) out = GeoGrid.cellId(loc.first, loc.second)
        }
        out
    } catch (e: Exception) { null }
}


import kotlinx.coroutines.flow.Flow

fun observeMessagesFlow(cell: String): Flow<List<com.newton.deskchatapp.db.entity.DeskMessage>> {
    return repo.observeMessages(cell)
}

}
