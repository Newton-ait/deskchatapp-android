// Top-level Gradle build file — applies common configuration across all modules

buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        // Hilt plugin
        classpath "com.google.dagger:hilt-android-gradle-plugin:2.52"

        // Firebase
        classpath "com.google.gms:google-services:4.4.2"

        // Android Gradle plugin (match your installed version)
        classpath "com.android.tools.build:gradle:8.3.2"

        // Kotlin Gradle plugin
        classpath "org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.24"
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

task clean(type: Delete) {
    delete rootProject.buildDir
}
