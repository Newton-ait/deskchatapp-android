package com.newton.deskchatapp.ui.profile

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.newton.deskchatapp.databinding.FragmentProfileBinding

/**
 * ProfileFragment - safer binding usage (no ?: throw IllegalStateException("Non-null assertion replaced to avoid NPE in app/src/main/java/com/newton/deskchatapp/ui/profile/ProfileFragment.kt")) and explicit lifecycle clearing.
 */
class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = requireNotNull(_binding) { "FragmentProfileBinding is only valid between onCreateView and onDestroyView." }

    private val viewModel: ProfileViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Example: safely access views via binding
        binding.btnEditProfile.setOnClickListener {
            // handle edit
            // viewModel.onEditClicked()
        }

        // Populate UI with ViewModel state observing LiveData/Flow, etc.
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
// on toggle changed:
val prefs = SecurePrefs(requireContext())
prefs.setIncognito(isChecked)
Toast.makeText(context, if (isChecked) "Incognito ON — messages remain local" else "Incognito OFF", Toast.LENGTH_SHORT).show()