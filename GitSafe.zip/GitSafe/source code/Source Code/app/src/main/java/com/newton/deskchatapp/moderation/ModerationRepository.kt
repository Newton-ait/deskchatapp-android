package com.newton.deskchatapp.moderation

import com.google.firebase.firestore.FirebaseFirestore
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.tasks.await
import com.newton.deskchatapp.util.Resource
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.Flow
import com.google.firebase.firestore.Query

@Singleton
class ModerationRepository @Inject constructor(
    private val firestore: FirebaseFirestore
) {
    private val moderationActionsRef = firestore.collection("moderationActions")
    private val userReportsRef = firestore.collection("userReports")
    private val userRolesRef = firestore.collection("userRoles")

    suspend fun reportUser(report: UserReport): Resource<Unit> {
        return try {
            userReportsRef.add(report).await()
            Resource.Success(Unit)
        } catch (e: Exception) {
            Resource.Error("Failed to submit report: ${e.message}", e)
        }
    }

    suspend fun deleteMessage(messageId: String, moderatorId: String, reason: String): Resource<Unit> {
        return try {
            val action = ModerationAction(
                moderatorId = moderatorId,
                targetMessageId = messageId,
                actionType = ModerationActionType.MESSAGE_DELETED,
                reason = reason
            )
            firestore.collection("messages").document(messageId).delete().await()
            moderationActionsRef.add(action).await()
            Resource.Success(Unit)
        } catch (e: Exception) {
            Resource.Error("Failed to delete message: ${e.message}", e)
        }
    }

    fun getPendingReports(): Flow<Resource<List<UserReport>>> = callbackFlow {
        trySend(Resource.Loading())
        val listener = userReportsRef
            .whereEqualTo("status", ReportStatus.PENDING)
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                when {
                    error != null -> trySend(Resource.Error("Failed to load reports: ${error.message}"))
                    snapshot != null -> {
                        val reports = snapshot.documents.mapNotNull { doc ->
                            try { doc.toObject(UserReport::class.java)?.copy(id = doc.id) } catch (e: Exception) { null }
                        }
                        trySend(Resource.Success(reports))
                    }
                }
            }
        awaitClose { listener.remove() }
    }

    suspend fun hasPermission(userId: String, permission: Permission): Boolean {
        return try {
            val snapshot = userRolesRef.document(userId).get().await()
            val userRole = snapshot.toObject(UserRole::class.java)
            userRole?.permissions?.contains(permission) ?: false
        } catch (e: Exception) {
            false
        }
    }
}