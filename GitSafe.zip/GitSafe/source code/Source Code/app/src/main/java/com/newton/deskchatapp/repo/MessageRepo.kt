package com.newton.deskchatapp.repo

import android.content.Context
import com.newton.deskchatapp.db.DeskDatabase
import com.newton.deskchatapp.db.entity.DeskMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

class MessageRepo(private val context: Context) {
    private val db = DeskDatabase.getInstance(context)
    private val dao = db.deskMessageDao()

    suspend fun postLocalMessage(text: String?, cellHash: String, ttlMs: Long = 48L*60L*60L*1000L): DeskMessage {
        val msg = DeskMessage(
            id = UUID.randomUUID().toString(),
            text = text,
            cellHash = cellHash,
            timestamp = System.currentTimeMillis(),
            anonToken = generateAnonToken(),
            synced = false,
            ttlMs = ttlMs
        )
        withContext(Dispatchers.IO) {
            dao.insert(msg)
        }
        return msg
    }

    private fun generateAnonToken(): String {
        return UUID.randomUUID().toString().substring(0,8)
    }

    suspend fun getNearby(cell: String): List<DeskMessage> {
        return withContext(Dispatchers.IO) { dao.getByCell(cell) }
    }

    suspend fun expireOldMessages(): Int {
        val cutoff = System.currentTimeMillis() - (48L*60L*60L*1000L)
        return withContext(Dispatchers.IO) { dao.deleteOlderThan(cutoff) }
    }
}
