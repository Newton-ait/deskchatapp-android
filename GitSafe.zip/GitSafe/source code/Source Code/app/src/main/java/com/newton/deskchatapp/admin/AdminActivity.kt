
package com.newton.deskchatapp.admin

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.newton.deskchatapp.R
import com.newton.deskchatapp.desk.DeskManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AdminActivity : AppCompatActivity() {
    private val deskManager = DeskManager()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)
        val recycler = findViewById<RecyclerView>(R.id.recyclerAdminDesks)
        recycler.layoutManager = LinearLayoutManager(this)

        CoroutineScope(Dispatchers.Main).launch {
            deskManager.listenForAllDesks { desks ->
                recycler.adapter = AdminDeskAdapter(desks)
            }
        }
    }
}
