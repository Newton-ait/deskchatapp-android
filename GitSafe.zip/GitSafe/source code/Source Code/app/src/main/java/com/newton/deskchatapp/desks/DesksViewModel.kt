package com.newton.deskchatapp.desks

import android.location.Location
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.newton.deskchatapp.data.managers.DeskManager
import com.newton.deskchatapp.models.Desk
import com.newton.deskchatapp.models.CreateDeskRequest
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DesksViewModel @Inject constructor(
    private val deskManager: DeskManager
) : ViewModel() {

    private val _desks = MutableStateFlow<List<Desk>>(emptyList())
    val desks: StateFlow<List<Desk>> = _desks.asStateFlow()

    private val _currentLocation = MutableStateFlow<Location?>(null)
    val currentLocation: StateFlow<Location?> = _currentLocation.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    fun updateCurrentLocation(location: Location) {
        _currentLocation.value = location
    }

    fun loadNearbyDesks(userLocation: Location) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            try {
                val radiusInMeters = 1000.0
                val result = deskManager.getDesksNearLocation(
                    com.google.firebase.firestore.GeoPoint(
                        userLocation.latitude,
                        userLocation.longitude
                    ),
                    radiusInMeters
                )
                result.onSuccess { list ->
                    _desks.value = list.sortedBy { desk ->
                        val deskLocation = android.location.Location("desk").apply {
                            latitude = desk.location.latitude
                            longitude = desk.location.longitude
                        }
                        userLocation.distanceTo(deskLocation)
                    }
                }.onFailure {
                    _errorMessage.value = "Failed to load desks: ${it.message}"
                }
            } catch (e: Exception) {
                _errorMessage.value = "Error loading desks: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun createDesk(request: CreateDeskRequest) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val result = deskManager.createDesk(request)
                result.onSuccess { newDesk ->
                    _desks.value = _desks.value + newDesk
                    _currentLocation.value?.let { loadNearbyDesks(it) }
                    _errorMessage.value = "Desk created successfully!"
                }.onFailure {
                    _errorMessage.value = "Failed to create desk: ${it.message}"
                }
            } catch (e: Exception) {
                _errorMessage.value = "Error creating desk: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun clearError() {
        _errorMessage.value = null
    }
}