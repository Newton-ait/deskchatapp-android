package com.newton.deskchatapp.messages

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.newton.deskchatapp.models.Message
import com.newton.deskchatapp.util.Resource
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import java.util.*

sealed class ChatUiState {
    object Idle : ChatUiState()
    object Loading : ChatUiState()
    data class Success(val message: String) : ChatUiState()
    data class Error(val message: String) : ChatUiState()
}

class ChatViewModel @Inject constructor(
    private val messageRepository: MessageRepository
) : ViewModel() {

    private val _messagesState = MutableStateFlow<Resource<List<Message>>>(Resource.Loading())
    val messagesState: StateFlow<Resource<List<Message>>> = _messagesState.asStateFlow()

    private val _uiState = MutableStateFlow<ChatUiState>(ChatUiState.Idle)
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    private var currentDeskId: String? = null

    fun loadMessages(deskId: String) {
        currentDeskId = deskId
        viewModelScope.launch {
            messageRepository.getMessages(deskId).collect { resource ->
                _messagesState.value = resource
                // set ui state lightly
                _uiState.value = when {
                    resource.isLoading -> ChatUiState.Loading
                    resource.isError -> ChatUiState.Error(resource.message ?: "Unknown error")
                    resource.isSuccess -> ChatUiState.Success("Messages loaded")
                    else -> ChatUiState.Idle
                }
            }
        }
    }

    /**
     * Send a text message with optimistic update in messages stream.
     * Repository will also emit the definitive message via Firestore listener.
     */
    fun sendMessage(text: String) {
        val deskId = currentDeskId ?: run {
            _uiState.value = ChatUiState.Error("No desk selected")
            return
        }

        if (text.isBlank()) {
            _uiState.value = ChatUiState.Error("Cannot send empty message")
            return
        }

        viewModelScope.launch {
            // optimistic update
            val current = (_messagesState.value as? Resource.Success)?.data ?: emptyList()
            val temp = Message(
                id = "temp_${System.currentTimeMillis()}",
                deskId = deskId,
                text = text,
                authorId = "local_user",
                createdAt = Date()
            )
            _messagesState.value = Resource.Success(current + temp)

            when (val res = messageRepository.sendMessage(deskId, temp)) {
                is Resource.Success -> {
                    _uiState.value = ChatUiState.Success("Message sent")
                    // the real message will come via repository listener; no further action required
                }
                is Resource.Error -> {
                    // rollback: drop temp
                    val rolledBack = current
                    _messagesState.value = Resource.Success(rolledBack)
                    _uiState.value = ChatUiState.Error(res.message ?: "Failed to send")
                }
                else -> { /* improbable */ }
            }
        }
    }

    fun clearUiState() {
        _uiState.value = ChatUiState.Idle
    }
}