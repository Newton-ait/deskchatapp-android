package com.newton.deskchatapp.nearby.bluetooth

import android.content.Context
import android.os.ParcelUuid
import android.util.Log

// Minimal BLE manager stub. Full production code should include AdvertiseSettings, callbacks and runtime permission checks.
class BluetoothManager(private val context: Context) {
    companion object {
        private const val TAG = "BluetoothManager"
    }

    fun startAdvertising(payload: ByteArray) {
        Log.i(TAG, "startAdvertising called (stub). payloadSize=${payload.size}")
        // TODO: implement Advertiser using BluetoothLeAdvertiser
    }

    fun stopAdvertising() {
        Log.i(TAG, "stopAdvertising called (stub).")
        // TODO: stop advertising
    }

    fun startScanning() {
        Log.i(TAG, "startScanning called (stub).")
        // TODO: start BLE scan and emit discovered adverts
    }

    fun stopScanning() {
        Log.i(TAG, "stopScanning called (stub).")
        // TODO: stop scanning
    }
}
