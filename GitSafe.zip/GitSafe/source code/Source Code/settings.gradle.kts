rootProject.name = "NewDeskChat"
include(":app")
