# DeskChat — Hybrid Social Chat App

DeskChat is a hybrid communication platform that combines **online Firebase chat** with **offline Bluetooth-based proximity messaging**.  
It allows users to send messages, create local “desk graffiti” posts, and communicate nearby — even without internet.

---

## 🌐 Modes

### 1. Online Mode (Firebase)
- Real-time chat using Firebase Firestore.
- Supports individual and group chats.
- Automatically syncs messages when online.

### 2. Nearby Mode (Bluetooth)
- Peer-to-peer communication via Bluetooth sockets.
- Works without mobile data or Wi-Fi.
- Temporary messages that disappear after 24 hours.

### 3. Anonymous Mode
- Allows users to post or chat without a username.
- Ideal for “desk graffiti” or location-tied micro-messages.

---

## 🧠 Architecture

- **Kotlin / Android Jetpack**
- **Firebase Firestore** (online sync)
- **BluetoothAdapter API** (nearby messaging)
- **Room Database** (offline cache)
- **WorkManager** (background sync)
- **MVVM pattern** with `ViewModel` and `LiveData` / `StateFlow`

---

## 📦 Project Structure
