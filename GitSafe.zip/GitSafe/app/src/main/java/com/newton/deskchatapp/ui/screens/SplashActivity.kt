package com.newton.deskchatapp.ui.screens

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.newton.deskchatapp.R

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Simple splash: immediately go to LoginActivity (or Chat if already signed in)
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }
}
