// File: app/src/main/java/com/newton/deskchatapp/di/AppModule.kt
package com.newton.deskchatapp.di

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.messaging.FirebaseMessaging
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * App-level DI module. Provides Firebase instances and application Context.
 *
 * IMPORTANT: This file enables Firestore offline persistence (disk cache).
 * The settings below enable persistence and set a modest cache size. Adjust if necessary.
 */
@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideFirebaseAuth(): FirebaseAuth = FirebaseAuth.getInstance()

    @Provides
    @Singleton
    fun provideFirebaseMessaging(): FirebaseMessaging = FirebaseMessaging.getInstance()

    /**
     * Provide a Firestore instance with offline persistence enabled.
     * Firestore local persistence allows reads/writes while offline; writes are queued and synchronized
     * when connectivity returns.
     */
    @Provides
    @Singleton
    fun provideFirebaseFirestore(): FirebaseFirestore {
        val firestore = FirebaseFirestore.getInstance()
        // Configure offline persistence. These settings are safe to call repeatedly.
        val settings = FirebaseFirestoreSettings.Builder()
            .setPersistenceEnabled(true)
            // optional: tune cache size (bytes). Default is 40MB. Increase if your app needs it.
            // .setCacheSizeBytes(FirebaseFirestoreSettings.CACHE_SIZE_UNLIMITED)
            .build()
        firestore.firestoreSettings = settings
        return firestore
    }

    /**
     * Keep this method if you need to access the Application Context directly in some classes.
     * Hilt already knows how to provide @ApplicationContext, so this is optional but helpful.
     */
    @Provides
    @Singleton
    fun provideApplicationContext(@ApplicationContext context: Context): Context = context
}