package com.newton.deskchatapp

import android.app.Application
import androidx.work.Configuration
import com.google.firebase.FirebaseApp
import timber.log.Timber\nimport androidx.appcompat.app.AppCompatDelegate

class MyApplication : Application(), Configuration.Provider {

    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this)

        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }

        Timber.i("DeskChat Application started.")\n        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
    }

    override fun getWorkManagerConfiguration(): Configuration {
        return Configuration.Builder()
            .setMinimumLoggingLevel(android.util.Log.INFO)
            .build()
    }
}
