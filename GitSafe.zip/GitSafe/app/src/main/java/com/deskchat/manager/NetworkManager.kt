package com.deskchat.manager

import android.content.Context
import com.deskchat.core.utils.NetworkUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.Socket
import java.net.InetSocketAddress

enum class Channel { BLUETOOTH, WIFI_LAN, INTERNET, NONE }

class NetworkManager(private val context: Context) {
    suspend fun chooseChannel(): Channel = withContext(Dispatchers.IO) {
        // Prefer BLE for immediate local interactions, but if wifi LAN is available prefer it for rooms
        if (NetworkUtils.isOnWifi(context)) {
            // quick probe to common local port could be added here
            return@withContext Channel.WIFI_LAN
        }

        // as a fallback, if no wifi choose BLUETOOTH if available on device
        // simplistic: assume bluetooth available
        return@withContext Channel.BLUETOOTH
    }
}
