package com.deskchat.core.notifications

import android.content.Context
import androidx.core.content.edit

/**
 * Stores user notification preferences.
 */
class NotificationPrefs(context: Context) {
    private val prefs = context.getSharedPreferences("notif_prefs", Context.MODE_PRIVATE)

    fun isEnabled(): Boolean = prefs.getBoolean("enabled", true)
    fun setEnabled(value: Boolean) = prefs.edit { putBoolean("enabled", value) }

    fun getQuietHoursStart(): Int = prefs.getInt("quiet_start", 22) // 22:00
    fun getQuietHoursEnd(): Int = prefs.getInt("quiet_end", 7) // 07:00
    fun setQuietHours(start: Int, end: Int) = prefs.edit {
        putInt("quiet_start", start)
        putInt("quiet_end", end)
    }

    fun shouldNotifyNow(): Boolean {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return isEnabled() && !(h >= getQuietHoursStart() || h < getQuietHoursEnd())
    }
}