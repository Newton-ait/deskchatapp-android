package com.deskchat.ui.onboarding

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.deskchat.R
import com.deskchat.ui.main.MainActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class OnboardingActivity : AppCompatActivity() {

    private lateinit var pager: ViewPager2
    private lateinit var adapter: OnboardingPagerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_onboarding)

        pager = findViewById(R.id.onboardingPager)
        adapter = OnboardingPagerAdapter(this)
        pager.adapter = adapter

        val tabLayout: TabLayout = findViewById(R.id.onboardingTabs)
        TabLayoutMediator(tabLayout, pager) { _, _ -> }.attach()

        val btnNext: MaterialButton = findViewById(R.id.btnNext)
        btnNext.setOnClickListener {
            if (pager.currentItem < adapter.itemCount - 1) {
                pager.currentItem++
            } else {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }
        }
    }
}