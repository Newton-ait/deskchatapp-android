package com.deskchat.ui.main

import android.content.Intent
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import com.deskchat.R
import com.deskchat.ui.nearby.NearbyActivity

/**
 * Host fragment that launches the earlier NearbyActivity UI inside a container.
 * If you prefer embedding the Nearby UI, replace this by loading the NearbyFragment class.
 * For now this fragment offers a small button to open full Nearby screen.
 */
class NearbyHostFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val v = inflater.inflate(R.layout.fragment_nearby_host, container, false)
        v.findViewById<View>(R.id.btnOpenNearby)?.setOnClickListener {
            val i = Intent(requireContext(), NearbyActivity::class.java)
            startActivity(i)
        }
        return v
    }
}