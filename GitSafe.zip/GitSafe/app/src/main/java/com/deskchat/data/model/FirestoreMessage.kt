package com.deskchat.data.model

import com.google.firebase.firestore.DocumentSnapshot

data class FirestoreMessage(
    var id: String = "",
    var text: String = "",
    var senderAlias: String? = null,
    var timestamp: Long = System.currentTimeMillis(),
    var expiresAt: Long = timestamp + 1000L * 60 * 60 * 24, // default 24h
    var lat: Double? = null,
    var lng: Double? = null,
    var status: String = "sent", // sent | delivered | read
    var deskId: String = "",
    var ephemeral: Boolean = true
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "text" to text,
        "senderAlias" to senderAlias,
        "timestamp" to timestamp,
        "expiresAt" to expiresAt,
        "lat" to lat,
        "lng" to lng,
        "status" to status,
        "deskId" to deskId,
        "ephemeral" to ephemeral
    )

    companion object {
        fun fromSnapshot(snap: DocumentSnapshot): FirestoreMessage {
            val map = snap.data ?: emptyMap<String, Any?>()
            val msg = FirestoreMessage()
            msg.id = snap.id
            msg.text = map["text"] as? String ?: ""
            msg.senderAlias = map["senderAlias"] as? String
            msg.timestamp = (map["timestamp"] as? Long) ?: System.currentTimeMillis()
            msg.expiresAt = (map["expiresAt"] as? Long) ?: (msg.timestamp + 1000L * 60 * 60 * 24)
            msg.lat = (map["lat"] as? Double)
            msg.lng = (map["lng"] as? Double)
            msg.status = map["status"] as? String ?: "sent"
            msg.deskId = map["deskId"] as? String ?: ""
            msg.ephemeral = map["ephemeral"] as? Boolean ?: true
            return msg
        }
    }
}