package com.deskchat.core.notifications

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.deskchat.data.local.db.DeskChatDatabase
import com.deskchat.data.repository.MessageRepository
import timber.log.Timber

/**
 * Periodic background job that checks for nearby messages in DB
 * and notifies user intelligently based on time and preferences.
 */
class NearbyNotificationWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    private val prefs = NotificationPrefs(context)
    private val repo = MessageRepository.getInstance(context)
    private val db = DeskChatDatabaseHolder.instance(context)

    override suspend fun doWork(): Result {
        if (!prefs.shouldNotifyNow()) {
            Timber.d("Quiet hours or notifications disabled")
            return Result.success()
        }

        val messages = db.messageDao().getAll()
        if (messages.isNotEmpty()) {
            val latest = messages.first()
            NotificationUtils.showNearbyNotification(
                applicationContext,
                "Someone nearby posted!",
                latest.text.take(80)
            )
            Timber.d("🔔 Sent nearby message notification")
        } else {
            Timber.d("No nearby messages found for notification")
        }

        return Result.success()
    }
}