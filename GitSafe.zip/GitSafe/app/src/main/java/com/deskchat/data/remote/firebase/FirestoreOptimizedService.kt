package com.deskchat.data.remote.firebase

import com.deskchat.data.model.FirestoreMessage
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.delay
import kotlinx.coroutines.tasks.await
import timber.log.Timber
import kotlin.math.min
import kotlin.math.pow

/**
 * FirestoreOptimizedService
 * - batches writes where possible
 * - provides retry with exponential backoff for intermittent failures
 * - keeps per-desk operation lightweight
 */
class FirestoreOptimizedService {
    private val db = FirebaseFirestore.getInstance()
    private val desksColl = db.collection("desks")

    suspend fun sendMessageWithRetry(deskId: String, message: FirestoreMessage, maxRetries: Int = 4): String {
        var attempt = 0
        var lastEx: Exception? = null
        while (attempt <= maxRetries) {
            try {
                val col = desksColl.document(deskId).collection("messages")
                val docRef = col.document(message.id.ifBlank { col.document().id })
                docRef.set(message.toMap()).await()
                return docRef.id
            } catch (e: Exception) {
                lastEx = e
                attempt++
                val backoff = computeBackoffMs(attempt)
                Timber.w(e, "Firestore write failed. attempt=$attempt backoff=$backoff ms")
                delay(backoff)
            }
        }
        throw lastEx ?: IllegalStateException("sendMessageWithRetry failed")
    }

    private fun computeBackoffMs(attempt: Int): Long {
        // exponential backoff with jitter: base 300ms
        val base = 300L
        val exp = (2.0.pow(attempt.toDouble()) * base).toLong()
        val jitter = (base..(base * 2)).random()
        return min(10_000L, exp + jitter)
    }

    /**
     * Bulk write helper for batching multiple messages in one write (server side)
     * Firestore limits: 500 operations per batch.
     */
    suspend fun batchWriteMessages(deskId: String, messages: List<FirestoreMessage>) {
        if (messages.isEmpty()) return
        val batch = db.batch()
        val colRef = desksColl.document(deskId).collection("messages")
        for (m in messages) {
            val doc = colRef.document(m.id.ifBlank { colRef.document().id })
            batch.set(doc, m.toMap())
        }
        // Firestore batch commit is a network call; retry with backoff if needed
        var attempt = 0
        while (true) {
            try {
                batch.commit().await()
                return
            } catch (e: Exception) {
                attempt++
                if (attempt > 5) throw e
                val backoff = computeBackoffMs(attempt)
                Timber.w(e, "Batch commit failed attempt=$attempt, retrying in $backoff ms")
                delay(backoff)
            }
        }
    }
}