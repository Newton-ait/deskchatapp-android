package com.deskchat.core.telemetry

import android.os.SystemClock
import timber.log.Timber

object StartupTimer {
    private var t0: Long = 0L

    fun markStart() {
        t0 = SystemClock.elapsedRealtime()
        Timber.d("StartupTimer: start marked")
    }

    fun mark(name: String) {
        if (t0 == 0L) t0 = SystemClock.elapsedRealtime()
        val now = SystemClock.elapsedRealtime()
        Timber.i("StartupTimer: $name at ${now - t0} ms")
    }

    fun finishAndLog(label: String = "cold_start") {
        if (t0 == 0L) {
            Timber.w("StartupTimer: finish called before start")
            return
        }
        val dur = SystemClock.elapsedRealtime() - t0
        Timber.i("StartupTimer: $label completed in $dur ms")
        t0 = 0L
    }
}