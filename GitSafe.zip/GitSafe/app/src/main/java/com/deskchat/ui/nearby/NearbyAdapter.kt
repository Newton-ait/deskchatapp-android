package com.deskchat.ui.nearby

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.deskchat.R
import com.deskchat.data.remote.bluetooth.ScannedDevice
import java.util.concurrent.TimeUnit

class NearbyAdapter(private val onClick: (NearbyEntry) -> Unit) :
    RecyclerView.Adapter<NearbyAdapter.VH>() {

    private val items = mutableListOf<NearbyEntry>()

    fun set(itemsList: List<NearbyEntry>) {
        items.clear()
        items.addAll(itemsList)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(android.R.layout.simple_list_item_2, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val e = items[position]
        holder.title.text = e.device.id
        holder.sub.text = formatSub(e)
        holder.itemView.setOnClickListener { onClick(e) }
    }

    override fun getItemCount(): Int = items.size

    private fun formatSub(e: NearbyEntry): String {
        val d = e.distanceMeters
        val ds = if (d >= 1000) String.format("%.2f km", d / 1000.0) else String.format("%.0f m", d)
        val ago = System.currentTimeMillis() - e.lastSeen
        val secs = TimeUnit.MILLISECONDS.toSeconds(ago)
        val seen = if (secs < 5) "just now" else "$secs s ago"
        return "$ds • RSSI=${e.device.rssi} • $seen"
    }

    class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title: TextView = itemView.findViewById(android.R.id.text1)
        val sub: TextView = itemView.findViewById(android.R.id.text2)
    }
}