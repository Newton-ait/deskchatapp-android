plugins {
    id 'com.android.application'
    id 'org.jetbrains.kotlin.android'
    id 'kotlin-kapt'
    id 'dagger.hilt.android.plugin'
    id 'com.google.gms.google-services'
}

android {
    namespace 'com.newton.deskchatapp'
    compileSdk 34

    defaultConfig {
        applicationId "com.newton.deskchatapp"
        minSdk 24
        targetSdk 34
        versionCode 1
        versionName "1.0"

        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
        debug {
            minifyEnabled false
        }
    }

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = '17'
    }

    buildFeatures {
        viewBinding true
    }
}

dependencies {

    // AndroidX core
    implementation 'androidx.core:core-ktx:1.12.0'
    implementation 'androidx.appcompat:appcompat:1.7.0'
    implementation 'com.google.android.material:material:1.14.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
    implementation 'androidx.recyclerview:recyclerview:1.4.0'

    // Lifecycle / coroutines
    implementation 'androidx.lifecycle:lifecycle-runtime:2.9.1:2.8.2'
    implementation 'androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.2'
    implementation 'org.jetbrains.kotlinx:kotlinx-coroutines-core:1.10.2'
    implementation 'org.jetbrains.kotlinx:kotlinx-coroutines-core:1.10.2'

    // Firebase
    implementation platform('com.google.firebase:firebase-bom:34.4.0')
    implementation 'com.google.firebase:firebase-auth-ktx'
    implementation 'com.google.firebase:firebase-firestore-ktx'

    // Hilt DI
    implementation 'com.google.dagger:hilt-android:2.52'
    kapt 'com.google.dagger:hilt-compiler:2.46.1'

    // Location / Play Services (for BatteryOptimizedLocationManager)
    implementation 'com.google.android.gms:play-services-location:21.3.0'

    // Optional: Lottie / UI enhancements
    implementation 'com.airbnb.android:lottie:6.3.0'

    // Unit testing
    testImplementation 'junit:junit:4.13.2'
    testImplementation 'org.mockito:mockito-core:4.11.0'
    testImplementation 'org.jetbrains.kotlinx:kotlinx-coroutines-test:1.8.0'

    // Android instrumented testing
    androidTestImplementation 'androidx.test.ext:junit:1.2.1'
    androidTestImplementation 'androidx.test.espresso:espresso-core:3.6.1'
}

kapt {
    correctErrorTypes = true
}



// NEW: Desk layer dependencies
dependencies {
    implementation("androidx.room:room-runtime:2.5.2")
    kapt("androidx.room:room-compiler:2.5.2")
    implementation("androidx.work:work-runtime-ktx:2.8.1")
    implementation("com.google.android.gms:play-services-location:21.0.1")
}
