package com.deskchat

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.deskchat.data.repository.NetworkManager
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class EdgeCaseTest {

    @Test
    fun testHandlesOfflineModeGracefully() {
        val ctx = InstrumentationRegistry.getInstrumentation().targetContext
        val nm = NetworkManager(ctx)
        nm.simulateOfflineMode() // helper you can stub in NetworkManager
        assertTrue("App should enter offline mode safely", nm.isOffline())
    }

    @Test
    fun testPermissionDeniedDoesNotCrash() {
        // Mock PermissionUtils to return false and assert no exception thrown
        val ctx = InstrumentationRegistry.getInstrumentation().targetContext
        val exception = runCatching {
            // Simulate starting Nearby without permission
            // Should handle internally
        }.exceptionOrNull()
        assertTrue("No crash when permissions denied", exception == null)
    }
}