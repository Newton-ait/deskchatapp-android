package com.newton.deskchatapp

import com.newton.deskchatapp.nearby.location.GeoGrid
import org.junit.Assert.assertEquals
import org.junit.Test

class GeoGridTest {
    @Test
    fun testCellStable() {
        val c1 = GeoGrid.cellId(0.123456, 32.123456)
        val c2 = GeoGrid.cellId(0.123499, 32.123499)
        // Should map to same coarse cell with our truncation method
        assertEquals(c1, c2)
    }
}
