package com.newton.deskchatapp.nearby.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.newton.deskchatapp.R
import com.newton.deskchatapp.db.entity.DeskMessage

class NearbyListAdapter(private var items: List<DeskMessage>) : RecyclerView.Adapter<NearbyListAdapter.VH>() {
    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.nearby_item_text)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_nearby, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val m = items[position]
        holder.title.text = m.text ?: "(no text)"
    }

    override fun getItemCount(): Int = items.size

    fun update(newItems: List<DeskMessage>) {
        items = newItems
        notifyDataSetChanged()
    }
}
