package com.deskchat.ui.nearby

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import com.deskchat.R
import com.deskchat.data.model.FirestoreMessage
import com.deskchat.data.repository.MessageRepository
import com.deskchat.location.GeoGrid
import com.deskchat.location.LocationManager
import kotlinx.android.synthetic.main.activity_send_air_message.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import timber.log.Timber
import java.util.*

/**
 * UI screen for sending an anonymous air message tied to a geo-cell.
 * Flow:
 *  - get one-shot location via LocationManager.requestSingleUpdate()
 *  - compute deskId via GeoGrid
 *  - create FirestoreMessage with expiresAt and location
 *  - call MessageRepository.sendAirMessage(...)
 *
 * Note: MessageRepository expects actual implementations of bluetooth/wifi/firebase to be present.
 */
class SendAirMessageActivity : AppCompatActivity() {

    private lateinit var locationManager: LocationManager
    private lateinit var messageRepo: MessageRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_send_air_message)

        locationManager = LocationManager(applicationContext)

        // MessageRepository: construct using your project's dependencies.
        // If you use DI, inject it. For this sample we instantiate a minimal stub that requires wiring.
        messageRepo = MessageRepository.getInstance(applicationContext) // helper below provided

        // setup expiry spinner
        val adapter = ArrayAdapter.createFromResource(this, R.array.expiry_options, android.R.layout.simple_spinner_item)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerExpiry.adapter = adapter

        etAirMessage.doAfterTextChanged {
            tvStatus.text = ""
        }

        btnSendAir.setOnClickListener {
            val text = etAirMessage.text.toString().trim()
            if (text.isEmpty()) {
                tvStatus.text = "Please write a message before sending."
                return@setOnClickListener
            }
            sendAirMessage(text)
        }
    }

    private fun sendAirMessage(text: String) {
        tvStatus.text = "Getting location..."
        btnSendAir.isEnabled = false

        // get one-shot location (will call callback even with lastLocation fallback)
        locationManager.requestSingleUpdate { location ->
            if (location == null) {
                runOnUiThread {
                    tvStatus.text = "Could not get location. Try again."
                    btnSendAir.isEnabled = true
                }
                return@requestSingleUpdate
            }

            val lat = location.latitude
            val lng = location.longitude
            val expiryChoice = spinnerExpiry.selectedItemPosition
            val expiryHours = when (expiryChoice) {
                0 -> 1
                1 -> 6
                2 -> 24
                3 -> 48
                else -> 24
            }
            val expiresAt = System.currentTimeMillis() + expiryHours * 3600L * 1000L

            val deskId = GeoGrid.toCellId(lat, lng, 100) // 100m grid cell

            val msg = FirestoreMessage(
                id = UUID.randomUUID().toString(),
                text = text,
                senderAlias = null,
                timestamp = System.currentTimeMillis(),
                expiresAt = expiresAt,
                lat = lat,
                lng = lng,
                status = "sent",
                deskId = deskId,
                ephemeral = true
            )

            // Save + send on background coroutine
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    messageRepo.sendAirMessage(msg) // implemented below in MessageRepository
                    runOnUiThread {
                        tvStatus.text = "Message sent to desk: $deskId"
                        etAirMessage.setText("")
                        btnSendAir.isEnabled = true
                    }
                } catch (e: Exception) {
                    Timber.e(e, "Failed to send air message")
                    runOnUiThread {
                        tvStatus.text = "Failed to send: ${e.message}"
                        btnSendAir.isEnabled = true
                    }
                }
            }
        }
    }
}