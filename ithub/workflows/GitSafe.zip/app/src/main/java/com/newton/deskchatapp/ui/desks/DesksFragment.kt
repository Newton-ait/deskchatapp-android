package com.newton.deskchatapp.ui.desks

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.newton.deskchatapp.databinding.FragmentDesksBinding

/**
 * DesksFragment - safer binding and adapter usage.
 */
class DesksFragment : Fragment() {

    private var _binding: FragmentDesksBinding? = null
    private val binding get() = requireNotNull(_binding) { "FragmentDesksBinding is only valid between onCreateView and onDestroyView." }

    private val adapter: DeskAdapter by lazy { DeskAdapter() }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentDesksBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.recyclerDesks.adapter = adapter

        // Example: update adapter data safely
        // adapter.submitList(viewModel.currentDesks)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        // detach adapter to help GC if necessary
        binding.recyclerDesks.adapter = null
        _binding = null
    }
}