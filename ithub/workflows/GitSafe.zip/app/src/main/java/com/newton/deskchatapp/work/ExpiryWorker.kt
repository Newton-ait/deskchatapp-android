package com.newton.deskchatapp.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.newton.deskchatapp.repo.MessageRepo
import android.util.Log

class ExpiryWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val repo = MessageRepo(applicationContext)
        return try {
            val deleted = repo.expireOldMessages()
            Log.i("ExpiryWorker", "Deleted $deleted expired messages")
            Result.success()
        } catch (e: Exception) {
            Result.failure()
        }
    }
}
