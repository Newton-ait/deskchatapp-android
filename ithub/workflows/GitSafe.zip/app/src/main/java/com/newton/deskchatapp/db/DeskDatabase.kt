package com.newton.deskchatapp.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.newton.deskchatapp.db.dao.DeskMessageDao
import com.newton.deskchatapp.db.entity.DeskMessage

@Database(entities = [DeskMessage::class], version = 1)
abstract class DeskDatabase : RoomDatabase() {
    abstract fun deskMessageDao(): DeskMessageDao

    companion object {
        @Volatile private var INSTANCE: DeskDatabase? = null

        fun getInstance(context: Context): DeskDatabase {
            return INSTANCE ?: synchronized(this) {
                val inst = Room.databaseBuilder(context.applicationContext, DeskDatabase::class.java, "desk_db")
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = inst
                inst
            }
        }
    }
}
