const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp();
const { Configuration, OpenAIApi } = require('openai');
const OPENAI_KEY = process.env.OPENAI_API_KEY || functions.config().openai?.key;
const configuration = new Configuration({ apiKey: OPENAI_KEY });
const openai = new OpenAIApi(configuration);

exports.deskbotReply = functions.https.onCall(async (data, context) => {
  const prompt = data.prompt || '';
  if (!prompt) throw new functions.https.HttpsError('invalid-argument', 'No prompt');
  try {
    const resp = await openai.createChatCompletion({ model: 'gpt-4o-mini', messages: [{role:'system', content: 'You are DeskBot, a friendly assistant.'}, {role:'user', content: prompt}], max_tokens:200 });
    const reply = resp.data.choices?.[0]?.message?.content || '';
    return { ok: true, reply };
  } catch (e) { console.error('deskbot error', e); throw new functions.https.HttpsError('internal', 'AI error'); }
});

exports.transcribeVoiceNote = functions.https.onCall(async (data, context) => {
  const storagePath = data.storagePath;
  if (!storagePath) throw new functions.https.HttpsError('invalid-argument', 'No storagePath');
  try {
    const bucket = admin.storage().bucket();
    const tmpFile = '/tmp/voice_' + Date.now();
    await bucket.file(storagePath).download({ destination: tmpFile });
    const fs = require('fs');
    const resp = await openai.createTranscription(fs.createReadStream(tmpFile), 'whisper-1');
    const transcript = resp.data.text || '';
    await admin.firestore().collection('transcripts').add({ storagePath, transcript, createdAt: admin.firestore.FieldValue.serverTimestamp() });
    return { ok: true, transcript };
  } catch (e) { console.error('transcription error', e); throw new functions.https.HttpsError('internal', 'Transcription failed'); }
});

exports.expireOldPosts = functions.pubsub.schedule('every 1 hours').onRun(async (context) => {
  const now = Date.now();
  const snap = await admin.firestore().collection('air_posts').where('expiresAt', '<=', now).get();
  const batch = admin.firestore().batch();
  snap.forEach(doc => batch.delete(doc.ref));
  await batch.commit();
  console.log('Expired posts cleaned up:', snap.size);
  return null;
});

exports.moderateText = functions.https.onCall(async (data, context) => {
  const text = data.text || '';
  if (!text) throw new functions.https.HttpsError('invalid-argument', 'No text');
  try {
    const prompt = `Classify the following message as SAFE or FLAGGED. If FLAGGED, give reason.\n\nMessage:\n${text}`;
    const resp = await openai.createChatCompletion({ model: 'gpt-4o-mini', messages:[{role:'system',content:'You are a moderation assistant'},{role:'user',content:prompt}], max_tokens:60, temperature:0 });
    const reply = resp.data.choices?.[0]?.message?.content || '';
    const flagged = reply.toLowerCase().includes('flagged');
    return { flagged, reason: reply };
  } catch (e) { console.error('moderation error', e); return { flagged: false, reason: 'error' }; }
});
