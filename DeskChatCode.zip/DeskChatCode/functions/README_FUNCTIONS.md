    Firebase Functions included (active-ready). Set OPENAI_API_KEY via firebase functions:config:set openai.key="YOUR_KEY" before deployment.
Deploy: cd functions && npm install && firebase deploy --only functions
