    package com.deskchatapp.sync

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.deskchatapp.local.LocalDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MessageSyncWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val db = LocalDatabase.getInstance(applicationContext)
            val dao = db.localMessageDao()
            dao.deleteExpired(System.currentTimeMillis())
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
