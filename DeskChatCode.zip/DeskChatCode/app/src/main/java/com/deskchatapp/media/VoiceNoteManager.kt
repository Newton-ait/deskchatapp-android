    package com.deskchatapp.media

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.util.Log
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class VoiceNoteManager(private val context: Context) {
    private var recorder: MediaRecorder? = null
    private var player: MediaPlayer? = null
    private var currentFile: File? = null
    private val TAG = "VoiceNoteManager"

    fun startRecording(): String? {
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val file = File(context.cacheDir, "voicenote_${'$'}{ts}.m4a")
        currentFile = file
        recorder = MediaRecorder().apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setOutputFile(file.absolutePath)
            try { prepare(); start() } catch (e: IOException) { Log.e(TAG, "prepare/start failed: ${'$'}{e.message}") }
        }
        return file.absolutePath
    }

    fun stopRecording(): String? {
        try { recorder?.stop() } catch (_: Exception) {}
        recorder?.release(); recorder = null
        return currentFile?.absolutePath
    }

    fun play(path: String) {
        try {
            player?.release()
            player = MediaPlayer().apply { setDataSource(path); prepare(); start() }
        } catch (e: Exception) { Log.e(TAG, "play failed: ${'$'}{e.message}") }
    }

    fun stopPlayback() { player?.release(); player = null }
}
