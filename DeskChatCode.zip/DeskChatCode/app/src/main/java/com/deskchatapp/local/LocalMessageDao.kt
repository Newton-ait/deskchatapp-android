    package com.deskchatapp.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface LocalMessageDao {
    @Insert
    suspend fun insert(message: LocalMessage)

    @Query("SELECT * FROM local_messages ORDER BY timestamp DESC")
    suspend fun getAll(): List<LocalMessage>

    @Query("DELETE FROM local_messages WHERE expiresAt <= :now")
    suspend fun deleteExpired(now: Long)
}
