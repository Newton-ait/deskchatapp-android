    package com.deskchatapp.moderation

import android.content.Context
import android.util.Log
import com.google.firebase.functions.ktx.functions
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class ModerationManager(private val context: Context) {
    private val TAG = "ModerationManager"
    private val functions = Firebase.functions

    fun checkText(text: String, onResult: (Boolean, String?) -> Unit) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val data = hashMapOf("text" to text)
                val call = functions.getHttpsCallable("moderateText").call(data).await()
                val map = call.data as? Map<*, *>
                val flagged = map?.get("flagged") as? Boolean ?: false
                val reason = map?.get("reason") as? String
                CoroutineScope(Dispatchers.Main).launch { onResult(flagged, reason) }
            } catch (e: Exception) { Log.e(TAG, "moderation error: ${'$'}{e.message}"); CoroutineScope(Dispatchers.Main).launch { onResult(false, e.message) } }
        }
    }
}
