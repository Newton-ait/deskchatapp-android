    package com.deskchatapp.ai

import android.content.Context
import android.util.Log
import com.google.firebase.functions.ktx.functions
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class DeskBotManager(private val context: Context) {
    private val TAG = "DeskBotManager"
    private val functions = Firebase.functions

    fun suggestRemoteReply(prompt: String, onResult: (String?, String?) -> Unit) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val data = hashMapOf("prompt" to prompt)
                val call = functions.getHttpsCallable("deskbotReply").call(data).await()
                val map = call.data as? Map<*, *>
                val reply = map?.get("reply") as? String
                CoroutineScope(Dispatchers.Main).launch { onResult(reply, null) }
            } catch (e: Exception) {
                Log.e(TAG, "remote bot error: ${'$'}{e.message}")
                CoroutineScope(Dispatchers.Main).launch { onResult(null, e.message) }
            }
        }
    }

    fun suggestLocalReply(message: String, onResult: (String) -> Unit) {
        val suggestion = when {
            message.contains("hello", true) -> "Hey! Want to chat?"
            message.length < 30 -> "Nice — tell me more!"
            else -> "That's interesting — what's next?"
        }
        onResult(suggestion)
    }
}
