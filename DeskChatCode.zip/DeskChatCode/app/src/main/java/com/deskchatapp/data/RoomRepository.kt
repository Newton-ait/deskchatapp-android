    package com.deskchatapp.data

import android.util.Log
import com.google.firebase.Timestamp
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.tasks.await

class RoomRepository {
    private val TAG = "RoomRepository"
    private val db = Firebase.firestore

    suspend fun sendMessage(roomId: String, msgId: String, authorId: String, text: String) : Boolean {
        return try {
            val doc = hashMapOf<String, Any>("authorId" to authorId, "text" to text, "createdAt" to Timestamp.now())
            db.collection("rooms").document(roomId).collection("messages").document(msgId).set(doc).await()
            true
        } catch (e: Exception) { Log.e(TAG, "sendMessage error: ${'$'}{e.message}"); false }
    }
}
