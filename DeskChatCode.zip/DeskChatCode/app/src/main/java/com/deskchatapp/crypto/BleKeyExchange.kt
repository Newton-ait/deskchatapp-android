    package com.deskchatapp.crypto

import android.util.Base64
import android.util.Log

object BleKeyExchange {
    private val TAG = "BleKeyExchange"

    fun fingerprintFromPubkey(pubKeyBase64: String): ByteArray {
        val bytes = Base64.decode(pubKeyBase64, Base64.NO_WRAP)
        val sha = java.security.MessageDigest.getInstance("SHA-256").digest(bytes)
        return sha.copyOfRange(0, 12)
    }

    fun exampleOnPeerReceived(peerPubBase64: String) {
        try {
            val peerBytes = Base64.decode(peerPubBase64, Base64.NO_WRAP)
            val aes = E2EEUtils.deriveSharedAesKey(peerBytes)
            Log.d(TAG, "Derived AES key length=${'$'}{aes.size}")
        } catch (e: Exception) { Log.e(TAG, "Key exchange failed: ${'$'}{e.message}") }
    }
}
