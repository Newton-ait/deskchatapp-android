    package com.deskchatapp.data

import android.util.Log
import com.google.firebase.Timestamp
import com.google.firebase.firestore.GeoPoint
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.tasks.await

class AirPostRepository {
    private val TAG = "AirPostRepository"
    private val db = Firebase.firestore

    suspend fun publishAirPost(postId: String, authorId: String, text: String, lat: Double?, lon: Double?) : Boolean {
        return try {
            val doc = hashMapOf<String, Any>(
                "authorId" to authorId,
                "text" to text,
                "createdAt" to Timestamp.now(),
                "expiresAt" to (System.currentTimeMillis() + 24*60*60*1000)
            )
            if (lat != null && lon != null) doc["location"] = GeoPoint(lat, lon)
            db.collection("air_posts").document(postId).set(doc).await()
            true
        } catch (e: Exception) { Log.e(TAG, "publish error: ${'$'}{e.message}"); false }
    }
}
