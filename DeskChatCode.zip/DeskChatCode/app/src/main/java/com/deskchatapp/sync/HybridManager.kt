    package com.deskchatapp.sync

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import com.deskchatapp.local.LocalDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class HybridManager(private val context: Context) {
    private val TAG = "HybridManager"
    private val db = LocalDatabase.getInstance(context)
    private val scope = CoroutineScope(Dispatchers.IO)

    private fun isOnline(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun sendText(message: String, senderId: String) {
        scope.launch {
            val msg = com.deskchatapp.local.LocalMessage(messageId = java.util.UUID.randomUUID().toString(), senderId = senderId, text = message)
            db.localMessageDao().insert(msg)
            if (isOnline()) {
                Log.d(TAG, "Online: would upload message ${'$'}{msg.messageId}")
            } else {
                Log.d(TAG, "Offline: queued message ${'$'}{msg.messageId} for peer transfer")
            }
        }
    }
}
