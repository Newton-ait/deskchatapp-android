    package com.deskchatapp.crypto

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.spec.ECGenParameterSpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.KeyAgreement
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlin.random.Random

object E2EEUtils {
    private const val KEY_ALIAS = "deskchat_ec"

    fun ensureKeyPair() {
        try {
            val kpg = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore")
            val spec = KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_AGREE_KEY or KeyProperties.PURPOSE_SIGN)
                .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
                .setDigests(KeyProperties.DIGEST_SHA256)
                .build()
            kpg.initialize(spec)
            kpg.generateKeyPair()
        } catch (_: Exception) { }
    }

    fun getPublicKeyBase64(): String {
        val ks = java.security.KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        val entry = ks.getEntry(KEY_ALIAS, null) as java.security.KeyStore.PrivateKeyEntry
        val pub = entry.certificate.publicKey.encoded
        return Base64.encodeToString(pub, Base64.NO_WRAP)
    }

    fun deriveSharedAesKey(peerPublicKeyBytes: ByteArray): ByteArray {
        val ks = java.security.KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        val entry = ks.getEntry(KEY_ALIAS, null) as java.security.KeyStore.PrivateKeyEntry
        val privateKey = entry.privateKey
        val keyFactory = KeyFactory.getInstance("EC")
        val pubSpec = X509EncodedKeySpec(peerPublicKeyBytes)
        val peerPub = keyFactory.generatePublic(pubSpec)
        val ka = KeyAgreement.getInstance("ECDH")
        ka.init(privateKey)
        ka.doPhase(peerPub, true)
        val shared = ka.generateSecret()
        val sha = java.security.MessageDigest.getInstance("SHA-256")
        return sha.digest(shared)
    }

    fun aesGcmEncrypt(aesKey: ByteArray, plaintext: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val keySpec = SecretKeySpec(aesKey, "AES")
        val iv = ByteArray(12).also { Random.Default.nextBytes(it) }
        val spec = GCMParameterSpec(128, iv)
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, spec)
        val cipherText = cipher.doFinal(plaintext)
        return iv + cipherText
    }

    fun aesGcmDecrypt(aesKey: ByteArray, ivAndCipher: ByteArray): ByteArray {
        val iv = ivAndCipher.copyOfRange(0, 12)
        val cipherText = ivAndCipher.copyOfRange(12, ivAndCipher.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val keySpec = SecretKeySpec(aesKey, "AES")
        val spec = GCMParameterSpec(128, iv)
        cipher.init(Cipher.DECRYPT_MODE, keySpec, spec)
        return cipher.doFinal(cipherText)
    }
}
