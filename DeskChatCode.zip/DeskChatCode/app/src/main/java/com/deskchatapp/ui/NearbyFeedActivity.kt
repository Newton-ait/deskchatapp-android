    package com.deskchatapp.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.deskchatapp.data.AirPostRepository
import com.deskchatapp.moderation.ModerationManager
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class NearbyFeedActivity : AppCompatActivity() {
    private val airRepo = AirPostRepository()
    private lateinit var moderation: ModerationManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(android.R.layout.activity_list_item)
        moderation = ModerationManager(this)
        val fab = FloatingActionButton(this)
        fab.setOnClickListener { dropAirMessage() }
    }

    private fun dropAirMessage() {
        val text = "Hello from DeskChat"
        moderation.checkText(text) { flagged, reason ->
            if (flagged) runOnUiThread { Toast.makeText(this, "Message flagged: ${'$'}{reason}", Toast.LENGTH_LONG).show() }
            else {
                CoroutineScope(Dispatchers.IO).launch {
                    val ok = airRepo.publishAirPost(System.currentTimeMillis().toString(), "anon", text, null, null)
                    runOnUiThread { Toast.makeText(this@NearbyFeedActivity, if (ok) "Dropped" else "Failed", Toast.LENGTH_SHORT).show() }
                }
            }
        }
    }
}
