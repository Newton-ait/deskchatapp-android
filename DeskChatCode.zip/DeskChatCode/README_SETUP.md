    DeskChat Final Stage 12 - Combined Project

This project is your original DeskChat app with Stage 12 upgrades applied:
- Adaptive icon (white background) added at app/src/main/res/mipmap-anydpi-v26/
- Firebase Functions folder added (functions/)
- GitHub Actions workflow added (.github/workflows/android.yml)

How to build locally:
1. Open this folder in Android Studio
2. Add your google-services.json into app/
3. Sync Gradle and build

How to deploy functions:
1. cd functions && npm install
2. firebase functions:config:set openai.key="YOUR_KEY"
3. firebase deploy --only functions


Stage 12 Upgrades Applied:
- HybridManager, VoiceNoteManager, DeskBotManager, E2EE utilities, BLE key exchange helpers
- MessageSyncWorker, Local Room DB, AirPostRepository, RoomRepository, ModerationManager
- Firebase Functions: deskbotReply, transcribeVoiceNote, expireOldPosts, moderateText

Build notes: place google-services.json into app/ and run Gradle build in Android Studio.
