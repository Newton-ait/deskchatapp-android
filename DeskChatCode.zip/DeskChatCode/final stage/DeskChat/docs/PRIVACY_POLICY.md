# DeskChat — Privacy Policy (draft)

**Last updated:** 29 Oct 2015

## Summary
DeskChat is an anonymous, proximity-based messaging app. We minimize data collection: messages are ephemeral, location is coarse-grained, and personal identifiers are optional.

## What we collect
- Anonymous ephemeral messages (text), optionally tagged with a coarse location cell.
- Device ephemeral tokens used for nearby discovery (rotating, not tied to user identity).
- Optional analytics (if enabled) — limited to app usage metrics.

## How we store data
- Local storage: messages are stored encrypted on-device (SQLCipher).
- Cloud: messages are uploaded to Firestore only when you permit (Incognito mode disables uploads). Firestore stores `desks/{deskId}/messages`.
- Attachments (if any) are stored as encrypted files using `EncryptedFile`.

## Retention
- Messages expire by default after 24 hours. Firestore TTL is used when enabled for server-side cleanup.

## Sharing & third parties
- We use Firebase (Google) for cloud sync and FCM for notifications. See Google Cloud's privacy docs.
- No third-party advertising SDKs are integrated by default.

## User rights
- Users may request data export (local messages as JSON) and data deletion (Account deletion / Forget me). Use the app's Privacy settings.
- To request deletion of server-side data, contact: privacy@deskchat.app

## Security
- Local data is encrypted at rest.
- Network communications use TLS (HTTPS).
- We rotate tokens frequently and do not store long-term identifiable device IDs.

## Contact
privacy@deskchat.app