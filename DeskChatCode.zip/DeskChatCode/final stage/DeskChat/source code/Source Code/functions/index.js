const functions = require("firebase-functions");
const admin = require("firebase-admin");
const Filter = require("bad-words");

admin.initializeApp();
const db = admin.firestore();

const filter = new Filter();
const PROFANITY_THRESHOLD = 1; // keep simple binary threshold

/**
 * Existing: moderate on new message
 */
exports.moderateNewMessage = functions.firestore
    .document('desks/{deskId}/messages/{messageId}')
    .onCreate(async (snap, ctx) => {
        const data = snap.data();
        if (!data) return null;
        const text = data.text || '';
        const deskId = ctx.params.deskId;
        const messageId = ctx.params.messageId;

        const moderationRef = db.collection('moderation').doc();
        const messageRef = snap.ref;

        try {
            const isProfane = filter.isProfane(text);
            const filteredText = isProfane ? filter.clean(text) : null;

            const moderationRecord = {
                type: 'automod',
                deskId,
                messageId,
                createdAt: admin.firestore.FieldValue.serverTimestamp(),
                profane: !!isProfane
            };

            if (isProfane) {
                await messageRef.update({
                    flagged: true,
                    profanityScore: PROFANITY_THRESHOLD,
                    filteredText: filteredText
                });
                await moderationRef.set(moderationRecord);
            } else {
                await moderationRef.set(moderationRecord);
            }
        } catch (err) {
            console.error('Moderation function error:', err);
        }

        return null;
    });

/**
 * Callable admin cleanup: delete documents that are expired or hard-flagged.
 * Only callable by users with admin role — the function checks a custom claim 'admin' on the token
 * (recommended: set custom claims via Firebase Admin SDK when promoting users to admin).
 */
exports.adminCleanup = functions.https.onCall(async (data, context) => {
    // ensure caller authenticated
    if (!context.auth) {
        throw new functions.https.HttpsError('unauthenticated', 'Request had no authentication.');
    }

    const uid = context.auth.uid;
    // check custom claim, this is safer than checking Firestore user doc
    if (!context.auth.token || !context.auth.token.admin) {
        throw new functions.https.HttpsError('permission-denied', 'Only admins may run cleanup.');
    }

    const now = admin.firestore.Timestamp.now();
    const deletedDocs = [];

    // Query all desks and their messages that are expired OR flagged + deleted=false
    const desksSnap = await db.collection('desks').get();
    const batch = db.batch();
    for (const deskDoc of desksSnap.docs) {
        const messagesRef = deskDoc.ref.collection('messages')
            .where('expiresAt', '<=', now)
            .limit(500);

        const expired = await messagesRef.get();
        expired.docs.forEach(d => {
            batch.delete(d.ref);
            deletedDocs.push(d.ref.path);
        });

        // also remove messages explicitly marked deleted=true (cleanup)
        const softDeletedQuery = deskDoc.ref.collection('messages')
            .where('deleted', '==', true)
            .limit(500);
        const softDeleted = await softDeletedQuery.get();
        softDeleted.docs.forEach(d => {
            batch.delete(d.ref);
            deletedDocs.push(d.ref.path);
        });
    }

    if (deletedDocs.length === 0) return {deleted: 0};

    await batch.commit();
    return {deleted: deletedDocs.length, paths: deletedDocs.slice(0, 100)};
});

/**
 * Placeholder: create a moderation report (already also created client-side by repo.reportMessage which writes to /moderation).
 * This cloud function demonstrates more validation server-side if you need it.
 */
exports.createReport = functions.https.onCall(async (data, context) => {
    if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'Not signed in');
    const {deskId, messageId, reason} = data || {};
    if (!deskId || !messageId) throw new functions.https.HttpsError('invalid-argument', 'deskId and messageId are required');

    const rec = {
        type: 'report',
        deskId,
        messageId,
        reporterId: context.auth.uid,
        reason: reason || 'unspecified',
        createdAt: admin.firestore.FieldValue.serverTimestamp()
    };

    try {
        await db.collection('moderation').doc().set(rec);
        return {ok: true};
    } catch (err) {
        console.error('createReport error', err);
        throw new functions.https.HttpsError('internal', 'Failed to create report');
    }
});