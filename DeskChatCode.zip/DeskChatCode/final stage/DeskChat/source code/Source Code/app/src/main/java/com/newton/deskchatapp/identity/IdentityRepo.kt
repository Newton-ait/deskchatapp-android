package com.newton.deskchatapp.identity

import java.util.UUID

class IdentityRepo {
    fun generateAnonToken(): String {
        return UUID.randomUUID().toString().substring(0,8)
    }

    // reveal identity would attach a real uid in cloud sync; local method stub
    fun reveal(identityToken: String): String {
        // stub - in production, link token to authenticated UID with explicit consent
        return "REVEALED_BY_USER"
    }
}
