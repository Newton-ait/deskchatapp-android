package com.deskchat.location

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingClient
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices
import timber.log.Timber

class GeofenceHelper(private val context: Context) {
    private val geofencingClient: GeofencingClient = LocationServices.getGeofencingClient(context)

    fun addGeofence(id: String, lat: Double, lng: Double, radiusMeters: Float = 100f, expirationMs: Long = Geofence.NEVER_EXPIRE, transitionTypes: Int = Geofence.GEOFENCE_TRANSITION_ENTER or Geofence.GEOFENCE_TRANSITION_EXIT, onComplete: (Boolean) -> Unit = {}) {
        val geofence = Geofence.Builder()
            .setRequestId(id)
            .setCircularRegion(lat, lng, radiusMeters)
            .setExpirationDuration(expirationMs)
            .setTransitionTypes(transitionTypes)
            .build()

        val request = GeofencingRequest.Builder()
            .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
            .addGeofence(geofence)
            .build()

        geofencingClient.addGeofences(request, getGeofencePendingIntent()).addOnSuccessListener {
            Timber.d("Geofence added $id")
            onComplete(true)
        }.addOnFailureListener { e ->
            Timber.w(e, "Failed to add geofence $id")
            onComplete(false)
        }
    }

    fun removeGeofence(id: String, onComplete: (Boolean) -> Unit = {}) {
        geofencingClient.removeGeofences(listOf(id)).addOnSuccessListener {
            onComplete(true)
        }.addOnFailureListener { _ -> onComplete(false) }
    }

    private fun getGeofencePendingIntent(): PendingIntent {
        val intent = Intent(context, GeofenceBroadcastReceiver::class.java)
        val flag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE else PendingIntent.FLAG_UPDATE_CURRENT
        return PendingIntent.getBroadcast(context, 0, intent, flag)
    }
}