package com.newton.deskchatapp.nearby.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.newton.deskchatapp.nearby.location.GeoGrid
import com.newton.deskchatapp.nearby.location.GpsManager
import com.newton.deskchatapp.repo.MessageRepo
import kotlinx.coroutines.launch

class NearbyDeskViewModel(application: Application) : AndroidViewModel(application) {
    private val gps = GpsManager(application)
    private val repo = MessageRepo(application)

    fun postMessageAtCurrentLocation(text: String, callback: (Boolean)->Unit) {
        viewModelScope.launch {
            try {
                val loc = gps.getLastLocationCoarse()
                if (loc == null) { callback(false); return@launch }
                val cell = GeoGrid.cellId(loc.first, loc.second)
                repo.postLocalMessage(text, cell)
                callback(true)
            } catch (e: Exception) {
                callback(false)
            }
        }
    }
}
