package com.newton.deskchatapp.auth

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser

class AuthManager(private val firebaseAuth: FirebaseAuth = FirebaseAuth.getInstance()) {
    fun currentUser(): FirebaseUser? = firebaseAuth.currentUser
    fun getUserId(): String? = firebaseAuth.currentUser?.uid
    suspend fun getOrCreateUserUid(): Result<String> {
        val u = firebaseAuth.currentUser
        return if (u != null) Result.success(u.uid) else Result.failure(Exception("No user signed in"))
    }
}
