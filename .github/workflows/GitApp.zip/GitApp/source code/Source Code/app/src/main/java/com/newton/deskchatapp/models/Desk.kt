package com.newton.deskchatapp.models

import com.google.firebase.firestore.GeoPoint

data class Desk(
    val id: String = "",
    val name: String = "",
    val location: GeoPoint? = null,
    val metadata: Map<String, Any>? = null
)
