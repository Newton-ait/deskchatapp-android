package com.newton.deskchatapp.nearby.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.le.*
import android.content.Context
import android.os.ParcelUuid
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import java.nio.charset.Charset
import java.util.UUID

/**
 * NEW: Desk layer - BluetoothManager
 * Implements basic BLE advertise & scan for short text payloads.
 *
 * Notes:
 * - Requires runtime permissions: BLUETOOTH_SCAN, BLUETOOTH_ADVERTISE, BLUETOOTH_CONNECT (API 31+)
 * - Advertise payloads are limited; use small messages or IDs referencing content stored locally/cloud.
 * - This class is a best-effort implementation and needs device testing.
 */
class BluetoothManager(private val context: Context) {
    private val TAG = "BluetoothManager"
    private val adapter: BluetoothAdapter? by lazy { BluetoothAdapter.getDefaultAdapter() }
    private val advertiser: BluetoothLeAdvertiser? by lazy { adapter?.bluetoothLeAdvertiser }
    private val scanner: BluetoothLeScanner? by lazy { adapter?.bluetoothLeScanner }
    private var advertising = false

    private val _received = MutableSharedFlow<NearbyAdvert>(replay = 16)
    val received = _received.asSharedFlow()

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            super.onScanResult(callbackType, result)
            try {
                val data = result.scanRecord?.serviceData
                // Try to get bytes from manufacturer data fallback
                val man = result.scanRecord?.manufacturerSpecificData
                var payloadText: String? = null
                // First try service data
                result.scanRecord?.serviceUuids?.let { uuids ->
                    if (uuids.isNotEmpty()) {
                        val uuid = uuids[0]
                        result.scanRecord?.getServiceData(uuid)?.let { bytes ->
                            payloadText = String(bytes, Charset.forName("UTF-8"))
                        }
                    }
                }
                // Fallback: manufacturer data (first entry)
                if (payloadText == null && man != null && man.size() > 0) {
                    val key = man.keyAt(0)
                    val bytes = man.get(key)
                    if (bytes != null) payloadText = String(bytes, Charset.forName("UTF-8"))
                }
                payloadText?.let {
                    val advert = NearbyAdvert(result.device.address, it)
                    CoroutineScope(Dispatchers.IO).launch { _received.emit(advert) }
                }
            } catch (e: Exception) {
                Log.w(TAG, "onScanResult parse failed: ${e.message}")
            }
        }

        override fun onScanFailed(errorCode: Int) {
            super.onScanFailed(errorCode)
            Log.w(TAG, "BLE scan failed: $errorCode")
        }
    }

    @SuppressLint("MissingPermission")
    fun startAdvertising(textPayload: String) {
        if (advertising) return
        try {
            if (adapter == null || advertiser == null) {
                Log.w(TAG, "Device does not support BLE advertising")
                return
            }
            val settings = AdvertiseSettings.Builder()
                .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
                .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
                .setConnectable(false)
                .build()

            // Put payload into manufacturer data (small) as UTF-8 bytes. Keep payload short.
            val payloadBytes = textPayload.toByteArray(Charset.forName("UTF-8"))
            val manufacturerId = 0xFFFF // experimental ID; consider using proper assigned company ID in production
            val data = AdvertiseData.Builder()
                .addManufacturerData(manufacturerId, payloadBytes.take(22).toByteArray()) // limit size
                .setIncludeDeviceName(false)
                .build()

            advertiser.startAdvertising(settings, data, advertiseCallback)
            advertising = true
            Log.i(TAG, "started advertising payload size=${payloadBytes.size}")
        } catch (e: Exception) {
            Log.w(TAG, "startAdvertising failed: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    fun stopAdvertising() {
        try {
            advertiser?.stopAdvertising(advertiseCallback)
            advertising = false
        } catch (e: Exception) {
            Log.w(TAG, "stopAdvertising failed: ${e.message}")
        }
    }

    private val advertiseCallback = object : AdvertiseCallback() {
        override fun onStartSuccess(settingsInEffect: AdvertiseSettings) {
            super.onStartSuccess(settingsInEffect)
            Log.i(TAG, "Advertise onStartSuccess")
        }

        override fun onStartFailure(errorCode: Int) {
            super.onStartFailure(errorCode)
            Log.w(TAG, "Advertise onStartFailure: $errorCode")
        }
    }

    @SuppressLint("MissingPermission")
    fun startScan() {
        try {
            if (scanner == null) {
                Log.w(TAG, "Device does not support BLE scanning")
                return
            }
            val filters = listOf<ScanFilter>() // no filter to discover all adverts; consider adding filter by UUID/manufacturer
            val settings = ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .build()
            scanner.startScan(filters, settings, scanCallback)
            Log.i(TAG, "startScan called")
        } catch (e: Exception) {
            Log.w(TAG, "startScan failed: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    fun stopScan() {
        try {
            scanner?.stopScan(scanCallback)
            Log.i(TAG, "stopScan called")
        } catch (e: Exception) {
            Log.w(TAG, "stopScan failed: ${e.message}")
        }
    }

    data class NearbyAdvert(val address: String, val payload: String)
}
