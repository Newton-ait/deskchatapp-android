package com.newton.deskchatapp

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class MyApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val name = "DeskChat Messages"
                val channel = NotificationChannel("deskchat_messages", name, NotificationManager.IMPORTANCE_DEFAULT)
                val nm = getSystemService(NotificationManager::class.java)
                nm.createNotificationChannel(channel)
            }
        } catch (e: Exception) {}
    }

import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Constraints
import androidx.work.NetworkType
import androidx.work.ExistingPeriodicWorkPolicy
import java.util.concurrent.TimeUnit

try {
    val constraints = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED)
        .build()
    val syncReq = PeriodicWorkRequestBuilder<com.newton.deskchatapp.work.SyncWorker>(15, TimeUnit.MINUTES)
        .setConstraints(constraints)
        .build()
    WorkManager.getInstance(this).enqueueUniquePeriodicWork("desk_sync_worker", ExistingPeriodicWorkPolicy.KEEP, syncReq)
} catch (e: Exception) {}

}
