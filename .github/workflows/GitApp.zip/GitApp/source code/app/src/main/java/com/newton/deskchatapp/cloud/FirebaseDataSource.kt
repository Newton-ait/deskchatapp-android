package com.newton.deskchatapp.cloud

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

/**
 * NEW: Desk layer - FirebaseDataSource
 * Lightweight wrapper to push ephemeral desk messages to Firestore.
 * Requires google-services.json and proper Firebase setup.
 */
class FirebaseDataSource {
    private val TAG = "FirebaseDataSource"
    private val db = FirebaseFirestore.getInstance()

    suspend fun pushDeskMessage(docPath: String, payload: Map<String, Any>) : Boolean {
        return try {
            db.collection(docPath).add(payload).await()
            true
        } catch (e: Exception) {
            Log.w(TAG, "pushDeskMessage failed: ${e.message}")
            false
        }
    }
}
