package com.newton.deskchatapp.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.newton.deskchatapp.cloud.FirebaseDataSource
import com.newton.deskchatapp.db.DeskDatabase
import android.util.Log

class SyncWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    private val TAG = "SyncWorker"
    override suspend fun doWork(): Result {
        val db = DeskDatabase.getInstance(applicationContext)
        val dao = db.deskMessageDao()
        val firebase = FirebaseDataSource()
        return try {
            val unsynced = dao.getUnsynced()
            for (m in unsynced) {
                val payload = mapOf(
                    "id" to m.id,
                    "text" to (m.text ?: ""),
                    "cellHash" to m.cellHash,
                    "timestamp" to m.timestamp,
                    "ttlMs" to m.ttlMs
                )
                val ok = firebase.pushDeskMessage("desks_ephemeral", payload)
                if (ok) {
                    // mark as synced
                    dao.insert(m.copy(synced = true))
                    Log.i(TAG, "synced ${m.id}")
                }
            }
            Result.success()
        } catch (e: Exception) {
            Log.w(TAG, "SyncWorker failed: ${e.message}")
            Result.retry()
        }
    }
}
