package com.newton.deskchatapp.nearby.ui

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.newton.deskchatapp.R
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class NearbyActivity : AppCompatActivity() {
    private lateinit var viewModel: NearbyDeskViewModel
    private lateinit var adapter: NearbyListAdapter

    private val requestPerms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        // start scanning if permissions granted
        viewModel.startNearby()
        viewModel.observeIncomingFromBluetooth()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_nearby)

        viewModel = ViewModelProvider(this).get(NearbyDeskViewModel::class.java)
        adapter = NearbyListAdapter(listOf())

        val rv = findViewById<RecyclerView>(R.id.nearby_recycler)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        val postBtn = findViewById<Button>(R.id.post_button)
        val postInput = findViewById<EditText>(R.id.post_input)

        postBtn.setOnClickListener {
            val text = postInput.text.toString().trim()
            if (text.isNotEmpty()) {
                viewModel.postMessageAtCurrentLocation(text) { ok ->
                    runOnUiThread {
                        if (ok) {
                            postInput.setText("")
                        }
                    }
                }
            }
        }

        // Request permissions
        val perms = mutableListOf<String>()
        perms.addAll(com.newton.deskchatapp.nearby.PermissionsHelper.requiredBluetoothPermissions)
        perms.addAll(com.newton.deskchatapp.nearby.PermissionsHelper.locationPermissions)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        requestPerms.launch(perms.toTypedArray())

        // Observe incoming messages and update adapter (simple polling via ViewModel)
        CoroutineScope(Dispatchers.Main).launch {
            // For simplicity, poll local DB every 2s - in production use Flow/LiveData
            while (!isFinishing) {
                try {
                    val loc = viewModel.getLastCellSync()
                    val list = if (loc != null) viewModel.getMessagesForCellSync(loc) else emptyList()
                    adapter.update(list)
                    kotlinx.coroutines.delay(2000)
                } catch (e: Exception) { break }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.startNearby()
        viewModel.observeIncomingFromBluetooth()
    }

    override fun onPause() {
        super.onPause()
        viewModel.stopNearby()
    }
}
