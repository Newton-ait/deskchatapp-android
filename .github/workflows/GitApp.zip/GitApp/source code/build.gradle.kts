
plugins {
    id("org.jlleitschuh.gradle.ktlint") version "12.1.1"
}
tasks.register("ktlintCheckAll") {
    group = "verification"
    dependsOn("ktlintCheck")
}


// NEW: Add google services classpath in buildscript dependencies if using legacy buildscript
