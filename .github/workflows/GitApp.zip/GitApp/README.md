# DeskChat

DeskChat is a hybrid anonymous, location-based messaging app designed for proximity and global communication.
Messages are anonymous by default and expire after 24 hours.

## Features
- Location-based anonymous messaging
- 24-hour message expiration
- Offline mode via Bluetooth / Wi-Fi Direct
- Online sync via Firebase (replace google-services.json)
- Voice notes and local caching
- Privacy-first: no personal data stored by default

## Build & Run
1. Place your `google-services.json` into the `app/` folder (replace placeholder).
2. Open the project in Android Studio.
3. Sync Gradle and build:
```
./gradlew assembleDebug
```
4. The debug APK will be at `app/build/outputs/apk/debug/`.

## Commit Verification
For enhanced project security and authenticity, consider enabling Git commit signing (GPG) on GitHub:
https://docs.github.com/en/authentication/managing-commit-signature-verification

Developed by Newton-ait
© 2025 Newton-ait. All rights reserved.
